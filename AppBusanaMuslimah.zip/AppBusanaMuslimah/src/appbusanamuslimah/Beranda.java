/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package appbusanamuslimah;

import java.awt.Color;
import javax.swing.JOptionPane;
import Hijab.Diario;
import Hijab.Elzata;
import Hijab.Levine;
import Hijab.Pashmina;
import Hijab.Rabbani;
import Hijab.Shafira;
import Hijab.Umama;
import Hijab.Zoya;
import Baju.Babyhelu;
import Baju.Dianpelangi;
import Baju.Haura;
import Baju.Melika;
import Baju.Monel;
import Baju.Riamiranda;
import Baju.Tuneeca;
import Baju.Zmnow;
import Mukena.Abaya;
import Mukena.Algani;
import Mukena.Azzura;
import Mukena.Ghanimi;
import Mukena.Halima;
import Mukena.Ponco;
import Mukena.Tatuis;
import Mukena.Tazbiya;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Stack;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import javax.swing.JPanel;


/**
 *
 * @author Lenovo
 */
public class Beranda extends javax.swing.JFrame {
    private final List<Object[]> rowsToBeAdded = new ArrayList<>();
    
    private Diario Diariohijab;
    private Elzata Elzatahijab;
    private Levine Levinehijab;
    private Pashmina Pashminahijab;
    private Rabbani Rabbanihijab;
    private Shafira Shafirahijab;
    private Umama Umamahijab;
    private Zoya Zoyahijab;
    
    private Babyhelu Babyhelubaju;
    private Dianpelangi Dianpelangibaju;
    private Haura Haurabaju;
    private Melika Melikabaju;
    private Monel Monelbaju;
    private Riamiranda Riamirandabaju;
    private Tuneeca Tuneecabaju;
    private Zmnow Zmnowbaju;
    
    private Abaya Abayamukena;
    private Algani Alganimukena;
    private Azzura Azzuramukena;
    private Ghanimi Ghanimimukena;
    private Halima Halimamukena;
    private Ponco Poncomukena;
    private Tatuis Tatuismukena;
    private Tazbiya Tazbiyamukena;
    
    // Di dalam kelas Beranda


    private double total = 0.0;
    /**
     * Creates new form Beranda
     */
    public Beranda() {
        initComponents();
        // Anda mungkin perlu menginisialisasi JCombobox ini dengan daftar kelas yang tersedia
        JComboBox<String> kelasComboBox = new JComboBox<>(new String[]{"Abaya", "Algani", "Azzura", "Ghanimi", "Halima", "Ponco", "Tatuis", "Tazbiya", "Babyhelu", "Dianpelangi", "Haura", "Melika", "Monel", "Riamiranda", "Tuneeca", "Zmnow", "Diario", "Elzata", "Levine", "Pashmina", "Rabbani", "Shafira", "Umama", "Zoya" }); 

// ... kemudian Anda menambahkan listener
kelasComboBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String selectedClass = (String) kelasComboBox.getSelectedItem();
        
        // Berdasarkan kelas yang dipilih, set nilai hargatransaksi
        switch (selectedClass) {
            case "Abaya":
                hargatransaksi.setText(String.valueOf(Abayamukena.getHarga()));
                break;
            case "Algani":
                hargatransaksi.setText(String.valueOf(Alganimukena.getHarga()));
                break;
            case "Azzura":
                hargatransaksi.setText(String.valueOf(Azzuramukena.getHarga()));
                break;
            case "Ghanimi":
                hargatransaksi.setText(String.valueOf(Ghanimimukena.getHarga()));
                break;
            case "Halima":
                hargatransaksi.setText(String.valueOf(Halimamukena.getHarga()));
                break;
            case "Ponco":
                hargatransaksi.setText(String.valueOf(Poncomukena.getHarga()));
                break;
            case "Tatuis":
                hargatransaksi.setText(String.valueOf(Tatuismukena.getHarga()));
                break;
            case "Tazbiya":
                hargatransaksi.setText(String.valueOf(Tazbiyamukena.getHarga()));
                break;
            case "Babyhelu":
                hargatransaksi.setText(String.valueOf(Babyhelubaju.getHarga()));
                break;
            case "Dianpelangi":
                hargatransaksi.setText(String.valueOf(Dianpelangibaju.getHarga()));
                break;
            case "Haura":
                hargatransaksi.setText(String.valueOf(Haurabaju.getHarga()));
                break;
            case "Melika":
                hargatransaksi.setText(String.valueOf(Melikabaju.getHarga()));
                break;
            case "Monel":
                hargatransaksi.setText(String.valueOf(Monelbaju.getHarga()));
                break;
            case "Riamiranda":
                hargatransaksi.setText(String.valueOf(Riamirandabaju.getHarga()));
                break;
            case "Tuneeca":
                hargatransaksi.setText(String.valueOf(Tuneecabaju.getHarga()));
                break;
            case "Zmnow":
                hargatransaksi.setText(String.valueOf(Zmnowbaju.getHarga()));
                break;
            case "Diario":
                hargatransaksi.setText(String.valueOf(Diariohijab.getHarga()));
                break;
            case "Elzata":
                hargatransaksi.setText(String.valueOf(Elzatahijab.getHarga()));
                break;
            case "Levine":
                hargatransaksi.setText(String.valueOf(Levinehijab.getHarga()));
                break;
            case "Pashmina":
                hargatransaksi.setText(String.valueOf(Pashminahijab.getHarga()));
                break;
            case "Rabbani":
                hargatransaksi.setText(String.valueOf(Rabbanihijab.getHarga()));
                break;
            case "Shafira":
                hargatransaksi.setText(String.valueOf(Shafirahijab.getHarga()));
                break;
            case "Umama":
                hargatransaksi.setText(String.valueOf(Umamahijab.getHarga()));
                break;
            case "Zoya":
                hargatransaksi.setText(String.valueOf(Zoyahijab.getHarga()));
                break;
        }
    }
});

        
        
        
        namapengguna.setText("hallo, " + Register.username);
        Diariohijab = new Diario("Diario", "Hitam", "Kain Katun", 40, 15000, "Hijab Diario adalah merek hijab yang menawarkan gaya dan kenyamanan untuk perempuan modern. Dengan desain yang elegan dan bahan berkualitas, Hijab Diario menyediakan berbagai pilihan hijab mulai dari warna, motif, hingga tekstur yang dapat menyesuaikan dengan kebutuhan sehari-hari. Produk-produknya didesain dengan mempertimbangkan tren terkini serta kebutuhan fungsionalitas bagi penggunanya. Dengan memilih Hijab Diario, pengguna dapat merasa percaya diri dalam tampilan mereka sekaligus menjaga aurat dengan sempurna.", 3050);
        Elzatahijab = new Elzata("Elzata", "Cream", "Kain Jearsey", 30, 30000, "Hijab Elzata adalah merek hijab yang menawarkan gaya dan kenyamanan untuk perempuan modern. Dengan desain yang elegan dan bahan berkualitas, Hijab Elzata menyediakan berbagai pilihan hijab mulai dari warna, motif, hingga tekstur yang dapat menyesuaikan dengan kebutuhan sehari-hari. Produk-produknya didesain dengan mempertimbangkan tren terkini serta kebutuhan fungsionalitas bagi penggunanya. Dengan memilih Hijab Elzata, pengguna dapat merasa percaya diri dalam tampilan mereka sekaligus menjaga aurat dengan sempurna.", 1294);
        Levinehijab = new Levine("Levine", "Abu-abu", "Kain Katun", 40, 25000, "Hijab Levine, sebuah merek yang menghadirkan gaya dan kenyamanan bagi perempuan modern. Dengan desain yang elegan dan kualitas bahan yang prima, Hijab Levine menawarkan beragam pilihan hijab dengan warna, motif, dan tekstur yang sesuai dengan kebutuhan sehari-hari. Produknya dirancang dengan memperhatikan tren mode terbaru dan kebutuhan praktis pengguna. Mengenakan Hijab Levine, pengguna tidak hanya tampil percaya diri tetapi juga menjaga aurat dengan elegan.", 3418);
        Pashminahijab = new Pashmina("Pashmina", "Putih", "Kain Jearsey", 40, 40000, "Hijab Pashmina, memadukan gaya dan kenyamanan bagi perempuan masa kini. Dengan desain yang memikat dan bahan terbaik, Hijab Pashmina menawarkan variasi hijab yang kaya akan warna, motif, dan tekstur. Setiap produknya mencerminkan tren terbaru dan memenuhi kebutuhan praktis pengguna. Memilih Hijab Pashmina berarti memilih gaya yang elegan sambil tetap menjaga keanggunan dan kesopanan.", 2761);
        Rabbanihijab = new Rabbani("Rabbani", "Putih", "Kain Katun", 30, 10000, "Hijab Rabbani, sebuah merek yang mengerti kebutuhan perempuan modern. Dengan desain yang anggun dan bahan berkualitas, Hijab Rabbani menyajikan berbagai pilihan hijab yang menarik dari segi warna, motif, dan tekstur. Selalu mengikuti tren terkini, produk Rabbani dirancang untuk memenuhi kebutuhan praktis dan estetika pengguna. Dengan Hijab Rabbani, tampilan Anda akan selalu berkelas dan aurat terjaga dengan sempurna.", 1513);
        Shafirahijab = new Shafira("Shafira", "Cream", "Kain Paris", 40, 20000, "Hijab Shafira, mewakili kombinasi sempurna antara gaya dan kenyamanan untuk perempuan modern. Dengan desain yang elegan dan bahan pilihan, Hijab Shafira menawarkan koleksi hijab yang beragam, mulai dari warna, motif, hingga tekstur. Setiap produknya menggambarkan tren terbaru dan memenuhi kebutuhan praktis pengguna. Dengan memilih Hijab Shafira, Anda akan merasa percaya diri dan menjaga aurat dengan indah.", 3627);
        Umamahijab = new Umama("Umama", "Putih", "Kain Katun", 30, 50000, "Hijab Umama, merek yang memahami kebutuhan perempuan modern akan gaya dan kenyamanan. Dengan desain yang unik dan bahan berkualitas tinggi, Hijab Umama menawarkan beragam hijab yang menarik dalam hal warna, motif, dan tekstur. Produk-produknya selalu mengikuti tren terbaru dan dirancang dengan mempertimbangkan kebutuhan praktis pengguna. Mengenakan Hijab Umama, Anda akan tampil elegan dan menjaga aurat dengan sempurna.", 2741);
        Zoyahijab = new Zoya("Zoya", "Biru", "Kain Voal", 40, 35000, "Hijab Zoya, menggabungkan gaya dan kenyamanan untuk perempuan modern. Dengan desain yang mempesona dan bahan berkualitas, Hijab Zoya menyediakan berbagai pilihan hijab dengan warna, motif, dan tekstur yang variatif. Produknya didesain untuk memenuhi tren terkini dan kebutuhan praktis pengguna. Dengan memilih Hijab Zoya, pengguna dapat tampil percaya diri dengan gaya yang elegan sambil menjaga aurat dengan sempurna.", 5724);
        
        
        Babyhelubaju = new Babyhelu("Babyhelu", "Putih", "Kain Katun", 40, 210000, "Selain menawarkan kualitas superior, Babyhelu menjadi pilihan utama bagi mereka yang menghargai harmoni antara keanggunan dan fungsionalitas. Setiap desainnya dikerjakan dengan detail, memastikan bahwa setiap pemakai merasa percaya diri dan menonjol di setiap kesempatan, dari acara formal hingga santai.", 3050);
        Dianpelangibaju = new Dianpelangi("Dian Pelangi", "Cream", "Kain Jearsey", 30, 225000, "Bagi pencinta busana yang berani dan berbeda, Dian Pelangi adalah jawabannya. Dengan mengenakan koleksi Dian Pelangi, Anda tidak hanya tampil stylish tetapi juga merayakan kekayaan budaya dan keindahan tradisi dengan twist modern.", 1294);
        Haurabaju = new Haura("Haura", "Abu-abu", "Kain Katun", 40, 240000, "Dengan Haura, setiap wanita dapat merasakan sentuhan eksklusif yang timeless. Busana yang ditawarkan tidak hanya memancarkan keanggunan tetapi juga memberikan kenyamanan maksimal, memastikan Anda tampil memukau setiap saat.", 3418);
        Melikabaju = new Melika("Melika", "Putih", "Kain Jearsey", 40, 235000, "Jika Anda mencari kombinasi sempurna antara elegansi dan kepraktisan, Melika adalah pilihan yang tepat. Setiap koleksi mencerminkan keunikan dan kefemininan, menambahkan sentuhan anggun pada setiap gaya Anda.", 2761);
        Monelbaju = new Monel("Monel", "Putih", "Kain Katun", 30, 215000, "Monel hadir dengan gaya yang modern dan santai dalam busana muslimah. Koleksi-koleksi mereka mengedepankan kenyamanan tanpa mengorbankan estetika dan keanggunan., tampilan Anda akan selalu berkelas dan aurat terjaga dengan sempurna.", 1513);
        Riamirandabaju = new Riamiranda("Ria Miranda", "Cream", "Kain Paris", 40, 230000, "Ria Miranda dikenal dengan desain busana muslimah yang penuh dengan detail dan motif etnik. Setiap koleksinya mencerminkan kekayaan budaya dan keindahan tradisional, memadukannya dengan tren kontemporer., Anda akan merasa percaya diri dan menjaga aurat dengan indah.", 3627);
        Tuneecabaju = new Tuneeca("Tuneeca", "Putih", "Kain Katun", 30, 220000, "Tuneeca menawarkan busana muslimah dengan gaya yang edgy dan kontemporer. Koleksi mereka selalu mengikuti tren terbaru namun tetap mempertahankan nilai-nilai syar'i. Produk-produknya selalu mengikuti tren terbaru dan dirancang dengan mempertimbangkan kebutuhan praktis pengguna. Mengenakan Hijab Umama, Anda akan tampil elegan dan menjaga aurat dengan sempurna.", 2741);
        Zmnowbaju = new Zmnow("ZM Now", "Biru", "Kain Voal", 40, 250000, "Dengan pendekatan yang fresh dan inovatif, ZM Now memadukan desain modern dengan kualitas tinggi dalam setiap koleksinya. Busana muslimah dari ZM Now seringkali menjadi pilihan bagi mereka yang menginginkan gaya yang stylish namun tetap syar'i., pengguna dapat tampil percaya diri dengan gaya yang elegan sambil menjaga aurat dengan sempurna.", 5724);
        
        
        Abayamukena = new Abaya("Abaya", "Abu-abu", "Kain Katun", 40, 120000, "Mukena Abaya menggabungkan esensi tradisi dengan elemen modern dalam desain busana ibadah, menciptakan harmoni antara fungsionalitas dan estetika. Dengan potongan yang longgar dan menggunakan bahan berkualitas tinggi seperti katun, mukena ini tidak hanya memastikan kenyamanan tetapi juga memenuhi prinsip-prinsip kesopanan dalam ibadah sesuai syariat Islam. Tidak hanya itu, detail-detail seperti bordir halus atau aplikasi menambahkan nuansa keanggunan yang mempesona. Ini menjadikan Mukena Abaya pilihan utama bagi wanita Muslim yang ingin meraih keseimbangan antara tampil modis dan mendalamkan nilai-nilai spiritual dalam setiap ibadahnya.", 3050);
        Alganimukena = new Algani("Algani", "Cream", "Kain Jearsey", 30, 110000, "Menggabungkan esensi tradisi dengan elemen modern, Algani menawarkan harmoni sempurna antara fungsionalitas dan estetika dalam busana ibadah. Dengan potongan longgar dan bahan berkualitas tinggi seperti katun, Algani memastikan kenyamanan sekaligus mematuhi prinsip kesopanan dalam ibadah sesuai syariat Islam. Detail-detail seperti bordir halus atau aplikasi menambahkan nuansa keanggunan, menjadikan Algani pilihan ideal untuk wanita Muslim yang ingin tampil elegan dan spiritual.", 1294);
        Azzuramukena = new Azzura("Azzura", "Putih", "Kain Katun", 40, 130000, "Dengan desain yang menawan dan detail yang teliti, Azzura memadukan kepraktisan dengan keindahan dalam busana ibadah. Bahan berkualitas dan siluet yang pas memastikan kenyamanan maksimal, sementara elemen desain seperti bordir atau aplikasi memberikan sentuhan estetika yang menawan.", 3418);
        Ghanimimukena = new Ghanimi("Ghanimi", "Putih", "Kain Jearsey", 40, 150000, "Busana ibadah Ghanimi mencerminkan kesederhanaan dengan sentuhan elegan. Desainnya yang fungsional tetap mempertahankan keanggunan, dengan aksen seperti bordir atau detail khas lainnya yang menambahkan nuansa spesial dalam setiap koleksinya.", 2761);
        Halimamukena = new Halima("Halima", "Hitam", "Kain Katun", 30, 115000, "Busana Halima menghadirkan harmoni antara tradisi dan tren saat ini. Dengan potongan yang nyaman dan desain yang elegan, Halima menawarkan busana ibadah yang tidak hanya memenuhi syariat tetapi juga memberikan tampilan yang modis.", 1513);
        Poncomukena = new Ponco("Ponco", "Coklta tua", "Kain Paris", 40, 135000, "Dengan pendekatan yang unik, Ponco menyuguhkan busana ibadah dengan siluet yang longgar namun tetap stylish. Bahan berkualitas dan aksen desain memberikan karakter khusus, memastikan penggunanya tampil percaya diri dan anggun.", 3627);
        Tatuismukena = new Tatuis("Tatuis", "Putih", "Kain Katun", 30, 125000, "Busana ibadah Tatuis menonjolkan keseimbangan antara sederhana dan elegan. Dengan fokus pada kualitas dan detail, Tatuis memastikan bahwa setiap koleksi mencerminkan keunikan dan keanggunan bagi penggunanya.", 2741);
        Tazbiyamukena = new Tazbiya("Tazbiya", "Cream", "Kain Voal", 40, 140000, "Dengan desain yang elegan dan fungsional, Tazbiya menghadirkan busana ibadah yang memadukan kepraktisan dengan keanggunan. Detail-detail seperti bordir halus atau aplikasi memberikan sentuhan estetika yang memukau, menjadikan Tazbiya pilihan ideal bagi wanita Muslim yang ingin tampil sempurna dalam setiap ibadahnya.", 5724);
        
    
    
    // Panggil method jalankan() untuk menetapkan deskripsi ke tksdeskripsi
    jalankan();
    }
  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel91 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnhome = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        btnkategori = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        logout = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        namapengguna = new javax.swing.JLabel();
        mainpanel = new javax.swing.JPanel();
        homepanel = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel265 = new javax.swing.JLabel();
        jLabel266 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel267 = new javax.swing.JLabel();
        jLabel268 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jLabel275 = new javax.swing.JLabel();
        jLabel276 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jPanel98 = new javax.swing.JPanel();
        jPanel99 = new javax.swing.JPanel();
        jLabel277 = new javax.swing.JLabel();
        jLabel278 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        kategori = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        Hijab = new javax.swing.JLabel();
        pilihhijab = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        Hijab1 = new javax.swing.JLabel();
        pilihbaju = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        Hijab2 = new javax.swing.JLabel();
        pilihmukena = new javax.swing.JButton();
        kategorihijab = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        kembalihijab = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        btndiario = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        btnelzata = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        btnpashmina = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        btnrabbani = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        btnlevine = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        btnumama = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        btnshafira = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        btnzoya = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        kategoribaju = new javax.swing.JPanel();
        jLabel96 = new javax.swing.JLabel();
        kembalibaju = new javax.swing.JPanel();
        jLabel97 = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jLabel98 = new javax.swing.JLabel();
        btnmonel = new javax.swing.JButton();
        jLabel99 = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jLabel100 = new javax.swing.JLabel();
        btnriamiranda = new javax.swing.JButton();
        jLabel101 = new javax.swing.JLabel();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jLabel102 = new javax.swing.JLabel();
        btnhaura = new javax.swing.JButton();
        jLabel103 = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        btnbabyhelu = new javax.swing.JButton();
        jLabel105 = new javax.swing.JLabel();
        jPanel47 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel106 = new javax.swing.JLabel();
        btndianpelangi = new javax.swing.JButton();
        jLabel107 = new javax.swing.JLabel();
        jPanel49 = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jLabel108 = new javax.swing.JLabel();
        btnzmnow = new javax.swing.JButton();
        jLabel109 = new javax.swing.JLabel();
        jPanel51 = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        btntuneeca = new javax.swing.JButton();
        jLabel111 = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jLabel112 = new javax.swing.JLabel();
        btnmelika = new javax.swing.JButton();
        jLabel113 = new javax.swing.JLabel();
        kategorimukena = new javax.swing.JPanel();
        jLabel114 = new javax.swing.JLabel();
        kembalimukena = new javax.swing.JPanel();
        jLabel115 = new javax.swing.JLabel();
        jPanel55 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        btnhalima = new javax.swing.JButton();
        jLabel117 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jLabel118 = new javax.swing.JLabel();
        btnazzura = new javax.swing.JButton();
        jLabel119 = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jLabel120 = new javax.swing.JLabel();
        btntazbiya = new javax.swing.JButton();
        jLabel121 = new javax.swing.JLabel();
        jPanel61 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        btnalgani = new javax.swing.JButton();
        jLabel123 = new javax.swing.JLabel();
        jPanel63 = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        btntatuis = new javax.swing.JButton();
        jLabel125 = new javax.swing.JLabel();
        jPanel65 = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jLabel126 = new javax.swing.JLabel();
        btnghanimi = new javax.swing.JButton();
        jLabel127 = new javax.swing.JLabel();
        jPanel67 = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jLabel128 = new javax.swing.JLabel();
        btnabaya = new javax.swing.JButton();
        jLabel129 = new javax.swing.JLabel();
        jPanel69 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jLabel130 = new javax.swing.JLabel();
        btnponco = new javax.swing.JButton();
        jLabel131 = new javax.swing.JLabel();
        deskabaya = new javax.swing.JPanel();
        jLabel196 = new javax.swing.JLabel();
        kembalideskabaya = new javax.swing.JPanel();
        kembalilevine14 = new javax.swing.JLabel();
        jPanel79 = new javax.swing.JPanel();
        jLabel197 = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        tksdeskripsiabaya = new javax.swing.JTextPane();
        jLabel198 = new javax.swing.JLabel();
        jLabel199 = new javax.swing.JLabel();
        jLabel200 = new javax.swing.JLabel();
        jLabel201 = new javax.swing.JLabel();
        jLabel202 = new javax.swing.JLabel();
        jLabel203 = new javax.swing.JLabel();
        tkswarnaabaya = new javax.swing.JTextField();
        tksbahanabaya = new javax.swing.JTextField();
        tkshargaabaya = new javax.swing.JTextField();
        tksukuranabaya = new javax.swing.JTextField();
        tksstockabaya = new javax.swing.JTextField();
        tksnamaabaya = new javax.swing.JTextField();
        checkabaya = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        deskalgani = new javax.swing.JPanel();
        jLabel204 = new javax.swing.JLabel();
        kembalideskalgani = new javax.swing.JPanel();
        kembalilevine15 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        jLabel205 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        tksdeskripsialgani = new javax.swing.JTextPane();
        jLabel206 = new javax.swing.JLabel();
        jLabel207 = new javax.swing.JLabel();
        jLabel208 = new javax.swing.JLabel();
        jLabel209 = new javax.swing.JLabel();
        jLabel210 = new javax.swing.JLabel();
        jLabel211 = new javax.swing.JLabel();
        tkswarnaalgani = new javax.swing.JTextField();
        tksbahanalgani = new javax.swing.JTextField();
        tkshargaalgani = new javax.swing.JTextField();
        tksukuranalgani = new javax.swing.JTextField();
        tksstockalgani = new javax.swing.JTextField();
        tksnamaalgani = new javax.swing.JTextField();
        checkalgani = new javax.swing.JButton();
        deskazzura = new javax.swing.JPanel();
        jLabel252 = new javax.swing.JLabel();
        kembalideskazzura = new javax.swing.JPanel();
        kembalilevine21 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        jLabel253 = new javax.swing.JLabel();
        jScrollPane25 = new javax.swing.JScrollPane();
        tksdeskripsiazzura = new javax.swing.JTextPane();
        jLabel254 = new javax.swing.JLabel();
        jLabel255 = new javax.swing.JLabel();
        jLabel256 = new javax.swing.JLabel();
        jLabel257 = new javax.swing.JLabel();
        jLabel258 = new javax.swing.JLabel();
        jLabel259 = new javax.swing.JLabel();
        tkswarnaazzura = new javax.swing.JTextField();
        tksbahanazzura = new javax.swing.JTextField();
        tkshargaazzura = new javax.swing.JTextField();
        tksukuranazzura = new javax.swing.JTextField();
        tksstockazzura = new javax.swing.JTextField();
        tksnamaazzura = new javax.swing.JTextField();
        checkazzura = new javax.swing.JButton();
        deskghanimi = new javax.swing.JPanel();
        jLabel212 = new javax.swing.JLabel();
        kembalideskghanimi = new javax.swing.JPanel();
        kembalilevine16 = new javax.swing.JLabel();
        jPanel81 = new javax.swing.JPanel();
        jLabel213 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        tksdeskripsighanimi = new javax.swing.JTextPane();
        jLabel214 = new javax.swing.JLabel();
        jLabel215 = new javax.swing.JLabel();
        jLabel216 = new javax.swing.JLabel();
        jLabel217 = new javax.swing.JLabel();
        jLabel218 = new javax.swing.JLabel();
        jLabel219 = new javax.swing.JLabel();
        tkswarnaghanimi = new javax.swing.JTextField();
        tksbahanghanimi = new javax.swing.JTextField();
        tkshargaghanimi = new javax.swing.JTextField();
        tksukuranghanimi = new javax.swing.JTextField();
        tksstockghanimi = new javax.swing.JTextField();
        tksnamaghanimi = new javax.swing.JTextField();
        checkghanimi = new javax.swing.JButton();
        deskhalima = new javax.swing.JPanel();
        jLabel220 = new javax.swing.JLabel();
        kembalideskhalima = new javax.swing.JPanel();
        kembalilevine17 = new javax.swing.JLabel();
        jPanel82 = new javax.swing.JPanel();
        jLabel221 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        tksdeskripsihalima = new javax.swing.JTextPane();
        jLabel222 = new javax.swing.JLabel();
        jLabel223 = new javax.swing.JLabel();
        jLabel224 = new javax.swing.JLabel();
        jLabel225 = new javax.swing.JLabel();
        jLabel226 = new javax.swing.JLabel();
        jLabel227 = new javax.swing.JLabel();
        tkswarnahalima = new javax.swing.JTextField();
        tksbahanhalima = new javax.swing.JTextField();
        tkshargahalima = new javax.swing.JTextField();
        tksukuranhalima = new javax.swing.JTextField();
        tksstockhalima = new javax.swing.JTextField();
        tksnamahalima = new javax.swing.JTextField();
        chechhalima = new javax.swing.JButton();
        deskponco = new javax.swing.JPanel();
        jLabel228 = new javax.swing.JLabel();
        kembalideskponco = new javax.swing.JPanel();
        kembalilevine18 = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        jLabel229 = new javax.swing.JLabel();
        jScrollPane22 = new javax.swing.JScrollPane();
        tksdeskripsiponco = new javax.swing.JTextPane();
        jLabel230 = new javax.swing.JLabel();
        jLabel231 = new javax.swing.JLabel();
        jLabel232 = new javax.swing.JLabel();
        jLabel233 = new javax.swing.JLabel();
        jLabel234 = new javax.swing.JLabel();
        jLabel235 = new javax.swing.JLabel();
        tkswarnaponco = new javax.swing.JTextField();
        tksbahanponco = new javax.swing.JTextField();
        tkshargaponco = new javax.swing.JTextField();
        tksukuranponco = new javax.swing.JTextField();
        tksstockponco = new javax.swing.JTextField();
        tksnamaponco = new javax.swing.JTextField();
        checkponco = new javax.swing.JButton();
        desktatuis = new javax.swing.JPanel();
        jLabel236 = new javax.swing.JLabel();
        kembalidesktatuis = new javax.swing.JPanel();
        kembalilevine19 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        jLabel237 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        tksdeskripsitatuis = new javax.swing.JTextPane();
        jLabel238 = new javax.swing.JLabel();
        jLabel239 = new javax.swing.JLabel();
        jLabel240 = new javax.swing.JLabel();
        jLabel241 = new javax.swing.JLabel();
        jLabel242 = new javax.swing.JLabel();
        jLabel243 = new javax.swing.JLabel();
        tkswarnatatuis = new javax.swing.JTextField();
        tksbahantatuis = new javax.swing.JTextField();
        tkshargatatuis = new javax.swing.JTextField();
        tksukurantatuis = new javax.swing.JTextField();
        tksstocktatuis = new javax.swing.JTextField();
        tksnamatatuis = new javax.swing.JTextField();
        checktatuis = new javax.swing.JButton();
        desktazbiya = new javax.swing.JPanel();
        jLabel244 = new javax.swing.JLabel();
        kembalidesktazbiya = new javax.swing.JPanel();
        kembalilevine20 = new javax.swing.JLabel();
        jPanel85 = new javax.swing.JPanel();
        jLabel245 = new javax.swing.JLabel();
        jScrollPane24 = new javax.swing.JScrollPane();
        tksdeskripsitazbiya = new javax.swing.JTextPane();
        jLabel246 = new javax.swing.JLabel();
        jLabel247 = new javax.swing.JLabel();
        jLabel248 = new javax.swing.JLabel();
        jLabel249 = new javax.swing.JLabel();
        jLabel250 = new javax.swing.JLabel();
        jLabel251 = new javax.swing.JLabel();
        tkswarnatazbiya = new javax.swing.JTextField();
        tksbahantazbiya = new javax.swing.JTextField();
        tkshargatazbiya = new javax.swing.JTextField();
        tksukurantazbiya = new javax.swing.JTextField();
        tksstocktazbiya = new javax.swing.JTextField();
        tksnamatazbiya = new javax.swing.JTextField();
        checktazbiya = new javax.swing.JButton();
        deskbabyhelu = new javax.swing.JPanel();
        jLabel132 = new javax.swing.JLabel();
        kembalideskbabyhelu = new javax.swing.JPanel();
        kembalilevine6 = new javax.swing.JLabel();
        jPanel71 = new javax.swing.JPanel();
        jLabel133 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tksdeskripsibabyhelu = new javax.swing.JTextPane();
        jLabel134 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jLabel137 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        jLabel139 = new javax.swing.JLabel();
        tkswarnababyhelu = new javax.swing.JTextField();
        tksbahanbabyhelu = new javax.swing.JTextField();
        tkshargababyhelu = new javax.swing.JTextField();
        tksukuranbabyhelu = new javax.swing.JTextField();
        tksstockbabyhelu = new javax.swing.JTextField();
        tksnamababyhelu = new javax.swing.JTextField();
        checkbabyhelu = new javax.swing.JButton();
        deskdianpelangi = new javax.swing.JPanel();
        jLabel140 = new javax.swing.JLabel();
        kembalideskdianpelangi = new javax.swing.JPanel();
        kembalilevine7 = new javax.swing.JLabel();
        jPanel72 = new javax.swing.JPanel();
        jLabel141 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tksdeskripsidianpelangi = new javax.swing.JTextPane();
        jLabel142 = new javax.swing.JLabel();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        tkswarnadianpelangi = new javax.swing.JTextField();
        tksbahandianpelangi = new javax.swing.JTextField();
        tkshargadianpelangi = new javax.swing.JTextField();
        tksukurandianpelangi = new javax.swing.JTextField();
        tksstockdianpelangi = new javax.swing.JTextField();
        tksnamadianpelangi = new javax.swing.JTextField();
        checkdianpelangi = new javax.swing.JButton();
        deskhaura = new javax.swing.JPanel();
        jLabel148 = new javax.swing.JLabel();
        kembalideskhaura = new javax.swing.JPanel();
        kembalilevine8 = new javax.swing.JLabel();
        jPanel73 = new javax.swing.JPanel();
        jLabel149 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        tksdeskripsihaura = new javax.swing.JTextPane();
        jLabel150 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        tkswarnahaura = new javax.swing.JTextField();
        tksbahanhaura = new javax.swing.JTextField();
        tkshargahaura = new javax.swing.JTextField();
        tksukuranhaura = new javax.swing.JTextField();
        tksstockhaura = new javax.swing.JTextField();
        tksnamahaura = new javax.swing.JTextField();
        checkhaura = new javax.swing.JButton();
        deskmelika = new javax.swing.JPanel();
        jLabel156 = new javax.swing.JLabel();
        kembalideskmelika = new javax.swing.JPanel();
        kembalilevine9 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        jLabel157 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        tksdeskripsimelika = new javax.swing.JTextPane();
        jLabel158 = new javax.swing.JLabel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jLabel163 = new javax.swing.JLabel();
        tkswarnamelika = new javax.swing.JTextField();
        tksbahanmelika = new javax.swing.JTextField();
        tkshargamelika = new javax.swing.JTextField();
        tksukuranmelika = new javax.swing.JTextField();
        tksstockmelika = new javax.swing.JTextField();
        tksnamamelika = new javax.swing.JTextField();
        checkmelika = new javax.swing.JButton();
        deskmonel = new javax.swing.JPanel();
        jLabel164 = new javax.swing.JLabel();
        kembalideskmonel = new javax.swing.JPanel();
        kembalilevine10 = new javax.swing.JLabel();
        jPanel75 = new javax.swing.JPanel();
        jLabel165 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        tksdeskripsimonel = new javax.swing.JTextPane();
        jLabel166 = new javax.swing.JLabel();
        jLabel167 = new javax.swing.JLabel();
        jLabel168 = new javax.swing.JLabel();
        jLabel169 = new javax.swing.JLabel();
        jLabel170 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        tkswarnamonel = new javax.swing.JTextField();
        tksbahanmonel = new javax.swing.JTextField();
        tkshargamonel = new javax.swing.JTextField();
        tksukuranmonel = new javax.swing.JTextField();
        tksstockmonel = new javax.swing.JTextField();
        tksnamamonel = new javax.swing.JTextField();
        checkmonel = new javax.swing.JButton();
        deskrianmiranda = new javax.swing.JPanel();
        jLabel172 = new javax.swing.JLabel();
        kembalideskrianmiranda = new javax.swing.JPanel();
        kembalilevine11 = new javax.swing.JLabel();
        jPanel76 = new javax.swing.JPanel();
        jLabel173 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        tksdeskripsimiranda = new javax.swing.JTextPane();
        jLabel174 = new javax.swing.JLabel();
        jLabel175 = new javax.swing.JLabel();
        jLabel176 = new javax.swing.JLabel();
        jLabel177 = new javax.swing.JLabel();
        jLabel178 = new javax.swing.JLabel();
        jLabel179 = new javax.swing.JLabel();
        tkswarnamiranda = new javax.swing.JTextField();
        tksbahanmiranda = new javax.swing.JTextField();
        tkshargamiranda = new javax.swing.JTextField();
        tksukuranmiranda = new javax.swing.JTextField();
        tksstockmiranda = new javax.swing.JTextField();
        tksnamamiranda = new javax.swing.JTextField();
        checkmiranda = new javax.swing.JButton();
        desktuneeca = new javax.swing.JPanel();
        jLabel180 = new javax.swing.JLabel();
        kembalidesktuneeca = new javax.swing.JPanel();
        kembalilevine12 = new javax.swing.JLabel();
        jPanel77 = new javax.swing.JPanel();
        jLabel181 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        tksdeskripsituneeca = new javax.swing.JTextPane();
        jLabel182 = new javax.swing.JLabel();
        jLabel183 = new javax.swing.JLabel();
        jLabel184 = new javax.swing.JLabel();
        jLabel185 = new javax.swing.JLabel();
        jLabel186 = new javax.swing.JLabel();
        jLabel187 = new javax.swing.JLabel();
        tkswarnatuneeca = new javax.swing.JTextField();
        tksbahantuneeca = new javax.swing.JTextField();
        tkshargatuneeca = new javax.swing.JTextField();
        tksukurantuneeca = new javax.swing.JTextField();
        tksstocktuneeca = new javax.swing.JTextField();
        tksnamatuneeca = new javax.swing.JTextField();
        checktuneeca = new javax.swing.JButton();
        deskzmnow = new javax.swing.JPanel();
        jLabel188 = new javax.swing.JLabel();
        kembalideskzmnow = new javax.swing.JPanel();
        kembalilevine13 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        jLabel189 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        tksdeskripsizmnow = new javax.swing.JTextPane();
        jLabel190 = new javax.swing.JLabel();
        jLabel191 = new javax.swing.JLabel();
        jLabel192 = new javax.swing.JLabel();
        jLabel193 = new javax.swing.JLabel();
        jLabel194 = new javax.swing.JLabel();
        jLabel195 = new javax.swing.JLabel();
        tkswarnazmnow = new javax.swing.JTextField();
        tksbahanzmnow = new javax.swing.JTextField();
        tkshargazmnow = new javax.swing.JTextField();
        tksukuranzmnow = new javax.swing.JTextField();
        tksstockzmnow = new javax.swing.JTextField();
        tksnamazmnow = new javax.swing.JTextField();
        checkzmnow = new javax.swing.JButton();
        deskzoya = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        kembalideskzoya = new javax.swing.JPanel();
        kembalilevine5 = new javax.swing.JLabel();
        jPanel38 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tksdeskripsizoya = new javax.swing.JTextPane();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        tkswarnazoya = new javax.swing.JTextField();
        tksbahanzoya = new javax.swing.JTextField();
        tkshargazoya = new javax.swing.JTextField();
        tksukuranzoya = new javax.swing.JTextField();
        tksstockzoya = new javax.swing.JTextField();
        tksnamazoya = new javax.swing.JTextField();
        checkzoya = new javax.swing.JButton();
        deskumama = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        kembalideskumama = new javax.swing.JPanel();
        kembalilevine4 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tksdeskripsiumama = new javax.swing.JTextPane();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        tkswarnaumama = new javax.swing.JTextField();
        tksbahanumama = new javax.swing.JTextField();
        tkshargaumama = new javax.swing.JTextField();
        tksukuranumama = new javax.swing.JTextField();
        tksstockumama = new javax.swing.JTextField();
        tksnamaumama = new javax.swing.JTextField();
        checkumama = new javax.swing.JButton();
        deskshafira = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        kembalideskshafira = new javax.swing.JPanel();
        kembalilevine3 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tksdeskripsishafira = new javax.swing.JTextPane();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        tkswarnashafira = new javax.swing.JTextField();
        tksbahanshafira = new javax.swing.JTextField();
        tkshargashafira = new javax.swing.JTextField();
        tksukuranshafira = new javax.swing.JTextField();
        tksstockshafira = new javax.swing.JTextField();
        tksnamashafira = new javax.swing.JTextField();
        checkshafira = new javax.swing.JButton();
        deskrabbani = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        kembalideskrabbani = new javax.swing.JPanel();
        kembalilevine2 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tksdeskripsirabbani = new javax.swing.JTextPane();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        tkswarnarabbani = new javax.swing.JTextField();
        tksbahanrabbani = new javax.swing.JTextField();
        tkshargarabbani = new javax.swing.JTextField();
        tksukuranrabbani = new javax.swing.JTextField();
        tksstockrabbani = new javax.swing.JTextField();
        tksnamarabbani = new javax.swing.JTextField();
        checkrabbani = new javax.swing.JButton();
        deskpashmina = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        kembalideskpashmina = new javax.swing.JPanel();
        kembalilevine1 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tksdeskripsipashmina = new javax.swing.JTextPane();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        tkswarnapashmina = new javax.swing.JTextField();
        tksbahanpashmina = new javax.swing.JTextField();
        tkshargapashmina = new javax.swing.JTextField();
        tksukuranpashmina = new javax.swing.JTextField();
        tksstockpashmina = new javax.swing.JTextField();
        tksnamapashmina = new javax.swing.JTextField();
        checkpashmina = new javax.swing.JButton();
        desklevine = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        kembalidesklevine = new javax.swing.JPanel();
        kembalilevine = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tksdeskripsilevine = new javax.swing.JTextPane();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        tkswarnalevine = new javax.swing.JTextField();
        tksbahanlevine = new javax.swing.JTextField();
        tkshargalevine = new javax.swing.JTextField();
        tksukuranlevine = new javax.swing.JTextField();
        tksstocklevine = new javax.swing.JTextField();
        tksnamalevine = new javax.swing.JTextField();
        checklevine = new javax.swing.JButton();
        deskelzata = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        kembalideskelzata = new javax.swing.JPanel();
        kembalidiario1 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tksdeskripsielzata = new javax.swing.JTextPane();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        tkswarnaelzata = new javax.swing.JTextField();
        tksbahanelzata = new javax.swing.JTextField();
        tkshargaelzata = new javax.swing.JTextField();
        tksukuranelzata = new javax.swing.JTextField();
        tksstockelzata = new javax.swing.JTextField();
        tksnamaelzata = new javax.swing.JTextField();
        checkelzata = new javax.swing.JButton();
        deskdiario = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        kembalideskdiario = new javax.swing.JPanel();
        kembalidiario = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tksdeskripsidiario = new javax.swing.JTextPane();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        tkswarnadiario = new javax.swing.JTextField();
        tksbahandiario = new javax.swing.JTextField();
        tkshargadiario = new javax.swing.JTextField();
        tksukurandiario = new javax.swing.JTextField();
        tksstockdiario = new javax.swing.JTextField();
        tksnamadiario = new javax.swing.JTextField();
        checkdiario = new javax.swing.JButton();
        Transaksi = new javax.swing.JPanel();
        jLabel260 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        namatransaksi = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        ukurantransaksi = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        warnatransaksi = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        hargatransaksi = new javax.swing.JTextField();
        jLabel261 = new javax.swing.JLabel();
        jumlahtransaksi = new javax.swing.JTextField();
        jLabel262 = new javax.swing.JLabel();
        totaltransaksi = new javax.swing.JTextField();
        bayar = new javax.swing.JButton();
        hitung = new javax.swing.JButton();
        jLabel263 = new javax.swing.JLabel();
        nominal = new javax.swing.JTextField();
        Validasinominal = new javax.swing.JLabel();
        kembalidesktuneeca1 = new javax.swing.JPanel();
        kembalibayar = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel91Layout = new javax.swing.GroupLayout(jPanel91);
        jPanel91.setLayout(jPanel91Layout);
        jPanel91Layout.setHorizontalGroup(
            jPanel91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel91Layout.setVerticalGroup(
            jPanel91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(109, 33, 79));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel2.setBackground(new java.awt.Color(179, 55, 113));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.gray, java.awt.Color.lightGray, java.awt.Color.gray, java.awt.Color.lightGray));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Lenovo\\Downloads\\ikonmikasa.png")); // NOI18N

        jLabel2.setFont(new java.awt.Font("Sketsa Ramadhan", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(248, 239, 186));
        jLabel2.setText("z a s y a v l o");

        btnhome.setBackground(new java.awt.Color(248, 239, 186));
        btnhome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnhomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnhomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnhomeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnhomeMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnhomeMouseReleased(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(44, 58, 71));
        jLabel3.setText("Home");

        javax.swing.GroupLayout btnhomeLayout = new javax.swing.GroupLayout(btnhome);
        btnhome.setLayout(btnhomeLayout);
        btnhomeLayout.setHorizontalGroup(
            btnhomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnhomeLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnhomeLayout.setVerticalGroup(
            btnhomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
        );

        btnkategori.setBackground(new java.awt.Color(248, 239, 186));
        btnkategori.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnkategoriMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnkategoriMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnkategoriMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnkategoriMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnkategoriMouseReleased(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(44, 58, 71));
        jLabel4.setText("Kategori");

        javax.swing.GroupLayout btnkategoriLayout = new javax.swing.GroupLayout(btnkategori);
        btnkategori.setLayout(btnkategoriLayout);
        btnkategoriLayout.setHorizontalGroup(
            btnkategoriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnkategoriLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnkategoriLayout.setVerticalGroup(
            btnkategoriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
        );

        logout.setBackground(new java.awt.Color(248, 239, 186));
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                logoutMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logoutMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                logoutMouseReleased(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(44, 58, 71));
        jLabel6.setText("Logout");

        javax.swing.GroupLayout logoutLayout = new javax.swing.GroupLayout(logout);
        logout.setLayout(logoutLayout);
        logoutLayout.setHorizontalGroup(
            logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        logoutLayout.setVerticalGroup(
            logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
        );

        namapengguna.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 12)); // NOI18N
        namapengguna.setForeground(new java.awt.Color(248, 239, 186));
        namapengguna.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(46, 46, 46))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(namapengguna, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                    .addComponent(btnkategori, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnhome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(namapengguna, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(12, 12, 12)
                .addComponent(btnhome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnkategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );

        mainpanel.setBackground(new java.awt.Color(179, 55, 113));
        mainpanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.gray, java.awt.Color.lightGray, java.awt.Color.gray, java.awt.Color.lightGray));
        mainpanel.setLayout(new java.awt.CardLayout());

        homepanel.setBackground(new java.awt.Color(248, 239, 186));
        homepanel.setPreferredSize(new java.awt.Dimension(700, 400));

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(109, 33, 79));
        jLabel7.setText("MENU - HOME");

        jPanel4.setBackground(new java.awt.Color(179, 55, 113));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 61, Short.MAX_VALUE)
        );

        jLabel265.setBackground(new java.awt.Color(248, 239, 186));
        jLabel265.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 12)); // NOI18N
        jLabel265.setForeground(new java.awt.Color(248, 239, 186));
        jLabel265.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel265.setText("PROMO");

        jLabel266.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 12)); // NOI18N
        jLabel266.setForeground(new java.awt.Color(248, 239, 186));
        jLabel266.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel266.setText("Mukena Monel");

        jButton1.setText("Lihat Selengkapnya");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel265, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel266, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel265)
                .addGap(7, 7, 7)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel266)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(179, 55, 113));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 61, Short.MAX_VALUE)
        );

        jLabel267.setBackground(new java.awt.Color(248, 239, 186));
        jLabel267.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 12)); // NOI18N
        jLabel267.setForeground(new java.awt.Color(248, 239, 186));
        jLabel267.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel267.setText("PROMO");

        jLabel268.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 12)); // NOI18N
        jLabel268.setForeground(new java.awt.Color(248, 239, 186));
        jLabel268.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel268.setText("Baju Al Ghani");

        jButton3.setText("Lihat Selengkapnya");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel267, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 27, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel268, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel267)
                .addGap(7, 7, 7)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel268)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jPanel96.setBackground(new java.awt.Color(179, 55, 113));
        jPanel96.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        javax.swing.GroupLayout jPanel97Layout = new javax.swing.GroupLayout(jPanel97);
        jPanel97.setLayout(jPanel97Layout);
        jPanel97Layout.setHorizontalGroup(
            jPanel97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel97Layout.setVerticalGroup(
            jPanel97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 61, Short.MAX_VALUE)
        );

        jLabel275.setBackground(new java.awt.Color(248, 239, 186));
        jLabel275.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 12)); // NOI18N
        jLabel275.setForeground(new java.awt.Color(248, 239, 186));
        jLabel275.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel275.setText("PROMO");

        jLabel276.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 12)); // NOI18N
        jLabel276.setForeground(new java.awt.Color(248, 239, 186));
        jLabel276.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel276.setText("Mukena Baby helu");

        jButton7.setText("Lihat Selengkapnya");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel96Layout = new javax.swing.GroupLayout(jPanel96);
        jPanel96.setLayout(jPanel96Layout);
        jPanel96Layout.setHorizontalGroup(
            jPanel96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel96Layout.createSequentialGroup()
                .addGroup(jPanel96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel96Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel275, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel96Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel276, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel97, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel96Layout.setVerticalGroup(
            jPanel96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel96Layout.createSequentialGroup()
                .addComponent(jLabel275)
                .addGap(7, 7, 7)
                .addComponent(jPanel97, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel276)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jPanel98.setBackground(new java.awt.Color(179, 55, 113));
        jPanel98.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        javax.swing.GroupLayout jPanel99Layout = new javax.swing.GroupLayout(jPanel99);
        jPanel99.setLayout(jPanel99Layout);
        jPanel99Layout.setHorizontalGroup(
            jPanel99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel99Layout.setVerticalGroup(
            jPanel99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 61, Short.MAX_VALUE)
        );

        jLabel277.setBackground(new java.awt.Color(248, 239, 186));
        jLabel277.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 12)); // NOI18N
        jLabel277.setForeground(new java.awt.Color(248, 239, 186));
        jLabel277.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel277.setText("PROMO");

        jLabel278.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 12)); // NOI18N
        jLabel278.setForeground(new java.awt.Color(248, 239, 186));
        jLabel278.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel278.setText("Hijab Rabbani");

        jButton8.setText("Lihat Selengkapnya");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel98Layout = new javax.swing.GroupLayout(jPanel98);
        jPanel98.setLayout(jPanel98Layout);
        jPanel98Layout.setHorizontalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel98Layout.createSequentialGroup()
                .addGroup(jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel98Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel277, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel98Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel278, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(jPanel99, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel98Layout.setVerticalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel98Layout.createSequentialGroup()
                .addComponent(jLabel277)
                .addGap(7, 7, 7)
                .addComponent(jPanel99, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel278)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout homepanelLayout = new javax.swing.GroupLayout(homepanel);
        homepanel.setLayout(homepanelLayout);
        homepanelLayout.setHorizontalGroup(
            homepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homepanelLayout.createSequentialGroup()
                .addContainerGap(178, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(175, 175, 175))
            .addGroup(homepanelLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(homepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(jPanel96, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        homepanelLayout.setVerticalGroup(
            homepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homepanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(homepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel96, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(homepanelLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(homepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jPanel98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        mainpanel.add(homepanel, "card2");

        kategori.setBackground(new java.awt.Color(254, 164, 127));
        kategori.setForeground(new java.awt.Color(253, 114, 114));
        kategori.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        kategori.setPreferredSize(new java.awt.Dimension(700, 400));

        jLabel8.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(109, 33, 79));
        jLabel8.setText("MENU - KATEGORI");

        jPanel3.setBackground(new java.awt.Color(179, 55, 113));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        jPanel12.setBackground(new java.awt.Color(248, 239, 186));

        Hijab.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        Hijab.setForeground(new java.awt.Color(109, 33, 79));
        Hijab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Hijab.setText("Hijab");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(Hijab, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(147, Short.MAX_VALUE)
                .addComponent(Hijab)
                .addContainerGap())
        );

        pilihhijab.setText("Pilih");
        pilihhijab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pilihhijabMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pilihhijabMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pilihhijabMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pilihhijabMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pilihhijabMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pilihhijab, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5)
                .addComponent(pilihhijab))
        );

        jPanel10.setBackground(new java.awt.Color(179, 55, 113));
        jPanel10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        jPanel13.setBackground(new java.awt.Color(248, 239, 186));

        Hijab1.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        Hijab1.setForeground(new java.awt.Color(109, 33, 79));
        Hijab1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Hijab1.setText("Baju Muslimah");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(Hijab1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(147, Short.MAX_VALUE)
                .addComponent(Hijab1)
                .addContainerGap())
        );

        pilihbaju.setText("Pilih");
        pilihbaju.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pilihbajuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pilihbajuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pilihbajuMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pilihbajuMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pilihbajuMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pilihbaju, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5)
                .addComponent(pilihbaju))
        );

        jPanel11.setBackground(new java.awt.Color(179, 55, 113));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        jPanel14.setBackground(new java.awt.Color(248, 239, 186));

        Hijab2.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        Hijab2.setForeground(new java.awt.Color(109, 33, 79));
        Hijab2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Hijab2.setText("Mukena");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(Hijab2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(147, Short.MAX_VALUE)
                .addComponent(Hijab2)
                .addContainerGap())
        );

        pilihmukena.setText("Pilih");
        pilihmukena.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pilihmukenaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pilihmukenaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pilihmukenaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pilihmukenaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pilihmukenaMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(pilihmukena, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5)
                .addComponent(pilihmukena))
        );

        javax.swing.GroupLayout kategoriLayout = new javax.swing.GroupLayout(kategori);
        kategori.setLayout(kategoriLayout);
        kategoriLayout.setHorizontalGroup(
            kategoriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategoriLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kategoriLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(151, 151, 151))
        );
        kategoriLayout.setVerticalGroup(
            kategoriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategoriLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(48, 48, 48)
                .addGroup(kategoriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(94, Short.MAX_VALUE))
        );

        mainpanel.add(kategori, "card3");

        kategorihijab.setBackground(new java.awt.Color(254, 164, 127));

        jLabel10.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(109, 33, 79));
        jLabel10.setText("KATEGORI - HIJAB");

        kembalihijab.setBackground(new java.awt.Color(248, 239, 186));
        kembalihijab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalihijab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalihijabMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalihijabMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalihijabMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalihijabMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalihijabMouseReleased(evt);
            }
        });

        jLabel15.setBackground(new java.awt.Color(248, 239, 186));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalihijabLayout = new javax.swing.GroupLayout(kembalihijab);
        kembalihijab.setLayout(kembalihijabLayout);
        kembalihijabLayout.setHorizontalGroup(
            kembalihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );
        kembalihijabLayout.setVerticalGroup(
            kembalihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel15.setBackground(new java.awt.Color(179, 55, 113));

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel16.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(248, 239, 186));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Hijab Diario");

        btndiario.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btndiario.setText("Lihat");
        btndiario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndiarioActionPerformed(evt);
            }
        });

        jLabel18.setForeground(new java.awt.Color(248, 239, 186));
        jLabel18.setText("Rp. 15.000");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btndiario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel18)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btndiario)
                .addGap(7, 7, 7))
        );

        jPanel17.setBackground(new java.awt.Color(179, 55, 113));

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel17.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(248, 239, 186));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("Hijab Elzata");

        btnelzata.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnelzata.setText("Lihat");
        btnelzata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnelzataActionPerformed(evt);
            }
        });

        jLabel19.setForeground(new java.awt.Color(248, 239, 186));
        jLabel19.setText("Rp. 30.000");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnelzata, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel19)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnelzata)
                .addGap(7, 7, 7))
        );

        jPanel19.setBackground(new java.awt.Color(179, 55, 113));

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel20.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(248, 239, 186));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Hijab Pashmina");

        btnpashmina.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnpashmina.setText("Lihat");
        btnpashmina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpashminaActionPerformed(evt);
            }
        });

        jLabel21.setForeground(new java.awt.Color(248, 239, 186));
        jLabel21.setText("Rp. 40.000");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnpashmina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel19Layout.createSequentialGroup()
                                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel21)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnpashmina)
                .addGap(7, 7, 7))
        );

        jPanel21.setBackground(new java.awt.Color(179, 55, 113));

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel22.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(248, 239, 186));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("Hijab Rabbani");

        btnrabbani.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnrabbani.setText("Lihat");
        btnrabbani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrabbaniActionPerformed(evt);
            }
        });

        jLabel23.setForeground(new java.awt.Color(248, 239, 186));
        jLabel23.setText("Rp. 10.000");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnrabbani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel23)
                .addGap(26, 26, 26))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnrabbani)
                .addGap(7, 7, 7))
        );

        jPanel23.setBackground(new java.awt.Color(179, 55, 113));

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel24.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(248, 239, 186));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("Hijab Levine");

        btnlevine.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnlevine.setText("Lihat");
        btnlevine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlevineActionPerformed(evt);
            }
        });

        jLabel25.setForeground(new java.awt.Color(248, 239, 186));
        jLabel25.setText("Rp. 25.000");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnlevine, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel25)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnlevine)
                .addGap(7, 7, 7))
        );

        jPanel25.setBackground(new java.awt.Color(179, 55, 113));

        jPanel26.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel26.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(248, 239, 186));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Hijab Umama");

        btnumama.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnumama.setText("Lihat");
        btnumama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnumamaActionPerformed(evt);
            }
        });

        jLabel27.setForeground(new java.awt.Color(248, 239, 186));
        jLabel27.setText("Rp. 50.000");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnumama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel27)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnumama)
                .addGap(7, 7, 7))
        );

        jPanel27.setBackground(new java.awt.Color(179, 55, 113));

        jPanel28.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel28.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(248, 239, 186));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Hijab Shafira");

        btnshafira.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnshafira.setText("Lihat");
        btnshafira.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnshafiraActionPerformed(evt);
            }
        });

        jLabel29.setForeground(new java.awt.Color(248, 239, 186));
        jLabel29.setText("Rp. 20.000");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnshafira, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel27Layout.createSequentialGroup()
                                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel29)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnshafira)
                .addGap(7, 7, 7))
        );

        jPanel29.setBackground(new java.awt.Color(179, 55, 113));

        jPanel30.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel30.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(248, 239, 186));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Hijab Zoya");

        btnzoya.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnzoya.setText("Lihat");
        btnzoya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnzoyaActionPerformed(evt);
            }
        });

        jLabel31.setForeground(new java.awt.Color(248, 239, 186));
        jLabel31.setText("Rp. 35.000");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnzoya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel31)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnzoya)
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout kategorihijabLayout = new javax.swing.GroupLayout(kategorihijab);
        kategorihijab.setLayout(kategorihijabLayout);
        kategorihijabLayout.setHorizontalGroup(
            kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategorihijabLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kembalihijab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(119, 119, 119)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(kategorihijabLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(kategorihijabLayout.createSequentialGroup()
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(kategorihijabLayout.createSequentialGroup()
                        .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kategorihijabLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(kategorihijabLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        kategorihijabLayout.setVerticalGroup(
            kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategorihijabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(kategorihijabLayout.createSequentialGroup()
                        .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(kembalihijab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(kategorihijabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        mainpanel.add(kategorihijab, "card5");

        kategoribaju.setBackground(new java.awt.Color(254, 164, 127));

        jLabel96.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(109, 33, 79));
        jLabel96.setText("KATEGORI - BAJU");

        kembalibaju.setBackground(new java.awt.Color(248, 239, 186));
        kembalibaju.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalibaju.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalibajuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalibajuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalibajuMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalibajuMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalibajuMouseReleased(evt);
            }
        });

        jLabel97.setBackground(new java.awt.Color(248, 239, 186));
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel97.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalibajuLayout = new javax.swing.GroupLayout(kembalibaju);
        kembalibaju.setLayout(kembalibajuLayout);
        kembalibajuLayout.setHorizontalGroup(
            kembalibajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel97, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );
        kembalibajuLayout.setVerticalGroup(
            kembalibajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel97, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel39.setBackground(new java.awt.Color(179, 55, 113));

        jPanel40.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel98.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel98.setForeground(new java.awt.Color(248, 239, 186));
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel98.setText("Monel");

        btnmonel.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnmonel.setText("Lihat");
        btnmonel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmonelActionPerformed(evt);
            }
        });

        jLabel99.setForeground(new java.awt.Color(248, 239, 186));
        jLabel99.setText("Rp. 215.000");

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel98, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnmonel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel39Layout.createSequentialGroup()
                                .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel99)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel98)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel99)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnmonel)
                .addGap(7, 7, 7))
        );

        jPanel41.setBackground(new java.awt.Color(179, 55, 113));

        jPanel42.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel100.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel100.setForeground(new java.awt.Color(248, 239, 186));
        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel100.setText("Ria Miranda");

        btnriamiranda.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnriamiranda.setText("Lihat");
        btnriamiranda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnriamirandaActionPerformed(evt);
            }
        });

        jLabel101.setForeground(new java.awt.Color(248, 239, 186));
        jLabel101.setText("Rp. 230.000");

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel100, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnriamiranda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel41Layout.createSequentialGroup()
                                .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel101)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel100)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel101)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnriamiranda)
                .addGap(7, 7, 7))
        );

        jPanel43.setBackground(new java.awt.Color(179, 55, 113));

        jPanel44.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel102.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel102.setForeground(new java.awt.Color(248, 239, 186));
        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel102.setText("Haura");

        btnhaura.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnhaura.setText("Lihat");
        btnhaura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhauraActionPerformed(evt);
            }
        });

        jLabel103.setForeground(new java.awt.Color(248, 239, 186));
        jLabel103.setText("Rp. 240.000");

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel102, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnhaura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel43Layout.createSequentialGroup()
                                .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel103)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnhaura)
                .addGap(7, 7, 7))
        );

        jPanel45.setBackground(new java.awt.Color(179, 55, 113));

        jPanel46.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel104.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(248, 239, 186));
        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel104.setText("Babyhelu");

        btnbabyhelu.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnbabyhelu.setText("Lihat");
        btnbabyhelu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbabyheluActionPerformed(evt);
            }
        });

        jLabel105.setForeground(new java.awt.Color(248, 239, 186));
        jLabel105.setText("Rp. 210.000");

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel104, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnbabyhelu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel45Layout.createSequentialGroup()
                                .addComponent(jPanel46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel45Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel105)
                .addGap(26, 26, 26))
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel104)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel105)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnbabyhelu)
                .addGap(7, 7, 7))
        );

        jPanel47.setBackground(new java.awt.Color(179, 55, 113));

        jPanel48.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel48Layout = new javax.swing.GroupLayout(jPanel48);
        jPanel48.setLayout(jPanel48Layout);
        jPanel48Layout.setHorizontalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel48Layout.setVerticalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel106.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel106.setForeground(new java.awt.Color(248, 239, 186));
        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel106.setText("Dian Pelangi");

        btndianpelangi.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btndianpelangi.setText("Lihat");
        btndianpelangi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndianpelangiActionPerformed(evt);
            }
        });

        jLabel107.setForeground(new java.awt.Color(248, 239, 186));
        jLabel107.setText("Rp. 225.000");

        javax.swing.GroupLayout jPanel47Layout = new javax.swing.GroupLayout(jPanel47);
        jPanel47.setLayout(jPanel47Layout);
        jPanel47Layout.setHorizontalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel47Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel47Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel106, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel47Layout.createSequentialGroup()
                        .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btndianpelangi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel47Layout.createSequentialGroup()
                                .addComponent(jPanel48, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel47Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel107)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel47Layout.setVerticalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel47Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel48, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel106)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel107)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btndianpelangi)
                .addGap(7, 7, 7))
        );

        jPanel49.setBackground(new java.awt.Color(179, 55, 113));

        jPanel50.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel50Layout = new javax.swing.GroupLayout(jPanel50);
        jPanel50.setLayout(jPanel50Layout);
        jPanel50Layout.setHorizontalGroup(
            jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel50Layout.setVerticalGroup(
            jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel108.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel108.setForeground(new java.awt.Color(248, 239, 186));
        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel108.setText("ZMNow");

        btnzmnow.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnzmnow.setText("Lihat");
        btnzmnow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnzmnowActionPerformed(evt);
            }
        });

        jLabel109.setForeground(new java.awt.Color(248, 239, 186));
        jLabel109.setText("Rp. 250.000");

        javax.swing.GroupLayout jPanel49Layout = new javax.swing.GroupLayout(jPanel49);
        jPanel49.setLayout(jPanel49Layout);
        jPanel49Layout.setHorizontalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel49Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel108, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnzmnow, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel49Layout.createSequentialGroup()
                                .addComponent(jPanel50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel49Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel109)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel49Layout.setVerticalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel49Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel108)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel109)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnzmnow)
                .addGap(7, 7, 7))
        );

        jPanel51.setBackground(new java.awt.Color(179, 55, 113));

        jPanel52.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel52Layout = new javax.swing.GroupLayout(jPanel52);
        jPanel52.setLayout(jPanel52Layout);
        jPanel52Layout.setHorizontalGroup(
            jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel52Layout.setVerticalGroup(
            jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel110.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(248, 239, 186));
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("Tuneeca");

        btntuneeca.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btntuneeca.setText("Lihat");
        btntuneeca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntuneecaActionPerformed(evt);
            }
        });

        jLabel111.setForeground(new java.awt.Color(248, 239, 186));
        jLabel111.setText("Rp. 220.000");

        javax.swing.GroupLayout jPanel51Layout = new javax.swing.GroupLayout(jPanel51);
        jPanel51.setLayout(jPanel51Layout);
        jPanel51Layout.setHorizontalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel51Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel110, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel51Layout.createSequentialGroup()
                        .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btntuneeca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel51Layout.createSequentialGroup()
                                .addComponent(jPanel52, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel111)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel51Layout.setVerticalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel52, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel110)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel111)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btntuneeca)
                .addGap(7, 7, 7))
        );

        jPanel53.setBackground(new java.awt.Color(179, 55, 113));

        jPanel54.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel54Layout = new javax.swing.GroupLayout(jPanel54);
        jPanel54.setLayout(jPanel54Layout);
        jPanel54Layout.setHorizontalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel54Layout.setVerticalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel112.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel112.setForeground(new java.awt.Color(248, 239, 186));
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel112.setText("Melika");

        btnmelika.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnmelika.setText("Lihat");
        btnmelika.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmelikaActionPerformed(evt);
            }
        });

        jLabel113.setForeground(new java.awt.Color(248, 239, 186));
        jLabel113.setText("Rp. 235.000");

        javax.swing.GroupLayout jPanel53Layout = new javax.swing.GroupLayout(jPanel53);
        jPanel53.setLayout(jPanel53Layout);
        jPanel53Layout.setHorizontalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel53Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel112, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel53Layout.createSequentialGroup()
                        .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnmelika, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel53Layout.createSequentialGroup()
                                .addComponent(jPanel54, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel113)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel53Layout.setVerticalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel54, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel112)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel113)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnmelika)
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout kategoribajuLayout = new javax.swing.GroupLayout(kategoribaju);
        kategoribaju.setLayout(kategoribajuLayout);
        kategoribajuLayout.setHorizontalGroup(
            kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategoribajuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kembalibaju, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(119, 119, 119)
                .addComponent(jLabel96)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(kategoribajuLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(kategoribajuLayout.createSequentialGroup()
                        .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(kategoribajuLayout.createSequentialGroup()
                        .addComponent(jPanel51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel49, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kategoribajuLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                        .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(kategoribajuLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel53, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        kategoribajuLayout.setVerticalGroup(
            kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategoribajuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(kategoribajuLayout.createSequentialGroup()
                        .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(kembalibaju, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel96, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(kategoribajuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel49, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel53, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        mainpanel.add(kategoribaju, "card5");

        kategorimukena.setBackground(new java.awt.Color(254, 164, 127));

        jLabel114.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel114.setForeground(new java.awt.Color(109, 33, 79));
        jLabel114.setText("KATEGORI - MUKENA");

        kembalimukena.setBackground(new java.awt.Color(248, 239, 186));
        kembalimukena.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalimukena.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalimukenaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalimukenaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalimukenaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalimukenaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalimukenaMouseReleased(evt);
            }
        });

        jLabel115.setBackground(new java.awt.Color(248, 239, 186));
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel115.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalimukenaLayout = new javax.swing.GroupLayout(kembalimukena);
        kembalimukena.setLayout(kembalimukenaLayout);
        kembalimukenaLayout.setHorizontalGroup(
            kembalimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel115, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );
        kembalimukenaLayout.setVerticalGroup(
            kembalimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel115, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel55.setBackground(new java.awt.Color(179, 55, 113));

        jPanel56.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel56Layout = new javax.swing.GroupLayout(jPanel56);
        jPanel56.setLayout(jPanel56Layout);
        jPanel56Layout.setHorizontalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel56Layout.setVerticalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel116.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel116.setForeground(new java.awt.Color(248, 239, 186));
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("Halima");

        btnhalima.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnhalima.setText("Lihat");
        btnhalima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhalimaActionPerformed(evt);
            }
        });

        jLabel117.setForeground(new java.awt.Color(248, 239, 186));
        jLabel117.setText("Rp. 115.000");

        javax.swing.GroupLayout jPanel55Layout = new javax.swing.GroupLayout(jPanel55);
        jPanel55.setLayout(jPanel55Layout);
        jPanel55Layout.setHorizontalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel55Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel116, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnhalima, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel55Layout.createSequentialGroup()
                                .addComponent(jPanel56, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel55Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel117)
                .addGap(23, 23, 23))
        );
        jPanel55Layout.setVerticalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel55Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel56, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel116)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel117)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnhalima)
                .addGap(7, 7, 7))
        );

        jPanel57.setBackground(new java.awt.Color(179, 55, 113));

        jPanel58.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel58Layout = new javax.swing.GroupLayout(jPanel58);
        jPanel58.setLayout(jPanel58Layout);
        jPanel58Layout.setHorizontalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel58Layout.setVerticalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel118.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel118.setForeground(new java.awt.Color(248, 239, 186));
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel118.setText("Azzura");

        btnazzura.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnazzura.setText("Lihat");
        btnazzura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnazzuraActionPerformed(evt);
            }
        });

        jLabel119.setForeground(new java.awt.Color(248, 239, 186));
        jLabel119.setText("Rp. 130.000");

        javax.swing.GroupLayout jPanel57Layout = new javax.swing.GroupLayout(jPanel57);
        jPanel57.setLayout(jPanel57Layout);
        jPanel57Layout.setHorizontalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel57Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel57Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel118, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel57Layout.createSequentialGroup()
                        .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnazzura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel57Layout.createSequentialGroup()
                                .addComponent(jPanel58, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel57Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel119)
                .addGap(23, 23, 23))
        );
        jPanel57Layout.setVerticalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel57Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel58, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel118)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel119)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnazzura)
                .addGap(7, 7, 7))
        );

        jPanel59.setBackground(new java.awt.Color(179, 55, 113));

        jPanel60.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel60Layout = new javax.swing.GroupLayout(jPanel60);
        jPanel60.setLayout(jPanel60Layout);
        jPanel60Layout.setHorizontalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel60Layout.setVerticalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel120.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel120.setForeground(new java.awt.Color(248, 239, 186));
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("Tazbiya");

        btntazbiya.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btntazbiya.setText("Lihat");
        btntazbiya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntazbiyaActionPerformed(evt);
            }
        });

        jLabel121.setForeground(new java.awt.Color(248, 239, 186));
        jLabel121.setText("Rp. 140.000");

        javax.swing.GroupLayout jPanel59Layout = new javax.swing.GroupLayout(jPanel59);
        jPanel59.setLayout(jPanel59Layout);
        jPanel59Layout.setHorizontalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel59Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel59Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel120, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel59Layout.createSequentialGroup()
                        .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btntazbiya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel59Layout.createSequentialGroup()
                                .addComponent(jPanel60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel59Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel121)
                .addGap(23, 23, 23))
        );
        jPanel59Layout.setVerticalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel59Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel120)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel121)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btntazbiya)
                .addGap(7, 7, 7))
        );

        jPanel61.setBackground(new java.awt.Color(179, 55, 113));

        jPanel62.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel62Layout = new javax.swing.GroupLayout(jPanel62);
        jPanel62.setLayout(jPanel62Layout);
        jPanel62Layout.setHorizontalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel62Layout.setVerticalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel122.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel122.setForeground(new java.awt.Color(248, 239, 186));
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("Al Gani");

        btnalgani.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnalgani.setText("Lihat");
        btnalgani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnalganiActionPerformed(evt);
            }
        });

        jLabel123.setForeground(new java.awt.Color(248, 239, 186));
        jLabel123.setText("Rp. 110.000");

        javax.swing.GroupLayout jPanel61Layout = new javax.swing.GroupLayout(jPanel61);
        jPanel61.setLayout(jPanel61Layout);
        jPanel61Layout.setHorizontalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel61Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel122, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel61Layout.createSequentialGroup()
                        .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnalgani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel61Layout.createSequentialGroup()
                                .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel61Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel123)
                .addGap(26, 26, 26))
        );
        jPanel61Layout.setVerticalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel122)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel123)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnalgani)
                .addGap(7, 7, 7))
        );

        jPanel63.setBackground(new java.awt.Color(179, 55, 113));

        jPanel64.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel64Layout = new javax.swing.GroupLayout(jPanel64);
        jPanel64.setLayout(jPanel64Layout);
        jPanel64Layout.setHorizontalGroup(
            jPanel64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel64Layout.setVerticalGroup(
            jPanel64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel124.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel124.setForeground(new java.awt.Color(248, 239, 186));
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("Tatuis");

        btntatuis.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btntatuis.setText("Lihat");
        btntatuis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntatuisActionPerformed(evt);
            }
        });

        jLabel125.setForeground(new java.awt.Color(248, 239, 186));
        jLabel125.setText("Rp. 125.000");

        javax.swing.GroupLayout jPanel63Layout = new javax.swing.GroupLayout(jPanel63);
        jPanel63.setLayout(jPanel63Layout);
        jPanel63Layout.setHorizontalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel63Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel63Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel124, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel63Layout.createSequentialGroup()
                        .addGroup(jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btntatuis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel63Layout.createSequentialGroup()
                                .addComponent(jPanel64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel63Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel125)
                .addGap(23, 23, 23))
        );
        jPanel63Layout.setVerticalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel63Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel124)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel125)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btntatuis)
                .addGap(7, 7, 7))
        );

        jPanel65.setBackground(new java.awt.Color(179, 55, 113));

        jPanel66.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel66Layout = new javax.swing.GroupLayout(jPanel66);
        jPanel66.setLayout(jPanel66Layout);
        jPanel66Layout.setHorizontalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel66Layout.setVerticalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel126.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel126.setForeground(new java.awt.Color(248, 239, 186));
        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("Ghanimi");

        btnghanimi.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnghanimi.setText("Lihat");
        btnghanimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnghanimiActionPerformed(evt);
            }
        });

        jLabel127.setForeground(new java.awt.Color(248, 239, 186));
        jLabel127.setText("Rp. 150.000");

        javax.swing.GroupLayout jPanel65Layout = new javax.swing.GroupLayout(jPanel65);
        jPanel65.setLayout(jPanel65Layout);
        jPanel65Layout.setHorizontalGroup(
            jPanel65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel65Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel65Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel126, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel65Layout.createSequentialGroup()
                        .addGroup(jPanel65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnghanimi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel65Layout.createSequentialGroup()
                                .addComponent(jPanel66, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel65Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel127)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel65Layout.setVerticalGroup(
            jPanel65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel65Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel66, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel126)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel127)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnghanimi)
                .addGap(7, 7, 7))
        );

        jPanel67.setBackground(new java.awt.Color(179, 55, 113));

        jPanel68.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel68Layout = new javax.swing.GroupLayout(jPanel68);
        jPanel68.setLayout(jPanel68Layout);
        jPanel68Layout.setHorizontalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel68Layout.setVerticalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel128.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel128.setForeground(new java.awt.Color(248, 239, 186));
        jLabel128.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel128.setText("Abaya");

        btnabaya.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnabaya.setText("Lihat");
        btnabaya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnabayaActionPerformed(evt);
            }
        });

        jLabel129.setForeground(new java.awt.Color(248, 239, 186));
        jLabel129.setText("Rp. 120.000");

        javax.swing.GroupLayout jPanel67Layout = new javax.swing.GroupLayout(jPanel67);
        jPanel67.setLayout(jPanel67Layout);
        jPanel67Layout.setHorizontalGroup(
            jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel67Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel67Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel128, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel67Layout.createSequentialGroup()
                        .addGroup(jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnabaya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel67Layout.createSequentialGroup()
                                .addComponent(jPanel68, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel67Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel129)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel67Layout.setVerticalGroup(
            jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel67Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel68, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel128)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel129)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnabaya)
                .addGap(7, 7, 7))
        );

        jPanel69.setBackground(new java.awt.Color(179, 55, 113));

        jPanel70.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel70Layout = new javax.swing.GroupLayout(jPanel70);
        jPanel70.setLayout(jPanel70Layout);
        jPanel70Layout.setHorizontalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel70Layout.setVerticalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );

        jLabel130.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jLabel130.setForeground(new java.awt.Color(248, 239, 186));
        jLabel130.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel130.setText("Ponco");

        btnponco.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnponco.setText("Lihat");
        btnponco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnponcoActionPerformed(evt);
            }
        });

        jLabel131.setForeground(new java.awt.Color(248, 239, 186));
        jLabel131.setText("Rp. 135.000");

        javax.swing.GroupLayout jPanel69Layout = new javax.swing.GroupLayout(jPanel69);
        jPanel69.setLayout(jPanel69Layout);
        jPanel69Layout.setHorizontalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel69Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel69Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel130, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel69Layout.createSequentialGroup()
                        .addGroup(jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnponco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel69Layout.createSequentialGroup()
                                .addComponent(jPanel70, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(jPanel69Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel131)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel69Layout.setVerticalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel69Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel70, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel130)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel131)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnponco)
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout kategorimukenaLayout = new javax.swing.GroupLayout(kategorimukena);
        kategorimukena.setLayout(kategorimukenaLayout);
        kategorimukenaLayout.setHorizontalGroup(
            kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategorimukenaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(kategorimukenaLayout.createSequentialGroup()
                        .addComponent(kembalimukena, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(jLabel114))
                    .addGroup(kategorimukenaLayout.createSequentialGroup()
                        .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel55, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(kategorimukenaLayout.createSequentialGroup()
                                .addComponent(jPanel57, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel63, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(kategorimukenaLayout.createSequentialGroup()
                                .addComponent(jPanel67, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel65, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kategorimukenaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                        .addComponent(jPanel59, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(kategorimukenaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel69, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        kategorimukenaLayout.setVerticalGroup(
            kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kategorimukenaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel59, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(kategorimukenaLayout.createSequentialGroup()
                        .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(kembalimukena, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel114, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel55, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel57, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel63, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(kategorimukenaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel65, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel67, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel69, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        mainpanel.add(kategorimukena, "card5");

        deskabaya.setBackground(new java.awt.Color(254, 164, 127));

        jLabel196.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel196.setForeground(new java.awt.Color(109, 33, 79));
        jLabel196.setText("MUKENA - ABAYA");

        kembalideskabaya.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskabaya.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskabaya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskabayaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskabayaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskabayaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskabayaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskabayaMouseReleased(evt);
            }
        });

        kembalilevine14.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N
        kembalilevine14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalilevine14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout kembalideskabayaLayout = new javax.swing.GroupLayout(kembalideskabaya);
        kembalideskabaya.setLayout(kembalideskabayaLayout);
        kembalideskabayaLayout.setHorizontalGroup(
            kembalideskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine14, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskabayaLayout.setVerticalGroup(
            kembalideskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel79.setBackground(new java.awt.Color(248, 239, 186));

        jLabel197.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel197.setText("icon");
        jLabel197.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsiabaya.setEditable(false);
        tksdeskripsiabaya.setBorder(null);
        tksdeskripsiabaya.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane18.setViewportView(tksdeskripsiabaya);

        jLabel198.setForeground(new java.awt.Color(109, 33, 79));
        jLabel198.setText("Nama ");

        jLabel199.setText("Bahan ");

        jLabel200.setText("Warna");

        jLabel201.setText("Harga");

        jLabel202.setText("Ukuran");

        jLabel203.setText("Stock");

        tkswarnaabaya.setEditable(false);

        tksbahanabaya.setEditable(false);

        tkshargaabaya.setEditable(false);

        tksukuranabaya.setEditable(false);

        tksstockabaya.setEditable(false);

        tksnamaabaya.setEditable(false);

        checkabaya.setText("Check out");
        checkabaya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkabayaActionPerformed(evt);
            }
        });

        jButton2.setText("Keranjang");

        javax.swing.GroupLayout jPanel79Layout = new javax.swing.GroupLayout(jPanel79);
        jPanel79.setLayout(jPanel79Layout);
        jPanel79Layout.setHorizontalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel79Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel79Layout.createSequentialGroup()
                        .addComponent(jLabel197, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel79Layout.createSequentialGroup()
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel198)
                                    .addComponent(jLabel199))
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel79Layout.createSequentialGroup()
                                        .addGap(89, 89, 89)
                                        .addComponent(jLabel200))
                                    .addGroup(jPanel79Layout.createSequentialGroup()
                                        .addGap(88, 88, 88)
                                        .addComponent(jLabel201)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel202)
                                    .addComponent(jLabel203))
                                .addGap(51, 51, 51))
                            .addGroup(jPanel79Layout.createSequentialGroup()
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(tksbahanabaya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                    .addComponent(tksnamaabaya))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(tkswarnaabaya)
                                    .addComponent(tkshargaabaya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tksukuranabaya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tksstockabaya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel79Layout.createSequentialGroup()
                        .addGap(0, 14, Short.MAX_VALUE)
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel79Layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(checkabaya))
                            .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
        );
        jPanel79Layout.setVerticalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel79Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel197, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel79Layout.createSequentialGroup()
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel198)
                            .addComponent(jLabel200)
                            .addComponent(jLabel202))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel199)
                            .addComponent(jLabel201)
                            .addComponent(jLabel203))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(checkabaya)
                    .addComponent(jButton2))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout deskabayaLayout = new javax.swing.GroupLayout(deskabaya);
        deskabaya.setLayout(deskabayaLayout);
        deskabayaLayout.setHorizontalGroup(
            deskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskabayaLayout.createSequentialGroup()
                .addGroup(deskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskabayaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskabaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(120, 120, 120)
                        .addComponent(jLabel196))
                    .addGroup(deskabayaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel79, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskabayaLayout.setVerticalGroup(
            deskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskabayaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskabayaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskabaya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel196, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel79, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskabaya, "card8");

        deskalgani.setBackground(new java.awt.Color(254, 164, 127));

        jLabel204.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel204.setForeground(new java.awt.Color(109, 33, 79));
        jLabel204.setText("MUKENA - ALGANI");

        kembalideskalgani.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskalgani.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskalgani.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskalganiMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskalganiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskalganiMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskalganiMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskalganiMouseReleased(evt);
            }
        });

        kembalilevine15.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskalganiLayout = new javax.swing.GroupLayout(kembalideskalgani);
        kembalideskalgani.setLayout(kembalideskalganiLayout);
        kembalideskalganiLayout.setHorizontalGroup(
            kembalideskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine15, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskalganiLayout.setVerticalGroup(
            kembalideskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel80.setBackground(new java.awt.Color(248, 239, 186));

        jLabel205.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel205.setText("icon");
        jLabel205.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsialgani.setEditable(false);
        tksdeskripsialgani.setBorder(null);
        tksdeskripsialgani.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane19.setViewportView(tksdeskripsialgani);

        jLabel206.setForeground(new java.awt.Color(109, 33, 79));
        jLabel206.setText("Nama ");

        jLabel207.setText("Bahan ");

        jLabel208.setText("Warna");

        jLabel209.setText("Harga");

        jLabel210.setText("Ukuran");

        jLabel211.setText("Stock");

        tkswarnaalgani.setEditable(false);

        tksbahanalgani.setEditable(false);

        tkshargaalgani.setEditable(false);

        tksukuranalgani.setEditable(false);

        tksstockalgani.setEditable(false);

        tksnamaalgani.setEditable(false);

        checkalgani.setText("Check out");
        checkalgani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkalganiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel80Layout = new javax.swing.GroupLayout(jPanel80);
        jPanel80.setLayout(jPanel80Layout);
        jPanel80Layout.setHorizontalGroup(
            jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel80Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel205, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel80Layout.createSequentialGroup()
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel206)
                            .addComponent(jLabel207))
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel80Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel208))
                            .addGroup(jPanel80Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel209)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel210)
                            .addComponent(jLabel211))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel80Layout.createSequentialGroup()
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanalgani, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaalgani))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaalgani)
                            .addComponent(tkshargaalgani, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranalgani, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockalgani, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel80Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkalgani)
                    .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel80Layout.setVerticalGroup(
            jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel80Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel205, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel80Layout.createSequentialGroup()
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel206)
                            .addComponent(jLabel208)
                            .addComponent(jLabel210))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel207)
                            .addComponent(jLabel209)
                            .addComponent(jLabel211))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkalgani)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskalganiLayout = new javax.swing.GroupLayout(deskalgani);
        deskalgani.setLayout(deskalganiLayout);
        deskalganiLayout.setHorizontalGroup(
            deskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskalganiLayout.createSequentialGroup()
                .addGroup(deskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskalganiLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskalgani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(120, 120, 120)
                        .addComponent(jLabel204))
                    .addGroup(deskalganiLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel80, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskalganiLayout.setVerticalGroup(
            deskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskalganiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskalganiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskalgani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel204, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel80, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskalgani, "card8");

        deskazzura.setBackground(new java.awt.Color(254, 164, 127));

        jLabel252.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel252.setForeground(new java.awt.Color(109, 33, 79));
        jLabel252.setText("MUKENA - AZZURA");

        kembalideskazzura.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskazzura.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskazzura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskazzuraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskazzuraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskazzuraMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskazzuraMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskazzuraMouseReleased(evt);
            }
        });

        kembalilevine21.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskazzuraLayout = new javax.swing.GroupLayout(kembalideskazzura);
        kembalideskazzura.setLayout(kembalideskazzuraLayout);
        kembalideskazzuraLayout.setHorizontalGroup(
            kembalideskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine21, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskazzuraLayout.setVerticalGroup(
            kembalideskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel86.setBackground(new java.awt.Color(248, 239, 186));

        jLabel253.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel253.setText("icon");
        jLabel253.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsiazzura.setEditable(false);
        tksdeskripsiazzura.setBorder(null);
        tksdeskripsiazzura.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane25.setViewportView(tksdeskripsiazzura);

        jLabel254.setForeground(new java.awt.Color(109, 33, 79));
        jLabel254.setText("Nama ");

        jLabel255.setText("Bahan ");

        jLabel256.setText("Warna");

        jLabel257.setText("Harga");

        jLabel258.setText("Ukuran");

        jLabel259.setText("Stock");

        tkswarnaazzura.setEditable(false);

        tksbahanazzura.setEditable(false);

        tkshargaazzura.setEditable(false);

        tksukuranazzura.setEditable(false);

        tksstockazzura.setEditable(false);

        tksnamaazzura.setEditable(false);

        checkazzura.setText("Check out");
        checkazzura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkazzuraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel86Layout = new javax.swing.GroupLayout(jPanel86);
        jPanel86.setLayout(jPanel86Layout);
        jPanel86Layout.setHorizontalGroup(
            jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel86Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel253, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel86Layout.createSequentialGroup()
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel254)
                            .addComponent(jLabel255))
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel86Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel256))
                            .addGroup(jPanel86Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel257)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel258)
                            .addComponent(jLabel259))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel86Layout.createSequentialGroup()
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanazzura, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaazzura))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaazzura)
                            .addComponent(tkshargaazzura, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranazzura, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockazzura, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel86Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkazzura)
                    .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel86Layout.setVerticalGroup(
            jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel86Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel253, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel86Layout.createSequentialGroup()
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel254)
                            .addComponent(jLabel256)
                            .addComponent(jLabel258))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel255)
                            .addComponent(jLabel257)
                            .addComponent(jLabel259))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkazzura)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskazzuraLayout = new javax.swing.GroupLayout(deskazzura);
        deskazzura.setLayout(deskazzuraLayout);
        deskazzuraLayout.setHorizontalGroup(
            deskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskazzuraLayout.createSequentialGroup()
                .addGroup(deskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskazzuraLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskazzura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113)
                        .addComponent(jLabel252))
                    .addGroup(deskazzuraLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel86, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskazzuraLayout.setVerticalGroup(
            deskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskazzuraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskazzuraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskazzura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel252, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel86, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskazzura, "card8");

        deskghanimi.setBackground(new java.awt.Color(254, 164, 127));

        jLabel212.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel212.setForeground(new java.awt.Color(109, 33, 79));
        jLabel212.setText("MUKENA - GHANIMI");

        kembalideskghanimi.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskghanimi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskghanimi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskghanimiMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskghanimiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskghanimiMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskghanimiMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskghanimiMouseReleased(evt);
            }
        });

        kembalilevine16.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskghanimiLayout = new javax.swing.GroupLayout(kembalideskghanimi);
        kembalideskghanimi.setLayout(kembalideskghanimiLayout);
        kembalideskghanimiLayout.setHorizontalGroup(
            kembalideskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine16, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskghanimiLayout.setVerticalGroup(
            kembalideskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel81.setBackground(new java.awt.Color(248, 239, 186));

        jLabel213.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel213.setText("icon");
        jLabel213.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsighanimi.setEditable(false);
        tksdeskripsighanimi.setBorder(null);
        tksdeskripsighanimi.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane20.setViewportView(tksdeskripsighanimi);

        jLabel214.setForeground(new java.awt.Color(109, 33, 79));
        jLabel214.setText("Nama ");

        jLabel215.setText("Bahan ");

        jLabel216.setText("Warna");

        jLabel217.setText("Harga");

        jLabel218.setText("Ukuran");

        jLabel219.setText("Stock");

        tkswarnaghanimi.setEditable(false);

        tksbahanghanimi.setEditable(false);

        tkshargaghanimi.setEditable(false);

        tksukuranghanimi.setEditable(false);

        tksstockghanimi.setEditable(false);

        tksnamaghanimi.setEditable(false);

        checkghanimi.setText("Check out");
        checkghanimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkghanimiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel81Layout = new javax.swing.GroupLayout(jPanel81);
        jPanel81.setLayout(jPanel81Layout);
        jPanel81Layout.setHorizontalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel81Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel213, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel81Layout.createSequentialGroup()
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel214)
                            .addComponent(jLabel215))
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel81Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel216))
                            .addGroup(jPanel81Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel217)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel218)
                            .addComponent(jLabel219))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel81Layout.createSequentialGroup()
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanghanimi, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaghanimi))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaghanimi)
                            .addComponent(tkshargaghanimi, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel81Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkghanimi)
                    .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel81Layout.setVerticalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel81Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel213, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel81Layout.createSequentialGroup()
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel214)
                            .addComponent(jLabel216)
                            .addComponent(jLabel218))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel215)
                            .addComponent(jLabel217)
                            .addComponent(jLabel219))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkghanimi)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskghanimiLayout = new javax.swing.GroupLayout(deskghanimi);
        deskghanimi.setLayout(deskghanimiLayout);
        deskghanimiLayout.setHorizontalGroup(
            deskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskghanimiLayout.createSequentialGroup()
                .addGroup(deskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskghanimiLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskghanimi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113)
                        .addComponent(jLabel212))
                    .addGroup(deskghanimiLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskghanimiLayout.setVerticalGroup(
            deskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskghanimiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskghanimiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskghanimi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel212, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskghanimi, "card8");

        deskhalima.setBackground(new java.awt.Color(254, 164, 127));

        jLabel220.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel220.setForeground(new java.awt.Color(109, 33, 79));
        jLabel220.setText("MUKENA - HALIMA");

        kembalideskhalima.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskhalima.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskhalima.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskhalimaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskhalimaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskhalimaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskhalimaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskhalimaMouseReleased(evt);
            }
        });

        kembalilevine17.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskhalimaLayout = new javax.swing.GroupLayout(kembalideskhalima);
        kembalideskhalima.setLayout(kembalideskhalimaLayout);
        kembalideskhalimaLayout.setHorizontalGroup(
            kembalideskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine17, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskhalimaLayout.setVerticalGroup(
            kembalideskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel82.setBackground(new java.awt.Color(248, 239, 186));

        jLabel221.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel221.setText("icon");
        jLabel221.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsihalima.setEditable(false);
        tksdeskripsihalima.setBorder(null);
        tksdeskripsihalima.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane21.setViewportView(tksdeskripsihalima);

        jLabel222.setForeground(new java.awt.Color(109, 33, 79));
        jLabel222.setText("Nama ");

        jLabel223.setText("Bahan ");

        jLabel224.setText("Warna");

        jLabel225.setText("Harga");

        jLabel226.setText("Ukuran");

        jLabel227.setText("Stock");

        tkswarnahalima.setEditable(false);

        tksbahanhalima.setEditable(false);

        tkshargahalima.setEditable(false);

        tksukuranhalima.setEditable(false);

        tksstockhalima.setEditable(false);

        tksnamahalima.setEditable(false);

        chechhalima.setText("Check out");
        chechhalima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chechhalimaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel82Layout = new javax.swing.GroupLayout(jPanel82);
        jPanel82.setLayout(jPanel82Layout);
        jPanel82Layout.setHorizontalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel221, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel82Layout.createSequentialGroup()
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel222)
                            .addComponent(jLabel223))
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel82Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel224))
                            .addGroup(jPanel82Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel225)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel226)
                            .addComponent(jLabel227))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel82Layout.createSequentialGroup()
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanhalima, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamahalima))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnahalima)
                            .addComponent(tkshargahalima, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranhalima, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockhalima, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel82Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(chechhalima)
                    .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel82Layout.setVerticalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel221, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel82Layout.createSequentialGroup()
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel222)
                            .addComponent(jLabel224)
                            .addComponent(jLabel226))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnahalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranhalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamahalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel223)
                            .addComponent(jLabel225)
                            .addComponent(jLabel227))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanhalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargahalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockhalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(chechhalima)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskhalimaLayout = new javax.swing.GroupLayout(deskhalima);
        deskhalima.setLayout(deskhalimaLayout);
        deskhalimaLayout.setHorizontalGroup(
            deskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskhalimaLayout.createSequentialGroup()
                .addGroup(deskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskhalimaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskhalima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(116, 116, 116)
                        .addComponent(jLabel220))
                    .addGroup(deskhalimaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskhalimaLayout.setVerticalGroup(
            deskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskhalimaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskhalimaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskhalima, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel220, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskhalima, "card8");

        deskponco.setBackground(new java.awt.Color(254, 164, 127));

        jLabel228.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel228.setForeground(new java.awt.Color(109, 33, 79));
        jLabel228.setText("MUKENA - PONCO");

        kembalideskponco.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskponco.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskponco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskponcoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskponcoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskponcoMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskponcoMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskponcoMouseReleased(evt);
            }
        });

        kembalilevine18.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskponcoLayout = new javax.swing.GroupLayout(kembalideskponco);
        kembalideskponco.setLayout(kembalideskponcoLayout);
        kembalideskponcoLayout.setHorizontalGroup(
            kembalideskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine18, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskponcoLayout.setVerticalGroup(
            kembalideskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel83.setBackground(new java.awt.Color(248, 239, 186));

        jLabel229.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel229.setText("icon");
        jLabel229.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsiponco.setEditable(false);
        tksdeskripsiponco.setBorder(null);
        tksdeskripsiponco.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane22.setViewportView(tksdeskripsiponco);

        jLabel230.setForeground(new java.awt.Color(109, 33, 79));
        jLabel230.setText("Nama ");

        jLabel231.setText("Bahan ");

        jLabel232.setText("Warna");

        jLabel233.setText("Harga");

        jLabel234.setText("Ukuran");

        jLabel235.setText("Stock");

        tkswarnaponco.setEditable(false);

        tksbahanponco.setEditable(false);

        tkshargaponco.setEditable(false);

        tksukuranponco.setEditable(false);

        tksstockponco.setEditable(false);

        tksnamaponco.setEditable(false);

        checkponco.setText("Check out");
        checkponco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkponcoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel83Layout = new javax.swing.GroupLayout(jPanel83);
        jPanel83.setLayout(jPanel83Layout);
        jPanel83Layout.setHorizontalGroup(
            jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel83Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel229, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel83Layout.createSequentialGroup()
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel230)
                            .addComponent(jLabel231))
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel83Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel232))
                            .addGroup(jPanel83Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel233)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel234)
                            .addComponent(jLabel235))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel83Layout.createSequentialGroup()
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanponco, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaponco))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaponco)
                            .addComponent(tkshargaponco, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranponco, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockponco, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel83Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkponco)
                    .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel83Layout.setVerticalGroup(
            jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel83Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel229, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel83Layout.createSequentialGroup()
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel230)
                            .addComponent(jLabel232)
                            .addComponent(jLabel234))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel231)
                            .addComponent(jLabel233)
                            .addComponent(jLabel235))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkponco)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskponcoLayout = new javax.swing.GroupLayout(deskponco);
        deskponco.setLayout(deskponcoLayout);
        deskponcoLayout.setHorizontalGroup(
            deskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskponcoLayout.createSequentialGroup()
                .addGroup(deskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskponcoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskponco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(123, 123, 123)
                        .addComponent(jLabel228))
                    .addGroup(deskponcoLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskponcoLayout.setVerticalGroup(
            deskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskponcoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskponcoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskponco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel228, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskponco, "card8");

        desktatuis.setBackground(new java.awt.Color(254, 164, 127));

        jLabel236.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel236.setForeground(new java.awt.Color(109, 33, 79));
        jLabel236.setText("MUKENA - TATUIS");

        kembalidesktatuis.setBackground(new java.awt.Color(248, 239, 186));
        kembalidesktatuis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalidesktatuis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidesktatuisMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidesktatuisMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidesktatuisMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidesktatuisMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidesktatuisMouseReleased(evt);
            }
        });

        kembalilevine19.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalidesktatuisLayout = new javax.swing.GroupLayout(kembalidesktatuis);
        kembalidesktatuis.setLayout(kembalidesktatuisLayout);
        kembalidesktatuisLayout.setHorizontalGroup(
            kembalidesktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine19, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalidesktatuisLayout.setVerticalGroup(
            kembalidesktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel84.setBackground(new java.awt.Color(248, 239, 186));

        jLabel237.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel237.setText("icon");
        jLabel237.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsitatuis.setEditable(false);
        tksdeskripsitatuis.setBorder(null);
        tksdeskripsitatuis.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane23.setViewportView(tksdeskripsitatuis);

        jLabel238.setForeground(new java.awt.Color(109, 33, 79));
        jLabel238.setText("Nama ");

        jLabel239.setText("Bahan ");

        jLabel240.setText("Warna");

        jLabel241.setText("Harga");

        jLabel242.setText("Ukuran");

        jLabel243.setText("Stock");

        tkswarnatatuis.setEditable(false);

        tksbahantatuis.setEditable(false);

        tkshargatatuis.setEditable(false);

        tksukurantatuis.setEditable(false);

        tksstocktatuis.setEditable(false);

        tksnamatatuis.setEditable(false);

        checktatuis.setText("Check out");
        checktatuis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checktatuisActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel84Layout = new javax.swing.GroupLayout(jPanel84);
        jPanel84.setLayout(jPanel84Layout);
        jPanel84Layout.setHorizontalGroup(
            jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel84Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel237, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel84Layout.createSequentialGroup()
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel238)
                            .addComponent(jLabel239))
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel84Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel240))
                            .addGroup(jPanel84Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel241)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel242)
                            .addComponent(jLabel243))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel84Layout.createSequentialGroup()
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahantatuis, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamatatuis))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnatatuis)
                            .addComponent(tkshargatatuis, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukurantatuis, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktatuis, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel84Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checktatuis)
                    .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel84Layout.setVerticalGroup(
            jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel84Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel237, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel84Layout.createSequentialGroup()
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel238)
                            .addComponent(jLabel240)
                            .addComponent(jLabel242))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnatatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukurantatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamatatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel239)
                            .addComponent(jLabel241)
                            .addComponent(jLabel243))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahantatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargatatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checktatuis)
                .addContainerGap())
        );

        javax.swing.GroupLayout desktatuisLayout = new javax.swing.GroupLayout(desktatuis);
        desktatuis.setLayout(desktatuisLayout);
        desktatuisLayout.setHorizontalGroup(
            desktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(desktatuisLayout.createSequentialGroup()
                .addGroup(desktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(desktatuisLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalidesktatuis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(122, 122, 122)
                        .addComponent(jLabel236))
                    .addGroup(desktatuisLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel84, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        desktatuisLayout.setVerticalGroup(
            desktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, desktatuisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(desktatuisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalidesktatuis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel236, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel84, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(desktatuis, "card8");

        desktazbiya.setBackground(new java.awt.Color(254, 164, 127));

        jLabel244.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel244.setForeground(new java.awt.Color(109, 33, 79));
        jLabel244.setText("MUKENA - TAZBIYA");

        kembalidesktazbiya.setBackground(new java.awt.Color(248, 239, 186));
        kembalidesktazbiya.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalidesktazbiya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidesktazbiyaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidesktazbiyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidesktazbiyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidesktazbiyaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidesktazbiyaMouseReleased(evt);
            }
        });

        kembalilevine20.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalidesktazbiyaLayout = new javax.swing.GroupLayout(kembalidesktazbiya);
        kembalidesktazbiya.setLayout(kembalidesktazbiyaLayout);
        kembalidesktazbiyaLayout.setHorizontalGroup(
            kembalidesktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine20, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalidesktazbiyaLayout.setVerticalGroup(
            kembalidesktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel85.setBackground(new java.awt.Color(248, 239, 186));

        jLabel245.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel245.setText("icon");
        jLabel245.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsitazbiya.setEditable(false);
        tksdeskripsitazbiya.setBorder(null);
        tksdeskripsitazbiya.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane24.setViewportView(tksdeskripsitazbiya);

        jLabel246.setForeground(new java.awt.Color(109, 33, 79));
        jLabel246.setText("Nama ");

        jLabel247.setText("Bahan ");

        jLabel248.setText("Warna");

        jLabel249.setText("Harga");

        jLabel250.setText("Ukuran");

        jLabel251.setText("Stock");

        tkswarnatazbiya.setEditable(false);

        tksbahantazbiya.setEditable(false);

        tkshargatazbiya.setEditable(false);

        tksukurantazbiya.setEditable(false);

        tksstocktazbiya.setEditable(false);

        tksnamatazbiya.setEditable(false);

        checktazbiya.setText("Check out");
        checktazbiya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checktazbiyaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel85Layout = new javax.swing.GroupLayout(jPanel85);
        jPanel85.setLayout(jPanel85Layout);
        jPanel85Layout.setHorizontalGroup(
            jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel85Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel245, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel85Layout.createSequentialGroup()
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel246)
                            .addComponent(jLabel247))
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel85Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel248))
                            .addGroup(jPanel85Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel249)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel250)
                            .addComponent(jLabel251))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel85Layout.createSequentialGroup()
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahantazbiya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamatazbiya))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnatazbiya)
                            .addComponent(tkshargatazbiya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukurantazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel85Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checktazbiya)
                    .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel85Layout.setVerticalGroup(
            jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel85Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel245, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel85Layout.createSequentialGroup()
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel246)
                            .addComponent(jLabel248)
                            .addComponent(jLabel250))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnatazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukurantazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamatazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel247)
                            .addComponent(jLabel249)
                            .addComponent(jLabel251))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahantazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargatazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checktazbiya)
                .addContainerGap())
        );

        javax.swing.GroupLayout desktazbiyaLayout = new javax.swing.GroupLayout(desktazbiya);
        desktazbiya.setLayout(desktazbiyaLayout);
        desktazbiyaLayout.setHorizontalGroup(
            desktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(desktazbiyaLayout.createSequentialGroup()
                .addGroup(desktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(desktazbiyaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalidesktazbiya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(115, 115, 115)
                        .addComponent(jLabel244))
                    .addGroup(desktazbiyaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel85, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        desktazbiyaLayout.setVerticalGroup(
            desktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, desktazbiyaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(desktazbiyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalidesktazbiya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel244, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel85, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(desktazbiya, "card8");

        deskbabyhelu.setBackground(new java.awt.Color(254, 164, 127));

        jLabel132.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel132.setForeground(new java.awt.Color(109, 33, 79));
        jLabel132.setText("BAJU - BABYHELU");

        kembalideskbabyhelu.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskbabyhelu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskbabyhelu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskbabyheluMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskbabyheluMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskbabyheluMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskbabyheluMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskbabyheluMouseReleased(evt);
            }
        });

        kembalilevine6.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskbabyheluLayout = new javax.swing.GroupLayout(kembalideskbabyhelu);
        kembalideskbabyhelu.setLayout(kembalideskbabyheluLayout);
        kembalideskbabyheluLayout.setHorizontalGroup(
            kembalideskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine6, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskbabyheluLayout.setVerticalGroup(
            kembalideskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel71.setBackground(new java.awt.Color(248, 239, 186));

        jLabel133.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel133.setText("icon");
        jLabel133.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsibabyhelu.setEditable(false);
        tksdeskripsibabyhelu.setBorder(null);
        tksdeskripsibabyhelu.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane10.setViewportView(tksdeskripsibabyhelu);

        jLabel134.setForeground(new java.awt.Color(109, 33, 79));
        jLabel134.setText("Nama ");

        jLabel135.setText("Bahan ");

        jLabel136.setText("Warna");

        jLabel137.setText("Harga");

        jLabel138.setText("Ukuran");

        jLabel139.setText("Stock");

        tkswarnababyhelu.setEditable(false);

        tksbahanbabyhelu.setEditable(false);

        tkshargababyhelu.setEditable(false);
        tkshargababyhelu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tkshargababyheluActionPerformed(evt);
            }
        });

        tksukuranbabyhelu.setEditable(false);

        tksstockbabyhelu.setEditable(false);

        tksnamababyhelu.setEditable(false);

        checkbabyhelu.setText("Check out");
        checkbabyhelu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkbabyheluActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel71Layout = new javax.swing.GroupLayout(jPanel71);
        jPanel71.setLayout(jPanel71Layout);
        jPanel71Layout.setHorizontalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel71Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel133, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel71Layout.createSequentialGroup()
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel134)
                            .addComponent(jLabel135))
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel71Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel136))
                            .addGroup(jPanel71Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel137)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel138)
                            .addComponent(jLabel139))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel71Layout.createSequentialGroup()
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanbabyhelu, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamababyhelu))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnababyhelu)
                            .addComponent(tkshargababyhelu, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel71Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkbabyhelu)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel71Layout.setVerticalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel71Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel133, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel71Layout.createSequentialGroup()
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel134)
                            .addComponent(jLabel136)
                            .addComponent(jLabel138))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnababyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamababyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel135)
                            .addComponent(jLabel137)
                            .addComponent(jLabel139))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargababyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkbabyhelu)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskbabyheluLayout = new javax.swing.GroupLayout(deskbabyhelu);
        deskbabyhelu.setLayout(deskbabyheluLayout);
        deskbabyheluLayout.setHorizontalGroup(
            deskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskbabyheluLayout.createSequentialGroup()
                .addGroup(deskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskbabyheluLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskbabyhelu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(127, 127, 127)
                        .addComponent(jLabel132))
                    .addGroup(deskbabyheluLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel71, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskbabyheluLayout.setVerticalGroup(
            deskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskbabyheluLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskbabyheluLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskbabyhelu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel132, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel71, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskbabyhelu, "card8");

        deskdianpelangi.setBackground(new java.awt.Color(254, 164, 127));

        jLabel140.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel140.setForeground(new java.awt.Color(109, 33, 79));
        jLabel140.setText("BAJU - DIAN PELANGI");

        kembalideskdianpelangi.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskdianpelangi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskdianpelangi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskdianpelangiMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskdianpelangiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskdianpelangiMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskdianpelangiMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskdianpelangiMouseReleased(evt);
            }
        });

        kembalilevine7.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskdianpelangiLayout = new javax.swing.GroupLayout(kembalideskdianpelangi);
        kembalideskdianpelangi.setLayout(kembalideskdianpelangiLayout);
        kembalideskdianpelangiLayout.setHorizontalGroup(
            kembalideskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine7, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskdianpelangiLayout.setVerticalGroup(
            kembalideskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel72.setBackground(new java.awt.Color(248, 239, 186));

        jLabel141.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel141.setText("icon");
        jLabel141.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsidianpelangi.setEditable(false);
        tksdeskripsidianpelangi.setBorder(null);
        tksdeskripsidianpelangi.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane11.setViewportView(tksdeskripsidianpelangi);

        jLabel142.setForeground(new java.awt.Color(109, 33, 79));
        jLabel142.setText("Nama ");

        jLabel143.setText("Bahan ");

        jLabel144.setText("Warna");

        jLabel145.setText("Harga");

        jLabel146.setText("Ukuran");

        jLabel147.setText("Stock");

        tkswarnadianpelangi.setEditable(false);

        tksbahandianpelangi.setEditable(false);

        tkshargadianpelangi.setEditable(false);

        tksukurandianpelangi.setEditable(false);

        tksstockdianpelangi.setEditable(false);

        tksnamadianpelangi.setEditable(false);

        checkdianpelangi.setText("Check out");
        checkdianpelangi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkdianpelangiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel72Layout = new javax.swing.GroupLayout(jPanel72);
        jPanel72.setLayout(jPanel72Layout);
        jPanel72Layout.setHorizontalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel72Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel141, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel72Layout.createSequentialGroup()
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel142)
                            .addComponent(jLabel143))
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel72Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel144))
                            .addGroup(jPanel72Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel145)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel146)
                            .addComponent(jLabel147))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel72Layout.createSequentialGroup()
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahandianpelangi, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamadianpelangi))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnadianpelangi)
                            .addComponent(tkshargadianpelangi, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukurandianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockdianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel72Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkdianpelangi)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel72Layout.setVerticalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel72Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel141, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel72Layout.createSequentialGroup()
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel142)
                            .addComponent(jLabel144)
                            .addComponent(jLabel146))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnadianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukurandianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamadianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel143)
                            .addComponent(jLabel145)
                            .addComponent(jLabel147))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahandianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargadianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockdianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkdianpelangi)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskdianpelangiLayout = new javax.swing.GroupLayout(deskdianpelangi);
        deskdianpelangi.setLayout(deskdianpelangiLayout);
        deskdianpelangiLayout.setHorizontalGroup(
            deskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskdianpelangiLayout.createSequentialGroup()
                .addGroup(deskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskdianpelangiLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskdianpelangi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(jLabel140))
                    .addGroup(deskdianpelangiLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel72, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskdianpelangiLayout.setVerticalGroup(
            deskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskdianpelangiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskdianpelangiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskdianpelangi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel140, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel72, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskdianpelangi, "card8");

        deskhaura.setBackground(new java.awt.Color(254, 164, 127));

        jLabel148.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel148.setForeground(new java.awt.Color(109, 33, 79));
        jLabel148.setText("BAJU - HAURA");

        kembalideskhaura.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskhaura.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskhaura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskhauraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskhauraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskhauraMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskhauraMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskhauraMouseReleased(evt);
            }
        });

        kembalilevine8.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskhauraLayout = new javax.swing.GroupLayout(kembalideskhaura);
        kembalideskhaura.setLayout(kembalideskhauraLayout);
        kembalideskhauraLayout.setHorizontalGroup(
            kembalideskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine8, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskhauraLayout.setVerticalGroup(
            kembalideskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel73.setBackground(new java.awt.Color(248, 239, 186));

        jLabel149.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel149.setText("icon");
        jLabel149.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsihaura.setEditable(false);
        tksdeskripsihaura.setBorder(null);
        tksdeskripsihaura.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane12.setViewportView(tksdeskripsihaura);

        jLabel150.setForeground(new java.awt.Color(109, 33, 79));
        jLabel150.setText("Nama ");

        jLabel151.setText("Bahan ");

        jLabel152.setText("Warna");

        jLabel153.setText("Harga");

        jLabel154.setText("Ukuran");

        jLabel155.setText("Stock");

        tkswarnahaura.setEditable(false);

        tksbahanhaura.setEditable(false);

        tkshargahaura.setEditable(false);

        tksukuranhaura.setEditable(false);

        tksstockhaura.setEditable(false);

        tksnamahaura.setEditable(false);

        checkhaura.setText("Check out");
        checkhaura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkhauraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel73Layout = new javax.swing.GroupLayout(jPanel73);
        jPanel73.setLayout(jPanel73Layout);
        jPanel73Layout.setHorizontalGroup(
            jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel73Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel149, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel73Layout.createSequentialGroup()
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel150)
                            .addComponent(jLabel151))
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel73Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel152))
                            .addGroup(jPanel73Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel153)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel154)
                            .addComponent(jLabel155))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel73Layout.createSequentialGroup()
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanhaura, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamahaura))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnahaura)
                            .addComponent(tkshargahaura, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranhaura, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockhaura, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel73Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkhaura)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel73Layout.setVerticalGroup(
            jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel73Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel149, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel73Layout.createSequentialGroup()
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel150)
                            .addComponent(jLabel152)
                            .addComponent(jLabel154))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnahaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranhaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamahaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel151)
                            .addComponent(jLabel153)
                            .addComponent(jLabel155))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanhaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargahaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockhaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkhaura)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskhauraLayout = new javax.swing.GroupLayout(deskhaura);
        deskhaura.setLayout(deskhauraLayout);
        deskhauraLayout.setHorizontalGroup(
            deskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskhauraLayout.createSequentialGroup()
                .addGroup(deskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskhauraLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskhaura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(141, 141, 141)
                        .addComponent(jLabel148))
                    .addGroup(deskhauraLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel73, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskhauraLayout.setVerticalGroup(
            deskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskhauraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskhauraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskhaura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel148, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel73, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskhaura, "card8");

        deskmelika.setBackground(new java.awt.Color(254, 164, 127));

        jLabel156.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel156.setForeground(new java.awt.Color(109, 33, 79));
        jLabel156.setText("BAJU - MELIKA");

        kembalideskmelika.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskmelika.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskmelika.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskmelikaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskmelikaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskmelikaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskmelikaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskmelikaMouseReleased(evt);
            }
        });

        kembalilevine9.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskmelikaLayout = new javax.swing.GroupLayout(kembalideskmelika);
        kembalideskmelika.setLayout(kembalideskmelikaLayout);
        kembalideskmelikaLayout.setHorizontalGroup(
            kembalideskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine9, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskmelikaLayout.setVerticalGroup(
            kembalideskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel74.setBackground(new java.awt.Color(248, 239, 186));

        jLabel157.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel157.setText("icon");
        jLabel157.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsimelika.setEditable(false);
        tksdeskripsimelika.setBorder(null);
        tksdeskripsimelika.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane13.setViewportView(tksdeskripsimelika);

        jLabel158.setForeground(new java.awt.Color(109, 33, 79));
        jLabel158.setText("Nama ");

        jLabel159.setText("Bahan ");

        jLabel160.setText("Warna");

        jLabel161.setText("Harga");

        jLabel162.setText("Ukuran");

        jLabel163.setText("Stock");

        tkswarnamelika.setEditable(false);

        tksbahanmelika.setEditable(false);

        tkshargamelika.setEditable(false);

        tksukuranmelika.setEditable(false);

        tksstockmelika.setEditable(false);

        tksnamamelika.setEditable(false);

        checkmelika.setText("Check out");
        checkmelika.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkmelikaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel74Layout = new javax.swing.GroupLayout(jPanel74);
        jPanel74.setLayout(jPanel74Layout);
        jPanel74Layout.setHorizontalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel74Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel157, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel74Layout.createSequentialGroup()
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel158)
                            .addComponent(jLabel159))
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel74Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel160))
                            .addGroup(jPanel74Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel161)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel162)
                            .addComponent(jLabel163))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel74Layout.createSequentialGroup()
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanmelika, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamamelika))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnamelika)
                            .addComponent(tkshargamelika, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranmelika, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmelika, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel74Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkmelika)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel74Layout.setVerticalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel74Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel157, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel74Layout.createSequentialGroup()
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel158)
                            .addComponent(jLabel160)
                            .addComponent(jLabel162))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnamelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranmelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamamelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel159)
                            .addComponent(jLabel161)
                            .addComponent(jLabel163))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanmelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargamelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkmelika)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskmelikaLayout = new javax.swing.GroupLayout(deskmelika);
        deskmelika.setLayout(deskmelikaLayout);
        deskmelikaLayout.setHorizontalGroup(
            deskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskmelikaLayout.createSequentialGroup()
                .addGroup(deskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskmelikaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskmelika, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(134, 134, 134)
                        .addComponent(jLabel156))
                    .addGroup(deskmelikaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel74, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskmelikaLayout.setVerticalGroup(
            deskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskmelikaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskmelikaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskmelika, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel156, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel74, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskmelika, "card8");

        deskmonel.setBackground(new java.awt.Color(254, 164, 127));

        jLabel164.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel164.setForeground(new java.awt.Color(109, 33, 79));
        jLabel164.setText("BAJU - MONEL");

        kembalideskmonel.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskmonel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskmonel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskmonelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskmonelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskmonelMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskmonelMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskmonelMouseReleased(evt);
            }
        });

        kembalilevine10.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskmonelLayout = new javax.swing.GroupLayout(kembalideskmonel);
        kembalideskmonel.setLayout(kembalideskmonelLayout);
        kembalideskmonelLayout.setHorizontalGroup(
            kembalideskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine10, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskmonelLayout.setVerticalGroup(
            kembalideskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel75.setBackground(new java.awt.Color(248, 239, 186));

        jLabel165.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel165.setText("icon");
        jLabel165.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsimonel.setEditable(false);
        tksdeskripsimonel.setBorder(null);
        tksdeskripsimonel.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane14.setViewportView(tksdeskripsimonel);

        jLabel166.setForeground(new java.awt.Color(109, 33, 79));
        jLabel166.setText("Nama ");

        jLabel167.setText("Bahan ");

        jLabel168.setText("Warna");

        jLabel169.setText("Harga");

        jLabel170.setText("Ukuran");

        jLabel171.setText("Stock");

        tkswarnamonel.setEditable(false);

        tksbahanmonel.setEditable(false);

        tkshargamonel.setEditable(false);

        tksukuranmonel.setEditable(false);

        tksstockmonel.setEditable(false);

        tksnamamonel.setEditable(false);

        checkmonel.setText("Check out");
        checkmonel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkmonelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel75Layout = new javax.swing.GroupLayout(jPanel75);
        jPanel75.setLayout(jPanel75Layout);
        jPanel75Layout.setHorizontalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel75Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel165, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel75Layout.createSequentialGroup()
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel166)
                            .addComponent(jLabel167))
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel75Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel168))
                            .addGroup(jPanel75Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel169)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel170)
                            .addComponent(jLabel171))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel75Layout.createSequentialGroup()
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanmonel, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamamonel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnamonel)
                            .addComponent(tkshargamonel, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranmonel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmonel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel75Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkmonel)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel75Layout.setVerticalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel75Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel165, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel75Layout.createSequentialGroup()
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel166)
                            .addComponent(jLabel168)
                            .addComponent(jLabel170))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnamonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranmonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamamonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel167)
                            .addComponent(jLabel169)
                            .addComponent(jLabel171))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanmonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargamonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkmonel)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskmonelLayout = new javax.swing.GroupLayout(deskmonel);
        deskmonel.setLayout(deskmonelLayout);
        deskmonelLayout.setHorizontalGroup(
            deskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskmonelLayout.createSequentialGroup()
                .addGroup(deskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskmonelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskmonel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(138, 138, 138)
                        .addComponent(jLabel164))
                    .addGroup(deskmonelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel75, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskmonelLayout.setVerticalGroup(
            deskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskmonelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskmonelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskmonel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel164, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel75, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskmonel, "card8");

        deskrianmiranda.setBackground(new java.awt.Color(254, 164, 127));

        jLabel172.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel172.setForeground(new java.awt.Color(109, 33, 79));
        jLabel172.setText("BAJU - RIA MIRANDA");

        kembalideskrianmiranda.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskrianmiranda.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskrianmiranda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskrianmirandaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskrianmirandaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskrianmirandaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskrianmirandaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskrianmirandaMouseReleased(evt);
            }
        });

        kembalilevine11.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskrianmirandaLayout = new javax.swing.GroupLayout(kembalideskrianmiranda);
        kembalideskrianmiranda.setLayout(kembalideskrianmirandaLayout);
        kembalideskrianmirandaLayout.setHorizontalGroup(
            kembalideskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine11, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskrianmirandaLayout.setVerticalGroup(
            kembalideskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel76.setBackground(new java.awt.Color(248, 239, 186));

        jLabel173.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel173.setText("icon");
        jLabel173.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsimiranda.setEditable(false);
        tksdeskripsimiranda.setBorder(null);
        tksdeskripsimiranda.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane15.setViewportView(tksdeskripsimiranda);

        jLabel174.setForeground(new java.awt.Color(109, 33, 79));
        jLabel174.setText("Nama ");

        jLabel175.setText("Bahan ");

        jLabel176.setText("Warna");

        jLabel177.setText("Harga");

        jLabel178.setText("Ukuran");

        jLabel179.setText("Stock");

        tkswarnamiranda.setEditable(false);

        tksbahanmiranda.setEditable(false);

        tkshargamiranda.setEditable(false);

        tksukuranmiranda.setEditable(false);

        tksstockmiranda.setEditable(false);

        tksnamamiranda.setEditable(false);

        checkmiranda.setText("Check out");
        checkmiranda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkmirandaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel76Layout = new javax.swing.GroupLayout(jPanel76);
        jPanel76.setLayout(jPanel76Layout);
        jPanel76Layout.setHorizontalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel76Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel173, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel76Layout.createSequentialGroup()
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel174)
                            .addComponent(jLabel175))
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel76Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel176))
                            .addGroup(jPanel76Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel177)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel178)
                            .addComponent(jLabel179))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel76Layout.createSequentialGroup()
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanmiranda, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamamiranda))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnamiranda)
                            .addComponent(tkshargamiranda, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel76Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkmiranda)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel76Layout.setVerticalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel76Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel173, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel76Layout.createSequentialGroup()
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel174)
                            .addComponent(jLabel176)
                            .addComponent(jLabel178))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnamiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamamiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel175)
                            .addComponent(jLabel177)
                            .addComponent(jLabel179))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargamiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkmiranda)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskrianmirandaLayout = new javax.swing.GroupLayout(deskrianmiranda);
        deskrianmiranda.setLayout(deskrianmirandaLayout);
        deskrianmirandaLayout.setHorizontalGroup(
            deskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskrianmirandaLayout.createSequentialGroup()
                .addGroup(deskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskrianmirandaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskrianmiranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(107, 107, 107)
                        .addComponent(jLabel172))
                    .addGroup(deskrianmirandaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel76, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskrianmirandaLayout.setVerticalGroup(
            deskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskrianmirandaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskrianmirandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskrianmiranda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel172, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel76, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskrianmiranda, "card8");

        desktuneeca.setBackground(new java.awt.Color(254, 164, 127));

        jLabel180.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel180.setForeground(new java.awt.Color(109, 33, 79));
        jLabel180.setText("BAJU - TUNEECA");

        kembalidesktuneeca.setBackground(new java.awt.Color(248, 239, 186));
        kembalidesktuneeca.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalidesktuneeca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidesktuneecaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidesktuneecaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidesktuneecaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidesktuneecaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidesktuneecaMouseReleased(evt);
            }
        });

        kembalilevine12.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalidesktuneecaLayout = new javax.swing.GroupLayout(kembalidesktuneeca);
        kembalidesktuneeca.setLayout(kembalidesktuneecaLayout);
        kembalidesktuneecaLayout.setHorizontalGroup(
            kembalidesktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine12, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalidesktuneecaLayout.setVerticalGroup(
            kembalidesktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel77.setBackground(new java.awt.Color(248, 239, 186));

        jLabel181.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel181.setText("icon");
        jLabel181.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsituneeca.setEditable(false);
        tksdeskripsituneeca.setBorder(null);
        tksdeskripsituneeca.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane16.setViewportView(tksdeskripsituneeca);

        jLabel182.setForeground(new java.awt.Color(109, 33, 79));
        jLabel182.setText("Nama ");

        jLabel183.setText("Bahan ");

        jLabel184.setText("Warna");

        jLabel185.setText("Harga");

        jLabel186.setText("Ukuran");

        jLabel187.setText("Stock");

        tkswarnatuneeca.setEditable(false);

        tksbahantuneeca.setEditable(false);

        tkshargatuneeca.setEditable(false);

        tksukurantuneeca.setEditable(false);

        tksstocktuneeca.setEditable(false);

        tksnamatuneeca.setEditable(false);

        checktuneeca.setText("Check out");
        checktuneeca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checktuneecaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel77Layout = new javax.swing.GroupLayout(jPanel77);
        jPanel77.setLayout(jPanel77Layout);
        jPanel77Layout.setHorizontalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel77Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel181, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel77Layout.createSequentialGroup()
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel182)
                            .addComponent(jLabel183))
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel77Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel184))
                            .addGroup(jPanel77Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel185)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel186)
                            .addComponent(jLabel187))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel77Layout.createSequentialGroup()
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahantuneeca, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamatuneeca))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnatuneeca)
                            .addComponent(tkshargatuneeca, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukurantuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel77Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checktuneeca)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel77Layout.setVerticalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel77Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel181, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel77Layout.createSequentialGroup()
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel182)
                            .addComponent(jLabel184)
                            .addComponent(jLabel186))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnatuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukurantuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamatuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel183)
                            .addComponent(jLabel185)
                            .addComponent(jLabel187))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahantuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargatuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocktuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checktuneeca)
                .addContainerGap())
        );

        javax.swing.GroupLayout desktuneecaLayout = new javax.swing.GroupLayout(desktuneeca);
        desktuneeca.setLayout(desktuneecaLayout);
        desktuneecaLayout.setHorizontalGroup(
            desktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(desktuneecaLayout.createSequentialGroup()
                .addGroup(desktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(desktuneecaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalidesktuneeca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(135, 135, 135)
                        .addComponent(jLabel180))
                    .addGroup(desktuneecaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel77, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        desktuneecaLayout.setVerticalGroup(
            desktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, desktuneecaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(desktuneecaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalidesktuneeca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel180, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel77, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(desktuneeca, "card8");

        deskzmnow.setBackground(new java.awt.Color(254, 164, 127));

        jLabel188.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel188.setForeground(new java.awt.Color(109, 33, 79));
        jLabel188.setText("BAJU - ZMNOW");

        kembalideskzmnow.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskzmnow.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskzmnow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskzmnowMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskzmnowMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskzmnowMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskzmnowMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskzmnowMouseReleased(evt);
            }
        });

        kembalilevine13.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskzmnowLayout = new javax.swing.GroupLayout(kembalideskzmnow);
        kembalideskzmnow.setLayout(kembalideskzmnowLayout);
        kembalideskzmnowLayout.setHorizontalGroup(
            kembalideskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine13, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskzmnowLayout.setVerticalGroup(
            kembalideskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel78.setBackground(new java.awt.Color(248, 239, 186));

        jLabel189.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel189.setText("icon");
        jLabel189.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsizmnow.setEditable(false);
        tksdeskripsizmnow.setBorder(null);
        tksdeskripsizmnow.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane17.setViewportView(tksdeskripsizmnow);

        jLabel190.setForeground(new java.awt.Color(109, 33, 79));
        jLabel190.setText("Nama ");

        jLabel191.setText("Bahan ");

        jLabel192.setText("Warna");

        jLabel193.setText("Harga");

        jLabel194.setText("Ukuran");

        jLabel195.setText("Stock");

        tkswarnazmnow.setEditable(false);

        tksbahanzmnow.setEditable(false);

        tkshargazmnow.setEditable(false);

        tksukuranzmnow.setEditable(false);

        tksstockzmnow.setEditable(false);

        tksnamazmnow.setEditable(false);

        checkzmnow.setText("Check out");
        checkzmnow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkzmnowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel78Layout = new javax.swing.GroupLayout(jPanel78);
        jPanel78.setLayout(jPanel78Layout);
        jPanel78Layout.setHorizontalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel78Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel189, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel78Layout.createSequentialGroup()
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel190)
                            .addComponent(jLabel191))
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel78Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel192))
                            .addGroup(jPanel78Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel193)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel194)
                            .addComponent(jLabel195))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel78Layout.createSequentialGroup()
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanzmnow, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamazmnow))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnazmnow)
                            .addComponent(tkshargazmnow, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel78Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkzmnow)
                    .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel78Layout.setVerticalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel78Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel189, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel78Layout.createSequentialGroup()
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel190)
                            .addComponent(jLabel192)
                            .addComponent(jLabel194))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnazmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamazmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel191)
                            .addComponent(jLabel193)
                            .addComponent(jLabel195))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargazmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkzmnow)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskzmnowLayout = new javax.swing.GroupLayout(deskzmnow);
        deskzmnow.setLayout(deskzmnowLayout);
        deskzmnowLayout.setHorizontalGroup(
            deskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskzmnowLayout.createSequentialGroup()
                .addGroup(deskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskzmnowLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskzmnow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(135, 135, 135)
                        .addComponent(jLabel188))
                    .addGroup(deskzmnowLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel78, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskzmnowLayout.setVerticalGroup(
            deskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskzmnowLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskzmnowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskzmnow, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel188, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel78, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskzmnow, "card8");

        deskzoya.setBackground(new java.awt.Color(254, 164, 127));

        jLabel88.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(109, 33, 79));
        jLabel88.setText("HIJAB - ZOYA");

        kembalideskzoya.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskzoya.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskzoya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskzoyaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskzoyaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskzoyaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskzoyaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskzoyaMouseReleased(evt);
            }
        });

        kembalilevine5.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskzoyaLayout = new javax.swing.GroupLayout(kembalideskzoya);
        kembalideskzoya.setLayout(kembalideskzoyaLayout);
        kembalideskzoyaLayout.setHorizontalGroup(
            kembalideskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine5, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskzoyaLayout.setVerticalGroup(
            kembalideskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel38.setBackground(new java.awt.Color(248, 239, 186));

        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("icon");
        jLabel89.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsizoya.setEditable(false);
        tksdeskripsizoya.setBorder(null);
        tksdeskripsizoya.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane9.setViewportView(tksdeskripsizoya);

        jLabel90.setForeground(new java.awt.Color(109, 33, 79));
        jLabel90.setText("Nama ");

        jLabel91.setText("Bahan ");

        jLabel92.setText("Warna");

        jLabel93.setText("Harga");

        jLabel94.setText("Ukuran");

        jLabel95.setText("Stock");

        tkswarnazoya.setEditable(false);

        tksbahanzoya.setEditable(false);

        tkshargazoya.setEditable(false);

        tksukuranzoya.setEditable(false);

        tksstockzoya.setEditable(false);

        tksnamazoya.setEditable(false);

        checkzoya.setText("Check out");
        checkzoya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkzoyaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel90)
                            .addComponent(jLabel91))
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel38Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel92))
                            .addGroup(jPanel38Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel93)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel94)
                            .addComponent(jLabel95))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanzoya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamazoya))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnazoya)
                            .addComponent(tkshargazoya, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranzoya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockzoya, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel38Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkzoya)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel90)
                            .addComponent(jLabel92)
                            .addComponent(jLabel94))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnazoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranzoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamazoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel91)
                            .addComponent(jLabel93)
                            .addComponent(jLabel95))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanzoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargazoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockzoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkzoya)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskzoyaLayout = new javax.swing.GroupLayout(deskzoya);
        deskzoya.setLayout(deskzoyaLayout);
        deskzoyaLayout.setHorizontalGroup(
            deskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskzoyaLayout.createSequentialGroup()
                .addGroup(deskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskzoyaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskzoya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(144, 144, 144)
                        .addComponent(jLabel88))
                    .addGroup(deskzoyaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskzoyaLayout.setVerticalGroup(
            deskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskzoyaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskzoyaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskzoya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel88, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskzoya, "card8");

        deskumama.setBackground(new java.awt.Color(254, 164, 127));

        jLabel80.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(109, 33, 79));
        jLabel80.setText("HIJAB - UMAMA");

        kembalideskumama.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskumama.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskumama.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskumamaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskumamaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskumamaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskumamaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskumamaMouseReleased(evt);
            }
        });

        kembalilevine4.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskumamaLayout = new javax.swing.GroupLayout(kembalideskumama);
        kembalideskumama.setLayout(kembalideskumamaLayout);
        kembalideskumamaLayout.setHorizontalGroup(
            kembalideskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine4, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskumamaLayout.setVerticalGroup(
            kembalideskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel37.setBackground(new java.awt.Color(248, 239, 186));

        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel81.setText("icon");
        jLabel81.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsiumama.setEditable(false);
        tksdeskripsiumama.setBorder(null);
        tksdeskripsiumama.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane8.setViewportView(tksdeskripsiumama);

        jLabel82.setForeground(new java.awt.Color(109, 33, 79));
        jLabel82.setText("Nama ");

        jLabel83.setText("Bahan ");

        jLabel84.setText("Warna");

        jLabel85.setText("Harga");

        jLabel86.setText("Ukuran");

        jLabel87.setText("Stock");

        tkswarnaumama.setEditable(false);

        tksbahanumama.setEditable(false);

        tkshargaumama.setEditable(false);

        tksukuranumama.setEditable(false);

        tksstockumama.setEditable(false);

        tksnamaumama.setEditable(false);

        checkumama.setText("Check out");
        checkumama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkumamaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel82)
                            .addComponent(jLabel83))
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel37Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel84))
                            .addGroup(jPanel37Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel85)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel86)
                            .addComponent(jLabel87))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanumama, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaumama))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaumama)
                            .addComponent(tkshargaumama, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranumama, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockumama, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel37Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkumama)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel82)
                            .addComponent(jLabel84)
                            .addComponent(jLabel86))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel83)
                            .addComponent(jLabel85)
                            .addComponent(jLabel87))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkumama)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskumamaLayout = new javax.swing.GroupLayout(deskumama);
        deskumama.setLayout(deskumamaLayout);
        deskumamaLayout.setHorizontalGroup(
            deskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskumamaLayout.createSequentialGroup()
                .addGroup(deskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskumamaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskumama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(128, 128, 128)
                        .addComponent(jLabel80))
                    .addGroup(deskumamaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskumamaLayout.setVerticalGroup(
            deskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskumamaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskumamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskumama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel80, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskumama, "card8");

        deskshafira.setBackground(new java.awt.Color(254, 164, 127));

        jLabel72.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(109, 33, 79));
        jLabel72.setText("HIJAB - SHAFIRA");

        kembalideskshafira.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskshafira.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskshafira.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskshafiraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskshafiraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskshafiraMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskshafiraMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskshafiraMouseReleased(evt);
            }
        });

        kembalilevine3.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskshafiraLayout = new javax.swing.GroupLayout(kembalideskshafira);
        kembalideskshafira.setLayout(kembalideskshafiraLayout);
        kembalideskshafiraLayout.setHorizontalGroup(
            kembalideskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine3, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskshafiraLayout.setVerticalGroup(
            kembalideskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel36.setBackground(new java.awt.Color(248, 239, 186));

        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel73.setText("icon");
        jLabel73.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsishafira.setEditable(false);
        tksdeskripsishafira.setBorder(null);
        tksdeskripsishafira.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane7.setViewportView(tksdeskripsishafira);

        jLabel74.setForeground(new java.awt.Color(109, 33, 79));
        jLabel74.setText("Nama ");

        jLabel75.setText("Bahan ");

        jLabel76.setText("Warna");

        jLabel77.setText("Harga");

        jLabel78.setText("Ukuran");

        jLabel79.setText("Stock");

        tkswarnashafira.setEditable(false);

        tksbahanshafira.setEditable(false);

        tkshargashafira.setEditable(false);

        tksukuranshafira.setEditable(false);

        tksstockshafira.setEditable(false);

        tksnamashafira.setEditable(false);

        checkshafira.setText("Check out");
        checkshafira.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkshafiraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel73, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel74)
                            .addComponent(jLabel75))
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel36Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel76))
                            .addGroup(jPanel36Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel77)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel78)
                            .addComponent(jLabel79))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanshafira, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamashafira))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnashafira)
                            .addComponent(tkshargashafira, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranshafira, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockshafira, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel36Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkshafira)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel73, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel74)
                            .addComponent(jLabel76)
                            .addComponent(jLabel78))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnashafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranshafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamashafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel75)
                            .addComponent(jLabel77)
                            .addComponent(jLabel79))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanshafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargashafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockshafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkshafira)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskshafiraLayout = new javax.swing.GroupLayout(deskshafira);
        deskshafira.setLayout(deskshafiraLayout);
        deskshafiraLayout.setHorizontalGroup(
            deskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskshafiraLayout.createSequentialGroup()
                .addGroup(deskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskshafiraLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskshafira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132)
                        .addComponent(jLabel72))
                    .addGroup(deskshafiraLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskshafiraLayout.setVerticalGroup(
            deskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskshafiraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskshafiraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskshafira, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskshafira, "card8");

        deskrabbani.setBackground(new java.awt.Color(254, 164, 127));

        jLabel64.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(109, 33, 79));
        jLabel64.setText("HIJAB - RABBANI");

        kembalideskrabbani.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskrabbani.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskrabbani.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskrabbaniMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskrabbaniMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskrabbaniMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskrabbaniMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskrabbaniMouseReleased(evt);
            }
        });

        kembalilevine2.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskrabbaniLayout = new javax.swing.GroupLayout(kembalideskrabbani);
        kembalideskrabbani.setLayout(kembalideskrabbaniLayout);
        kembalideskrabbaniLayout.setHorizontalGroup(
            kembalideskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine2, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskrabbaniLayout.setVerticalGroup(
            kembalideskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel35.setBackground(new java.awt.Color(248, 239, 186));

        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setText("icon");
        jLabel65.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsirabbani.setEditable(false);
        tksdeskripsirabbani.setBorder(null);
        tksdeskripsirabbani.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane6.setViewportView(tksdeskripsirabbani);

        jLabel66.setForeground(new java.awt.Color(109, 33, 79));
        jLabel66.setText("Nama ");

        jLabel67.setText("Bahan ");

        jLabel68.setText("Warna");

        jLabel69.setText("Harga");

        jLabel70.setText("Ukuran");

        jLabel71.setText("Stock");

        tkswarnarabbani.setEditable(false);

        tksbahanrabbani.setEditable(false);

        tkshargarabbani.setEditable(false);

        tksukuranrabbani.setEditable(false);

        tksstockrabbani.setEditable(false);

        tksnamarabbani.setEditable(false);

        checkrabbani.setText("Check out");
        checkrabbani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkrabbaniActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel66)
                            .addComponent(jLabel67))
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel35Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel68))
                            .addGroup(jPanel35Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel69)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel70)
                            .addComponent(jLabel71))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanrabbani, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamarabbani))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnarabbani)
                            .addComponent(tkshargarabbani, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkrabbani)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel66)
                            .addComponent(jLabel68)
                            .addComponent(jLabel70))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnarabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamarabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel67)
                            .addComponent(jLabel69)
                            .addComponent(jLabel71))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargarabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkrabbani)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskrabbaniLayout = new javax.swing.GroupLayout(deskrabbani);
        deskrabbani.setLayout(deskrabbaniLayout);
        deskrabbaniLayout.setHorizontalGroup(
            deskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskrabbaniLayout.createSequentialGroup()
                .addGroup(deskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskrabbaniLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskrabbani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(128, 128, 128)
                        .addComponent(jLabel64))
                    .addGroup(deskrabbaniLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskrabbaniLayout.setVerticalGroup(
            deskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskrabbaniLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskrabbaniLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskrabbani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel64, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskrabbani, "card8");

        deskpashmina.setBackground(new java.awt.Color(254, 164, 127));

        jLabel56.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(109, 33, 79));
        jLabel56.setText("HIJAB - PASHMINA");

        kembalideskpashmina.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskpashmina.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskpashmina.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskpashminaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskpashminaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskpashminaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskpashminaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskpashminaMouseReleased(evt);
            }
        });

        kembalilevine1.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskpashminaLayout = new javax.swing.GroupLayout(kembalideskpashmina);
        kembalideskpashmina.setLayout(kembalideskpashminaLayout);
        kembalideskpashminaLayout.setHorizontalGroup(
            kembalideskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskpashminaLayout.setVerticalGroup(
            kembalideskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel34.setBackground(new java.awt.Color(248, 239, 186));

        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText("icon");
        jLabel57.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsipashmina.setEditable(false);
        tksdeskripsipashmina.setBorder(null);
        tksdeskripsipashmina.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane5.setViewportView(tksdeskripsipashmina);

        jLabel58.setForeground(new java.awt.Color(109, 33, 79));
        jLabel58.setText("Nama ");

        jLabel59.setText("Bahan ");

        jLabel60.setText("Warna");

        jLabel61.setText("Harga");

        jLabel62.setText("Ukuran");

        jLabel63.setText("Stock");

        tkswarnapashmina.setEditable(false);

        tksbahanpashmina.setEditable(false);

        tkshargapashmina.setEditable(false);

        tksukuranpashmina.setEditable(false);

        tksstockpashmina.setEditable(false);

        tksnamapashmina.setEditable(false);

        checkpashmina.setText("Check out");
        checkpashmina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkpashminaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel58)
                            .addComponent(jLabel59))
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel34Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel60))
                            .addGroup(jPanel34Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel61)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel62)
                            .addComponent(jLabel63))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanpashmina, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamapashmina))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnapashmina)
                            .addComponent(tkshargapashmina, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkpashmina)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel58)
                            .addComponent(jLabel60)
                            .addComponent(jLabel62))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnapashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamapashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel59)
                            .addComponent(jLabel61)
                            .addComponent(jLabel63))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargapashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkpashmina)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskpashminaLayout = new javax.swing.GroupLayout(deskpashmina);
        deskpashmina.setLayout(deskpashminaLayout);
        deskpashminaLayout.setHorizontalGroup(
            deskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskpashminaLayout.createSequentialGroup()
                .addGroup(deskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskpashminaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskpashmina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(121, 121, 121)
                        .addComponent(jLabel56))
                    .addGroup(deskpashminaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskpashminaLayout.setVerticalGroup(
            deskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskpashminaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskpashminaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskpashmina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel56, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskpashmina, "card8");

        desklevine.setBackground(new java.awt.Color(254, 164, 127));

        jLabel48.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(109, 33, 79));
        jLabel48.setText("HIJAB - LEVINE");

        kembalidesklevine.setBackground(new java.awt.Color(248, 239, 186));
        kembalidesklevine.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalidesklevine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidesklevineMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidesklevineMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidesklevineMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidesklevineMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidesklevineMouseReleased(evt);
            }
        });

        kembalilevine.setBackground(new java.awt.Color(248, 239, 186));
        kembalilevine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalilevine.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalidesklevineLayout = new javax.swing.GroupLayout(kembalidesklevine);
        kembalidesklevine.setLayout(kembalidesklevineLayout);
        kembalidesklevineLayout.setHorizontalGroup(
            kembalidesklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalidesklevineLayout.setVerticalGroup(
            kembalidesklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalilevine, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel33.setBackground(new java.awt.Color(248, 239, 186));

        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setText("icon");
        jLabel49.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsilevine.setEditable(false);
        tksdeskripsilevine.setBorder(null);
        tksdeskripsilevine.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane4.setViewportView(tksdeskripsilevine);

        jLabel50.setForeground(new java.awt.Color(109, 33, 79));
        jLabel50.setText("Nama ");

        jLabel51.setText("Bahan ");

        jLabel52.setText("Warna");

        jLabel53.setText("Harga");

        jLabel54.setText("Ukuran");

        jLabel55.setText("Stock");

        tkswarnalevine.setEditable(false);

        tksbahanlevine.setEditable(false);

        tkshargalevine.setEditable(false);

        tksukuranlevine.setEditable(false);

        tksstocklevine.setEditable(false);

        tksnamalevine.setEditable(false);

        checklevine.setText("Check out");
        checklevine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checklevineActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel50)
                            .addComponent(jLabel51))
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel33Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel52))
                            .addGroup(jPanel33Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel53)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel54)
                            .addComponent(jLabel55))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanlevine, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamalevine))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnalevine)
                            .addComponent(tkshargalevine, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranlevine, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocklevine, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel33Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checklevine)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel50)
                            .addComponent(jLabel52)
                            .addComponent(jLabel54))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnalevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranlevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamalevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel51)
                            .addComponent(jLabel53)
                            .addComponent(jLabel55))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanlevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargalevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstocklevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checklevine)
                .addContainerGap())
        );

        javax.swing.GroupLayout desklevineLayout = new javax.swing.GroupLayout(desklevine);
        desklevine.setLayout(desklevineLayout);
        desklevineLayout.setHorizontalGroup(
            desklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(desklevineLayout.createSequentialGroup()
                .addGroup(desklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(desklevineLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalidesklevine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132)
                        .addComponent(jLabel48))
                    .addGroup(desklevineLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        desklevineLayout.setVerticalGroup(
            desklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, desklevineLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(desklevineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalidesklevine, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel48, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(desklevine, "card8");

        deskelzata.setBackground(new java.awt.Color(254, 164, 127));

        jLabel40.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(109, 33, 79));
        jLabel40.setText("HIJAB - ELZATA");

        kembalideskelzata.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskelzata.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskelzata.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskelzataMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskelzataMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskelzataMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskelzataMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskelzataMouseReleased(evt);
            }
        });

        kembalidiario1.setBackground(new java.awt.Color(248, 239, 186));
        kembalidiario1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalidiario1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalideskelzataLayout = new javax.swing.GroupLayout(kembalideskelzata);
        kembalideskelzata.setLayout(kembalideskelzataLayout);
        kembalideskelzataLayout.setHorizontalGroup(
            kembalideskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalidiario1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskelzataLayout.setVerticalGroup(
            kembalideskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalidiario1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel32.setBackground(new java.awt.Color(248, 239, 186));

        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setText("icon");
        jLabel41.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsielzata.setEditable(false);
        tksdeskripsielzata.setBorder(null);
        tksdeskripsielzata.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane3.setViewportView(tksdeskripsielzata);

        jLabel42.setForeground(new java.awt.Color(109, 33, 79));
        jLabel42.setText("Nama ");

        jLabel43.setText("Bahan ");

        jLabel44.setText("Warna");

        jLabel45.setText("Harga");

        jLabel46.setText("Ukuran");

        jLabel47.setText("Stock");

        tkswarnaelzata.setEditable(false);

        tksbahanelzata.setEditable(false);

        tkshargaelzata.setEditable(false);

        tksukuranelzata.setEditable(false);

        tksstockelzata.setEditable(false);

        tksnamaelzata.setEditable(false);

        checkelzata.setText("Check out");
        checkelzata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkelzataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel42)
                            .addComponent(jLabel43))
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel32Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel44))
                            .addGroup(jPanel32Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel45)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel46)
                            .addComponent(jLabel47))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahanelzata, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamaelzata))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnaelzata)
                            .addComponent(tkshargaelzata, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukuranelzata, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockelzata, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkelzata)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel42)
                            .addComponent(jLabel44)
                            .addComponent(jLabel46))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnaelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukuranelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamaelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel43)
                            .addComponent(jLabel45)
                            .addComponent(jLabel47))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahanelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargaelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkelzata)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskelzataLayout = new javax.swing.GroupLayout(deskelzata);
        deskelzata.setLayout(deskelzataLayout);
        deskelzataLayout.setHorizontalGroup(
            deskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskelzataLayout.createSequentialGroup()
                .addGroup(deskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskelzataLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskelzata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132)
                        .addComponent(jLabel40))
                    .addGroup(deskelzataLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskelzataLayout.setVerticalGroup(
            deskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskelzataLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskelzataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskelzata, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskelzata, "card8");

        deskdiario.setBackground(new java.awt.Color(254, 164, 127));

        jLabel32.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(109, 33, 79));
        jLabel32.setText("HIJAB - DIARIO");

        kembalideskdiario.setBackground(new java.awt.Color(248, 239, 186));
        kembalideskdiario.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalideskdiario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalideskdiarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalideskdiarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalideskdiarioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalideskdiarioMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalideskdiarioMouseReleased(evt);
            }
        });

        kembalidiario.setBackground(new java.awt.Color(248, 239, 186));
        kembalidiario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalidiario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N
        kembalidiario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidiarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidiarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidiarioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidiarioMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidiarioMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout kembalideskdiarioLayout = new javax.swing.GroupLayout(kembalideskdiario);
        kembalideskdiario.setLayout(kembalideskdiarioLayout);
        kembalideskdiarioLayout.setHorizontalGroup(
            kembalideskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalidiario, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
        );
        kembalideskdiarioLayout.setVerticalGroup(
            kembalideskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalidiario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel31.setBackground(new java.awt.Color(248, 239, 186));

        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("icon");
        jLabel33.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        tksdeskripsidiario.setEditable(false);
        tksdeskripsidiario.setBorder(null);
        tksdeskripsidiario.setForeground(new java.awt.Color(109, 33, 79));
        jScrollPane2.setViewportView(tksdeskripsidiario);

        jLabel34.setForeground(new java.awt.Color(109, 33, 79));
        jLabel34.setText("Nama ");

        jLabel35.setText("Bahan ");

        jLabel36.setText("Warna");

        jLabel37.setText("Harga");

        jLabel38.setText("Ukuran");

        jLabel39.setText("Stock");

        tkswarnadiario.setEditable(false);

        tksbahandiario.setEditable(false);

        tkshargadiario.setEditable(false);

        tksukurandiario.setEditable(false);

        tksstockdiario.setEditable(false);

        tksnamadiario.setEditable(false);

        checkdiario.setText("Check out");
        checkdiario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkdiarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(jLabel35))
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel31Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel36))
                            .addGroup(jPanel31Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel37)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38)
                            .addComponent(jLabel39))
                        .addGap(51, 51, 51))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tksbahandiario, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(tksnamadiario))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tkswarnadiario)
                            .addComponent(tkshargadiario, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tksukurandiario, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockdiario, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkdiario)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(jLabel36)
                            .addComponent(jLabel38))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tkswarnadiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksukurandiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksnamadiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(jLabel37)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tksbahandiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tkshargadiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tksstockdiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(checkdiario)
                .addContainerGap())
        );

        javax.swing.GroupLayout deskdiarioLayout = new javax.swing.GroupLayout(deskdiario);
        deskdiario.setLayout(deskdiarioLayout);
        deskdiarioLayout.setHorizontalGroup(
            deskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deskdiarioLayout.createSequentialGroup()
                .addGroup(deskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(deskdiarioLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalideskdiario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132)
                        .addComponent(jLabel32))
                    .addGroup(deskdiarioLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        deskdiarioLayout.setVerticalGroup(
            deskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, deskdiarioLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(deskdiarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(kembalideskdiario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        mainpanel.add(deskdiario, "card8");

        Transaksi.setBackground(new java.awt.Color(189, 197, 129));

        jLabel260.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 24)); // NOI18N
        jLabel260.setForeground(new java.awt.Color(109, 33, 79));
        jLabel260.setText("PEMBAYARAN");

        jPanel88.setBackground(new java.awt.Color(248, 239, 186));
        jPanel88.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));

        jLabel11.setText("Nama Barang");

        namatransaksi.setEditable(false);

        jLabel12.setText("Ukuran");

        ukurantransaksi.setEditable(false);

        jLabel13.setText("Warna");

        warnatransaksi.setEditable(false);

        jLabel14.setText("Harga");

        hargatransaksi.setEditable(false);

        jLabel261.setText("Jumlah Pesanan");

        jLabel262.setText("Total harga");

        totaltransaksi.setEditable(false);

        bayar.setText("BAYAR");
        bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bayarActionPerformed(evt);
            }
        });

        hitung.setText("tambahkan");
        hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hitungActionPerformed(evt);
            }
        });

        jLabel263.setText("Nominal uang");

        Validasinominal.setForeground(new java.awt.Color(204, 0, 0));

        javax.swing.GroupLayout jPanel88Layout = new javax.swing.GroupLayout(jPanel88);
        jPanel88.setLayout(jPanel88Layout);
        jPanel88Layout.setHorizontalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel88Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel14)
                    .addGroup(jPanel88Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(40, 40, 40)
                        .addComponent(jLabel13))
                    .addComponent(jLabel11)
                    .addComponent(namatransaksi)
                    .addGroup(jPanel88Layout.createSequentialGroup()
                        .addComponent(ukurantransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(warnatransaksi, javax.swing.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE))
                    .addComponent(hargatransaksi))
                .addGap(53, 53, 53)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Validasinominal, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel88Layout.createSequentialGroup()
                        .addComponent(nominal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bayar))
                    .addComponent(jumlahtransaksi)
                    .addComponent(jLabel262, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totaltransaksi, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                    .addComponent(jLabel261, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hitung)
                    .addComponent(jLabel263, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel88Layout.setVerticalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel88Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel261))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(namatransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jumlahtransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(hitung))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ukurantransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(warnatransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel262))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hargatransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totaltransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel263)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bayar)
                    .addComponent(nominal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Validasinominal, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        kembalidesktuneeca1.setBackground(new java.awt.Color(248, 239, 186));
        kembalidesktuneeca1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        kembalidesktuneeca1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembalidesktuneeca1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                kembalidesktuneeca1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                kembalidesktuneeca1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kembalidesktuneeca1MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                kembalidesktuneeca1MouseReleased(evt);
            }
        });

        kembalibayar.setBackground(new java.awt.Color(248, 239, 186));
        kembalibayar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kembalibayar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/appbusanamuslimah/—Pngtree—vector back icon_4267356.png"))); // NOI18N

        javax.swing.GroupLayout kembalidesktuneeca1Layout = new javax.swing.GroupLayout(kembalidesktuneeca1);
        kembalidesktuneeca1.setLayout(kembalidesktuneeca1Layout);
        kembalidesktuneeca1Layout.setHorizontalGroup(
            kembalidesktuneeca1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kembalidesktuneeca1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(kembalibayar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        kembalidesktuneeca1Layout.setVerticalGroup(
            kembalidesktuneeca1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kembalibayar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout TransaksiLayout = new javax.swing.GroupLayout(Transaksi);
        Transaksi.setLayout(TransaksiLayout);
        TransaksiLayout.setHorizontalGroup(
            TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TransaksiLayout.createSequentialGroup()
                .addGroup(TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TransaksiLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(kembalidesktuneeca1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(133, 133, 133)
                        .addComponent(jLabel260))
                    .addGroup(TransaksiLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jPanel88, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        TransaksiLayout.setVerticalGroup(
            TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TransaksiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel260, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(kembalidesktuneeca1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32)
                .addComponent(jPanel88, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );

        mainpanel.add(Transaksi, "card32");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(mainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 387, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnhomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseEntered
        // TODO add your handling code here:
        btnhome.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_btnhomeMouseEntered

    private void btnhomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseExited
        // TODO add your handling code here:
        btnhome.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_btnhomeMouseExited

    private void btnhomeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMousePressed
        // TODO add your handling code here:
        btnhome.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_btnhomeMousePressed

    private void btnhomeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseReleased
        // TODO add your handling code here:
        btnhome.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_btnhomeMouseReleased

    private void btnkategoriMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnkategoriMouseEntered
        // TODO add your handling code here:
        btnkategori.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_btnkategoriMouseEntered

    private void btnkategoriMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnkategoriMouseExited
        // TODO add your handling code here:
        btnkategori.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_btnkategoriMouseExited

    private void btnkategoriMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnkategoriMousePressed
        // TODO add your handling code here:
        btnkategori.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_btnkategoriMousePressed

    private void btnkategoriMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnkategoriMouseReleased
        // TODO add your handling code here:
        btnkategori.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_btnkategoriMouseReleased

    private void logoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseEntered
        // TODO add your handling code here:
        logout.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_logoutMouseEntered

    private void logoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseExited
        // TODO add your handling code here:
        logout.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_logoutMouseExited

    private void logoutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMousePressed
        // TODO add your handling code here:
        logout.setBackground(new Color(242,242,242));
    }//GEN-LAST:event_logoutMousePressed

    private void logoutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseReleased
        // TODO add your handling code here:
        logout.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_logoutMouseReleased

    private void btnhomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseClicked
        // TODO add your handling code here:
        // remove panel
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(homepanel);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnhomeMouseClicked

    private void btnkategoriMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnkategoriMouseClicked
        // TODO add your handling code here:
        // remove panel
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategori);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnkategoriMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        // TODO add your handling code here:
        int dialogBtn = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(rootPane, "Apakah anda yakin keluar?","PERINGATAN!",dialogBtn);
        // Jika pengguna memilih "Yes" (atau "OK" tergantung pada bahasa yang digunakan)
if (dialogResult == JOptionPane.YES_OPTION) {
    Login n = new Login();
    n.setVisible(true);
    
    mainpanel.add(homepanel).setVisible(false);
    mainpanel.repaint();
    mainpanel.revalidate();
} else {
    // Jika pengguna memilih "No", tidak lakukan apa-apa atau tambahkan kode lain sesuai kebutuhan Anda.
    // Jika Anda tidak memerlukan tindakan khusus saat memilih "No", Anda mungkin tidak perlu menambahkan blok else ini.
}
    }//GEN-LAST:event_logoutMouseClicked

    private void pilihhijabMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihhijabMousePressed
        // TODO add your handling code here:
        pilihhijab.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihhijabMousePressed

    private void pilihhijabMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihhijabMouseReleased
        // TODO add your handling code here:
        pilihhijab.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihhijabMouseReleased

    private void pilihhijabMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihhijabMouseEntered
        // TODO add your handling code here:
        pilihhijab.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihhijabMouseEntered

    private void pilihhijabMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihhijabMouseExited
        // TODO add your handling code here:
        pilihhijab.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihhijabMouseExited

    private void pilihhijabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihhijabMouseClicked
        // TODO add your handling code here:
        // remove panel
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_pilihhijabMouseClicked

    private void pilihbajuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihbajuMouseEntered
        // TODO add your handling code here:
        pilihbaju.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihbajuMouseEntered

    private void pilihbajuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihbajuMouseExited
        // TODO add your handling code here:
        pilihbaju.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihbajuMouseExited

    private void pilihbajuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihbajuMousePressed
        // TODO add your handling code here:
        pilihbaju.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihbajuMousePressed

    private void pilihbajuMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihbajuMouseReleased
        // TODO add your handling code here:
        pilihbaju.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihbajuMouseReleased

    private void pilihmukenaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihmukenaMouseEntered
        // TODO add your handling code here:
        pilihmukena.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihmukenaMouseEntered

    private void pilihmukenaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihmukenaMouseExited
        // TODO add your handling code here:
        pilihmukena.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihmukenaMouseExited

    private void pilihmukenaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihmukenaMousePressed
        // TODO add your handling code here:
        pilihmukena.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_pilihmukenaMousePressed

    private void pilihmukenaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihmukenaMouseReleased
        // TODO add your handling code here:
        pilihmukena.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_pilihmukenaMouseReleased

    private void pilihbajuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihbajuMouseClicked
        // TODO add your handling code here:
        // remove panel
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_pilihbajuMouseClicked

    private void pilihmukenaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pilihmukenaMouseClicked
        // TODO add your handling code here:
        // remove panel
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_pilihmukenaMouseClicked

    private void kembalihijabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalihijabMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategori);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalihijabMouseClicked

    private void kembalihijabMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalihijabMousePressed
        // TODO add your handling code here:
        kembalibaju.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalihijabMousePressed

    private void kembalihijabMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalihijabMouseReleased
        // TODO add your handling code here:
        kembalibaju.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalihijabMouseReleased

    private void kembalihijabMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalihijabMouseEntered
        // TODO add your handling code here:
        kembalihijab.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalihijabMouseEntered

    private void kembalihijabMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalihijabMouseExited
        // TODO add your handling code here:
        kembalihijab.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalihijabMouseExited

    private void btndiarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndiarioActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskdiario);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btndiarioActionPerformed

    private void btnelzataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnelzataActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskelzata);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnelzataActionPerformed

    private void btnpashminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpashminaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskpashmina);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnpashminaActionPerformed

    private void btnrabbaniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrabbaniActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskrabbani);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnrabbaniActionPerformed

    private void btnlevineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlevineActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(desklevine);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnlevineActionPerformed

    private void btnumamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnumamaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskumama);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnumamaActionPerformed

    private void btnshafiraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnshafiraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskshafira);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnshafiraActionPerformed

    private void btnzoyaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnzoyaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskzoya);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnzoyaActionPerformed

    private void kembalideskdiarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdiarioMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskdiarioMouseClicked

    private void kembalideskdiarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdiarioMouseEntered
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalideskdiarioMouseEntered

    private void kembalideskdiarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdiarioMouseExited
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalideskdiarioMouseExited

    private void kembalideskdiarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdiarioMousePressed
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalideskdiarioMousePressed

    private void kembalideskdiarioMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdiarioMouseReleased
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalideskdiarioMouseReleased

    private void kembalidiarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidiarioMouseEntered
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalidiarioMouseEntered

    private void kembalidiarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidiarioMouseExited
        // TODO add your handling code here:
        kembalidiario.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalidiarioMouseExited

    private void kembalidiarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidiarioMousePressed
        // TODO add your handling code here:
        kembalideskdiario.setBackground(new Color(248, 239, 186));
    }//GEN-LAST:event_kembalidiarioMousePressed

    private void kembalidiarioMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidiarioMouseReleased
        // TODO add your handling code here:
        kembalidiario.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_kembalidiarioMouseReleased

    private void kembalidiarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidiarioMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalidiarioMouseClicked

    private void kembalideskelzataMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskelzataMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskelzataMouseEntered

    private void kembalideskelzataMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskelzataMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskelzataMouseExited

    private void kembalideskelzataMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskelzataMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskelzataMousePressed

    private void kembalideskelzataMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskelzataMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskelzataMouseReleased

    private void kembalideskelzataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskelzataMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskelzataMouseClicked

    private void kembalidesklevineMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesklevineMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalidesklevineMouseClicked

    private void kembalidesklevineMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesklevineMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesklevineMouseEntered

    private void kembalidesklevineMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesklevineMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesklevineMouseExited

    private void kembalidesklevineMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesklevineMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesklevineMousePressed

    private void kembalidesklevineMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesklevineMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesklevineMouseReleased

    private void kembalideskpashminaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskpashminaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskpashminaMouseClicked

    private void kembalideskpashminaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskpashminaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskpashminaMouseEntered

    private void kembalideskpashminaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskpashminaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskpashminaMouseExited

    private void kembalideskpashminaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskpashminaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskpashminaMousePressed

    private void kembalideskpashminaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskpashminaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskpashminaMouseReleased

    private void kembalideskrabbaniMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrabbaniMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskrabbaniMouseClicked

    private void kembalideskrabbaniMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrabbaniMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrabbaniMouseEntered

    private void kembalideskrabbaniMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrabbaniMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrabbaniMouseExited

    private void kembalideskrabbaniMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrabbaniMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrabbaniMousePressed

    private void kembalideskrabbaniMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrabbaniMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrabbaniMouseReleased

    private void kembalideskshafiraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskshafiraMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskshafiraMouseClicked

    private void kembalideskshafiraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskshafiraMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskshafiraMouseEntered

    private void kembalideskshafiraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskshafiraMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskshafiraMouseExited

    private void kembalideskshafiraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskshafiraMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskshafiraMousePressed

    private void kembalideskshafiraMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskshafiraMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskshafiraMouseReleased

    private void kembalideskumamaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskumamaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskumamaMouseClicked

    private void kembalideskumamaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskumamaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskumamaMouseEntered

    private void kembalideskumamaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskumamaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskumamaMouseExited

    private void kembalideskumamaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskumamaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskumamaMousePressed

    private void kembalideskumamaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskumamaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskumamaMouseReleased

    private void kembalideskzoyaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzoyaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorihijab);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskzoyaMouseClicked

    private void kembalideskzoyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzoyaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzoyaMouseEntered

    private void kembalideskzoyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzoyaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzoyaMouseExited

    private void kembalideskzoyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzoyaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzoyaMousePressed

    private void kembalideskzoyaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzoyaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzoyaMouseReleased

    private void kembalibajuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalibajuMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategori);
        mainpanel.repaint();
        mainpanel.revalidate();
        
    }//GEN-LAST:event_kembalibajuMouseClicked

    private void kembalibajuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalibajuMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalibajuMouseEntered

    private void kembalibajuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalibajuMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalibajuMouseExited

    private void kembalibajuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalibajuMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalibajuMousePressed

    private void kembalibajuMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalibajuMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalibajuMouseReleased

    private void btnmonelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmonelActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskmonel);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnmonelActionPerformed

    private void btnriamirandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnriamirandaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskrianmiranda);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnriamirandaActionPerformed

    private void btnhauraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhauraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskhaura);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnhauraActionPerformed

    private void btnbabyheluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbabyheluActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskbabyhelu);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnbabyheluActionPerformed

    private void btndianpelangiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndianpelangiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskdianpelangi);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btndianpelangiActionPerformed

    private void btnzmnowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnzmnowActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskzmnow);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnzmnowActionPerformed

    private void btntuneecaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntuneecaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(desktuneeca);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btntuneecaActionPerformed

    private void btnmelikaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmelikaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskmelika);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnmelikaActionPerformed

    private void kembalimukenaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalimukenaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategori);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalimukenaMouseClicked

    private void kembalimukenaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalimukenaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalimukenaMouseEntered

    private void kembalimukenaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalimukenaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalimukenaMouseExited

    private void kembalimukenaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalimukenaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalimukenaMousePressed

    private void kembalimukenaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalimukenaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalimukenaMouseReleased

    private void btnhalimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhalimaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskhalima);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnhalimaActionPerformed

    private void btnazzuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnazzuraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskazzura);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnazzuraActionPerformed

    private void btntazbiyaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntazbiyaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(desktazbiya);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btntazbiyaActionPerformed

    private void btnalganiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnalganiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskalgani);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnalganiActionPerformed

    private void btntatuisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntatuisActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(desktatuis);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btntatuisActionPerformed

    private void btnghanimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnghanimiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskghanimi);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnghanimiActionPerformed

    private void btnabayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnabayaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskabaya);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnabayaActionPerformed

    private void btnponcoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnponcoActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskponco);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_btnponcoActionPerformed

    private void kembalideskbabyheluMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskbabyheluMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskbabyheluMouseClicked

    private void kembalideskbabyheluMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskbabyheluMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskbabyheluMouseEntered

    private void kembalideskbabyheluMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskbabyheluMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskbabyheluMouseExited

    private void kembalideskbabyheluMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskbabyheluMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskbabyheluMousePressed

    private void kembalideskbabyheluMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskbabyheluMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskbabyheluMouseReleased

    private void kembalideskdianpelangiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdianpelangiMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskdianpelangiMouseClicked

    private void kembalideskdianpelangiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdianpelangiMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskdianpelangiMouseEntered

    private void kembalideskdianpelangiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdianpelangiMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskdianpelangiMouseExited

    private void kembalideskdianpelangiMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdianpelangiMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskdianpelangiMousePressed

    private void kembalideskdianpelangiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskdianpelangiMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskdianpelangiMouseReleased

    private void kembalideskhauraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhauraMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskhauraMouseClicked

    private void kembalideskhauraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhauraMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhauraMouseEntered

    private void kembalideskhauraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhauraMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhauraMouseExited

    private void kembalideskhauraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhauraMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhauraMousePressed

    private void kembalideskhauraMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhauraMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhauraMouseReleased

    private void kembalideskmelikaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmelikaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskmelikaMouseClicked

    private void kembalideskmelikaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmelikaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmelikaMouseEntered

    private void kembalideskmelikaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmelikaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmelikaMouseExited

    private void kembalideskmelikaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmelikaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmelikaMousePressed

    private void kembalideskmelikaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmelikaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmelikaMouseReleased

    private void kembalideskmonelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmonelMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskmonelMouseClicked

    private void kembalideskmonelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmonelMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmonelMouseEntered

    private void kembalideskmonelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmonelMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmonelMouseExited

    private void kembalideskmonelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmonelMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmonelMousePressed

    private void kembalideskmonelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskmonelMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskmonelMouseReleased

    private void kembalideskrianmirandaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrianmirandaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskrianmirandaMouseClicked

    private void kembalideskrianmirandaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrianmirandaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrianmirandaMouseEntered

    private void kembalideskrianmirandaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrianmirandaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrianmirandaMouseExited

    private void kembalideskrianmirandaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrianmirandaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrianmirandaMousePressed

    private void kembalideskrianmirandaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskrianmirandaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskrianmirandaMouseReleased

    private void kembalidesktuneecaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneecaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalidesktuneecaMouseClicked

    private void kembalidesktuneecaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneecaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneecaMouseEntered

    private void kembalidesktuneecaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneecaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneecaMouseExited

    private void kembalidesktuneecaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneecaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneecaMousePressed

    private void kembalidesktuneecaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneecaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneecaMouseReleased

    private void kembalideskzmnowMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzmnowMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategoribaju);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskzmnowMouseClicked

    private void kembalideskzmnowMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzmnowMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzmnowMouseEntered

    private void kembalideskzmnowMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzmnowMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzmnowMouseExited

    private void kembalideskzmnowMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzmnowMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzmnowMousePressed

    private void kembalideskzmnowMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskzmnowMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskzmnowMouseReleased

    private void kembalideskabayaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskabayaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskabayaMouseClicked

    private void kembalideskabayaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskabayaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskabayaMouseEntered

    private void kembalideskabayaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskabayaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskabayaMouseExited

    private void kembalideskabayaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskabayaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskabayaMousePressed

    private void kembalideskabayaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskabayaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskabayaMouseReleased

    private void kembalideskalganiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskalganiMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskalganiMouseClicked

    private void kembalideskalganiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskalganiMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskalganiMouseEntered

    private void kembalideskalganiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskalganiMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskalganiMouseExited

    private void kembalideskalganiMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskalganiMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskalganiMousePressed

    private void kembalideskalganiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskalganiMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskalganiMouseReleased

    private void kembalideskghanimiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskghanimiMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskghanimiMouseClicked

    private void kembalideskghanimiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskghanimiMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskghanimiMouseEntered

    private void kembalideskghanimiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskghanimiMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskghanimiMouseExited

    private void kembalideskghanimiMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskghanimiMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskghanimiMousePressed

    private void kembalideskghanimiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskghanimiMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskghanimiMouseReleased

    private void kembalideskhalimaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhalimaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskhalimaMouseClicked

    private void kembalideskhalimaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhalimaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhalimaMouseEntered

    private void kembalideskhalimaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhalimaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhalimaMouseExited

    private void kembalideskhalimaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhalimaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhalimaMousePressed

    private void kembalideskhalimaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskhalimaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskhalimaMouseReleased

    private void kembalideskponcoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskponcoMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskponcoMouseClicked

    private void kembalideskponcoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskponcoMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskponcoMouseEntered

    private void kembalideskponcoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskponcoMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskponcoMouseExited

    private void kembalideskponcoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskponcoMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskponcoMousePressed

    private void kembalideskponcoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskponcoMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskponcoMouseReleased

    private void kembalidesktatuisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktatuisMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalidesktatuisMouseClicked

    private void kembalidesktatuisMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktatuisMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktatuisMouseEntered

    private void kembalidesktatuisMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktatuisMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktatuisMouseExited

    private void kembalidesktatuisMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktatuisMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktatuisMousePressed

    private void kembalidesktatuisMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktatuisMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktatuisMouseReleased

    private void kembalidesktazbiyaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktazbiyaMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalidesktazbiyaMouseClicked

    private void kembalidesktazbiyaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktazbiyaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktazbiyaMouseEntered

    private void kembalidesktazbiyaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktazbiyaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktazbiyaMouseExited

    private void kembalidesktazbiyaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktazbiyaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktazbiyaMousePressed

    private void kembalidesktazbiyaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktazbiyaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktazbiyaMouseReleased

    private void kembalideskazzuraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskazzuraMouseClicked
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(kategorimukena);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_kembalideskazzuraMouseClicked

    private void kembalideskazzuraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskazzuraMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskazzuraMouseEntered

    private void kembalideskazzuraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskazzuraMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskazzuraMouseExited

    private void kembalideskazzuraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskazzuraMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskazzuraMousePressed

    private void kembalideskazzuraMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalideskazzuraMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalideskazzuraMouseReleased

    private void tkshargababyheluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tkshargababyheluActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tkshargababyheluActionPerformed

    private void checkabayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkabayaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
        
        
        namatransaksi.setText(Abayamukena.getNama());
        ukurantransaksi.setText(String.valueOf(Abayamukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Abayamukena.getHarga()));
        warnatransaksi.setText(Abayamukena.getWarna());
                
    }//GEN-LAST:event_checkabayaActionPerformed

    private void kembalidesktuneeca1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneeca1MouseClicked
        // TODO add your handling code here:
        int dialogBtn = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(rootPane, "Apakah anda yakin keluar dari transaksi pembayaran?","PERINGATAN!",dialogBtn);
        mainpanel.add(Transaksi).setVisible(false);  // Tampilkan Transaksi kembali
        mainpanel.repaint();
        mainpanel.revalidate();
        if(dialogResult == 0){
        //kondisi benar
        mainpanel.add(homepanel).setVisible(true);
        mainpanel.repaint();
        mainpanel.revalidate();
        }else{
        }
    }//GEN-LAST:event_kembalidesktuneeca1MouseClicked

    private void kembalidesktuneeca1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneeca1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneeca1MouseEntered

    private void kembalidesktuneeca1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneeca1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneeca1MouseExited

    private void kembalidesktuneeca1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneeca1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneeca1MousePressed

    private void kembalidesktuneeca1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalidesktuneeca1MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalidesktuneeca1MouseReleased

    private void hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hitungActionPerformed
        // TODO add your handling code here:
        try {
        // Ambil jumlah dari JTextField
        double jumlah = Double.parseDouble(jumlahtransaksi.getText());
        
        // Ambil harga dari hargatransaksi yang telah diperbarui sesuai dengan kelas yang dipilih
        double harga = Double.parseDouble(hargatransaksi.getText());
        
        // Hitung total harga
        double total = harga * jumlah;
        
        // Menampilkan total harga dalam bentuk biner
        int totalInt = (int) total; 
        totaltransaksi.setText(String.format("%.2f", total));
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Masukkan angka yang valid!");
    }
    }//GEN-LAST:event_hitungActionPerformed

    private void checkalganiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkalganiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Alganimukena.getNama());
        ukurantransaksi.setText(String.valueOf(Alganimukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Alganimukena.getHarga()));
        warnatransaksi.setText(Alganimukena.getWarna());
    }//GEN-LAST:event_checkalganiActionPerformed

    private void checkazzuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkazzuraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Azzuramukena.getNama());
        ukurantransaksi.setText(String.valueOf(Azzuramukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Azzuramukena.getHarga()));
        warnatransaksi.setText(Azzuramukena.getWarna());
    }//GEN-LAST:event_checkazzuraActionPerformed

    private void checkghanimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkghanimiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Ghanimimukena.getNama());
        ukurantransaksi.setText(String.valueOf(Ghanimimukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Ghanimimukena.getHarga()));
        warnatransaksi.setText(Ghanimimukena.getWarna());
    }//GEN-LAST:event_checkghanimiActionPerformed

    private void chechhalimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chechhalimaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Halimamukena.getNama());
        ukurantransaksi.setText(String.valueOf(Halimamukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Halimamukena.getHarga()));
        warnatransaksi.setText(Halimamukena.getWarna());
    }//GEN-LAST:event_chechhalimaActionPerformed

    private void checkponcoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkponcoActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Poncomukena.getNama());
        ukurantransaksi.setText(String.valueOf(Poncomukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Poncomukena.getHarga()));
        warnatransaksi.setText(Poncomukena.getWarna());
    }//GEN-LAST:event_checkponcoActionPerformed

    private void checktatuisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checktatuisActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Tatuismukena.getNama());
        ukurantransaksi.setText(String.valueOf(Tatuismukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Tatuismukena.getHarga()));
        warnatransaksi.setText(Tatuismukena.getWarna());
    }//GEN-LAST:event_checktatuisActionPerformed

    private void checktazbiyaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checktazbiyaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Tazbiyamukena.getNama());
        ukurantransaksi.setText(String.valueOf(Tazbiyamukena.getUkuran()));
        hargatransaksi.setText(String.valueOf(Tazbiyamukena.getHarga()));
        warnatransaksi.setText(Tazbiyamukena.getWarna());
    }//GEN-LAST:event_checktazbiyaActionPerformed

    private void checkbabyheluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkbabyheluActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Babyhelubaju.getNama());
        ukurantransaksi.setText(String.valueOf(Babyhelubaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Babyhelubaju.getHarga()));
        warnatransaksi.setText(Babyhelubaju.getWarna());
    }//GEN-LAST:event_checkbabyheluActionPerformed

    private void checkdianpelangiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkdianpelangiActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Dianpelangibaju.getNama());
        ukurantransaksi.setText(String.valueOf(Dianpelangibaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Dianpelangibaju.getHarga()));
        warnatransaksi.setText(Dianpelangibaju.getWarna());
    }//GEN-LAST:event_checkdianpelangiActionPerformed

    private void checkhauraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkhauraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Haurabaju.getNama());
        ukurantransaksi.setText(String.valueOf(Haurabaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Haurabaju.getHarga()));
        warnatransaksi.setText(Haurabaju.getWarna());
    }//GEN-LAST:event_checkhauraActionPerformed

    private void checkmelikaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkmelikaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Melikabaju.getNama());
        ukurantransaksi.setText(String.valueOf(Melikabaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Melikabaju.getHarga()));
        warnatransaksi.setText(Melikabaju.getWarna());
    }//GEN-LAST:event_checkmelikaActionPerformed

    private void checkmonelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkmonelActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Monelbaju.getNama());
        ukurantransaksi.setText(String.valueOf(Monelbaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Monelbaju.getHarga()));
        warnatransaksi.setText(Monelbaju.getWarna());
    }//GEN-LAST:event_checkmonelActionPerformed

    private void checkmirandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkmirandaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Riamirandabaju.getNama());
        ukurantransaksi.setText(String.valueOf(Riamirandabaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Riamirandabaju.getHarga()));
        warnatransaksi.setText(Riamirandabaju.getWarna());
    }//GEN-LAST:event_checkmirandaActionPerformed

    private void checktuneecaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checktuneecaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Tuneecabaju.getNama());
        ukurantransaksi.setText(String.valueOf(Tuneecabaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Tuneecabaju.getHarga()));
        warnatransaksi.setText(Tuneecabaju.getWarna());
    }//GEN-LAST:event_checktuneecaActionPerformed

    private void checkzmnowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkzmnowActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Zmnowbaju.getNama());
        ukurantransaksi.setText(String.valueOf(Zmnowbaju.getUkuran()));
        hargatransaksi.setText(String.valueOf(Zmnowbaju.getHarga()));
        warnatransaksi.setText(Zmnowbaju.getWarna());
    }//GEN-LAST:event_checkzmnowActionPerformed

    private void checkzoyaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkzoyaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Zoyahijab.getNama());
        ukurantransaksi.setText(String.valueOf(Zoyahijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Zoyahijab.getHarga()));
        warnatransaksi.setText(Zoyahijab.getWarna());
    }//GEN-LAST:event_checkzoyaActionPerformed

    private void checkumamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkumamaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Umamahijab.getNama());
        ukurantransaksi.setText(String.valueOf(Umamahijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Umamahijab.getHarga()));
        warnatransaksi.setText(Umamahijab.getWarna());
    }//GEN-LAST:event_checkumamaActionPerformed

    private void checkshafiraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkshafiraActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Shafirahijab.getNama());
        ukurantransaksi.setText(String.valueOf(Shafirahijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Shafirahijab.getHarga()));
        warnatransaksi.setText(Shafirahijab.getWarna());
    }//GEN-LAST:event_checkshafiraActionPerformed

    private void checkrabbaniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkrabbaniActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Rabbanihijab.getNama());
        ukurantransaksi.setText(String.valueOf(Rabbanihijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Rabbanihijab.getHarga()));
        warnatransaksi.setText(Rabbanihijab.getWarna());
    }//GEN-LAST:event_checkrabbaniActionPerformed

    private void checkpashminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkpashminaActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Pashminahijab.getNama());
        ukurantransaksi.setText(String.valueOf(Pashminahijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Pashminahijab.getHarga()));
        warnatransaksi.setText(Pashminahijab.getWarna());
    }//GEN-LAST:event_checkpashminaActionPerformed

    private void checklevineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checklevineActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Levinehijab.getNama());
        ukurantransaksi.setText(String.valueOf(Levinehijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Levinehijab.getHarga()));
        warnatransaksi.setText(Levinehijab.getWarna());
    }//GEN-LAST:event_checklevineActionPerformed

    private void checkelzataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkelzataActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Elzatahijab.getNama());
        ukurantransaksi.setText(String.valueOf(Elzatahijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Elzatahijab.getHarga()));
        warnatransaksi.setText(Elzatahijab.getWarna());
    }//GEN-LAST:event_checkelzataActionPerformed

    private void checkdiarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkdiarioActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(Transaksi);
        mainpanel.repaint();
        mainpanel.revalidate();
                
        namatransaksi.setText(Diariohijab.getNama());
        ukurantransaksi.setText(String.valueOf(Diariohijab.getUkuran()));
        hargatransaksi.setText(String.valueOf(Diariohijab.getHarga()));
        warnatransaksi.setText(Diariohijab.getWarna());
    }//GEN-LAST:event_checkdiarioActionPerformed

    private void kembalilevine14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembalilevine14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalilevine14MouseClicked

    private void bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bayarActionPerformed
        // TODO add your handling code here:
        // Lakukan verifikasi
    String total = totaltransaksi.getText();

    // Periksa apakah totaltransaksi kosong
    if (total.trim().isEmpty()) {
        Validasinominal.setText("Mohon masukan jumlah pesanan anda");
    } else if (nominal.getText().equals(total)) {
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        mainpanel.add(homepanel);
        mainpanel.repaint();
        mainpanel.revalidate();
        
        Berhasil bd = new Berhasil();
            bd.setVisible(true);
            bd.pack();
            bd.setLocationRelativeTo(null);
    
    } else {
        Validasinominal.setText("Nominal kamu tidak sesuai");
    }

    }//GEN-LAST:event_bayarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskmonel);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskalgani);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskbabyhelu);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        mainpanel.removeAll();
        mainpanel.repaint();
        mainpanel.revalidate();
        // add panel
        mainpanel.add(deskrabbani);
        mainpanel.repaint();
        mainpanel.revalidate();
    }//GEN-LAST:event_jButton8ActionPerformed
    
    public void jalankan() {
        
    //teks kategori hijab
    
    tksdeskripsidiario.setText( Diariohijab.getDeskripsi());
    tksnamadiario.setText( Diariohijab.getNama());
    tkswarnadiario.setText( Diariohijab.getWarna());
    tksbahandiario.setText( Diariohijab.getBahan());
    tksukurandiario.setText(String.valueOf(Diariohijab.getUkuran()));
    tkshargadiario.setText(String.valueOf(Diariohijab.getHarga()));
    tksstockdiario.setText(String.valueOf(Diariohijab.getStock()));
    
    tksdeskripsielzata.setText( Elzatahijab.getDeskripsi());
    tksnamaelzata.setText( Elzatahijab.getNama());
    tkswarnaelzata.setText( Elzatahijab.getWarna());
    tksbahanelzata.setText( Elzatahijab.getBahan());
    tksukuranelzata.setText(String.valueOf(Elzatahijab.getUkuran()));
    tkshargaelzata.setText(String.valueOf(Elzatahijab.getHarga()));
    tksstockelzata.setText(String.valueOf(Elzatahijab.getStock()));
    
    tksdeskripsilevine.setText( Levinehijab.getDeskripsi());
    tksnamalevine.setText( Levinehijab.getNama());
    tkswarnalevine.setText( Levinehijab.getWarna());
    tksbahanlevine.setText( Levinehijab.getBahan());
    tksukuranlevine.setText(String.valueOf(Levinehijab.getUkuran()));
    tkshargalevine.setText(String.valueOf(Levinehijab.getHarga()));
    tksstocklevine.setText(String.valueOf(Levinehijab.getStock()));
    
    tksdeskripsipashmina.setText( Pashminahijab.getDeskripsi());
    tksnamapashmina.setText( Pashminahijab.getNama());
    tkswarnapashmina.setText( Pashminahijab.getWarna());
    tksbahanpashmina.setText( Pashminahijab.getBahan());
    tksukuranpashmina.setText(String.valueOf(Pashminahijab.getUkuran()));
    tkshargapashmina.setText(String.valueOf(Pashminahijab.getHarga()));
    tksstockpashmina.setText(String.valueOf(Pashminahijab.getStock()));
    
    tksdeskripsirabbani.setText( Rabbanihijab.getDeskripsi());
    tksnamarabbani.setText( Rabbanihijab.getNama());
    tkswarnarabbani.setText( Rabbanihijab.getWarna());
    tksbahanrabbani.setText( Rabbanihijab.getBahan());
    tksukuranrabbani.setText(String.valueOf(Rabbanihijab.getUkuran()));
    tkshargarabbani.setText(String.valueOf(Rabbanihijab.getHarga()));
    tksstockrabbani.setText(String.valueOf(Rabbanihijab.getStock()));
    
    tksdeskripsishafira.setText( Shafirahijab.getDeskripsi());
    tksnamashafira.setText( Shafirahijab.getNama());
    tkswarnashafira.setText( Shafirahijab.getWarna());
    tksbahanshafira.setText( Shafirahijab.getBahan());
    tksukuranshafira.setText(String.valueOf(Shafirahijab.getUkuran()));
    tkshargashafira.setText(String.valueOf(Shafirahijab.getHarga()));
    tksstockshafira.setText(String.valueOf(Shafirahijab.getStock()));
    
    tksdeskripsiumama.setText( Umamahijab.getDeskripsi());
    tksnamaumama.setText( Umamahijab.getNama());
    tkswarnaumama.setText( Umamahijab.getWarna());
    tksbahanumama.setText( Umamahijab.getBahan());
    tksukuranumama.setText(String.valueOf(Umamahijab.getUkuran()));
    tkshargaumama.setText(String.valueOf(Umamahijab.getHarga()));
    tksstockumama.setText(String.valueOf(Umamahijab.getStock()));
    
    tksdeskripsizoya.setText( Zoyahijab.getDeskripsi());
    tksnamazoya.setText( Zoyahijab.getNama());
    tkswarnazoya.setText( Zoyahijab.getWarna());
    tksbahanzoya.setText( Zoyahijab.getBahan());
    tksukuranzoya.setText(String.valueOf(Zoyahijab.getUkuran()));
    tkshargazoya.setText(String.valueOf(Zoyahijab.getHarga()));
    tksstockzoya.setText(String.valueOf(Zoyahijab.getStock()));
    
    //teks kategori baju
    
    tksdeskripsibabyhelu.setText( Babyhelubaju.getDeskripsi());
    tksnamababyhelu.setText( Babyhelubaju.getNama());
    tkswarnababyhelu.setText( Babyhelubaju.getWarna());
    tksbahanbabyhelu.setText( Babyhelubaju.getBahan());
    tksukuranbabyhelu.setText(String.valueOf(Babyhelubaju.getUkuran()));
    tkshargababyhelu.setText(String.valueOf(Babyhelubaju.getHarga()));
    tksstockbabyhelu.setText(String.valueOf(Babyhelubaju.getStock()));

    tksdeskripsidianpelangi.setText( Dianpelangibaju.getDeskripsi());
    tksnamadianpelangi.setText( Dianpelangibaju.getNama());
    tkswarnadianpelangi.setText( Dianpelangibaju.getWarna());
    tksbahandianpelangi.setText( Dianpelangibaju.getBahan());
    tksukurandianpelangi.setText(String.valueOf(Dianpelangibaju.getUkuran()));
    tkshargadianpelangi.setText(String.valueOf(Dianpelangibaju.getHarga()));
    tksstockdianpelangi.setText(String.valueOf(Dianpelangibaju.getStock()));
    
    tksdeskripsihaura.setText( Haurabaju.getDeskripsi());
    tksnamahaura.setText( Haurabaju.getNama());
    tkswarnahaura.setText( Haurabaju.getWarna());
    tksbahanhaura.setText( Haurabaju.getBahan());
    tksukuranhaura.setText(String.valueOf(Haurabaju.getUkuran()));
    tkshargahaura.setText(String.valueOf(Haurabaju.getHarga()));
    tksstockhaura.setText(String.valueOf(Haurabaju.getStock()));
    
    tksdeskripsimelika.setText( Melikabaju.getDeskripsi());
    tksnamamelika.setText( Melikabaju.getNama());
    tkswarnamelika.setText( Melikabaju.getWarna());
    tksbahanmelika.setText( Melikabaju.getBahan());
    tksukuranmelika.setText(String.valueOf(Melikabaju.getUkuran()));
    tkshargamelika.setText(String.valueOf(Melikabaju.getHarga()));
    tksstockmelika.setText(String.valueOf(Melikabaju.getStock()));
    
    tksdeskripsimonel.setText( Monelbaju.getDeskripsi());
    tksnamamonel.setText( Monelbaju.getNama());
    tkswarnamonel.setText( Monelbaju.getWarna());
    tksbahanmonel.setText( Monelbaju.getBahan());
    tksukuranmonel.setText(String.valueOf(Monelbaju.getUkuran()));
    tkshargamonel.setText(String.valueOf(Monelbaju.getHarga()));
    tksstockmonel.setText(String.valueOf(Monelbaju.getStock()));
    
    tksdeskripsimiranda.setText( Riamirandabaju.getDeskripsi());
    tksnamamiranda.setText( Riamirandabaju.getNama());
    tkswarnamiranda.setText( Riamirandabaju.getWarna());
    tksbahanmiranda.setText( Riamirandabaju.getBahan());
    tksukuranmiranda.setText(String.valueOf(Riamirandabaju.getUkuran()));
    tkshargamiranda.setText(String.valueOf(Riamirandabaju.getHarga()));
    tksstockmiranda.setText(String.valueOf(Riamirandabaju.getStock()));
    
    tksdeskripsituneeca.setText( Tuneecabaju.getDeskripsi());
    tksnamatuneeca.setText( Tuneecabaju.getNama());
    tkswarnatuneeca.setText( Tuneecabaju.getWarna());
    tksbahantuneeca.setText( Tuneecabaju.getBahan());
    tksukurantuneeca.setText(String.valueOf(Tuneecabaju.getUkuran()));
    tkshargatuneeca.setText(String.valueOf(Tuneecabaju.getHarga()));
    tksstocktuneeca.setText(String.valueOf(Tuneecabaju.getStock()));
    
    tksdeskripsizmnow.setText( Zmnowbaju.getDeskripsi());
    tksnamazmnow.setText( Zmnowbaju.getNama());
    tkswarnazmnow.setText( Zmnowbaju.getWarna());
    tksbahanzmnow.setText( Zmnowbaju.getBahan());
    tksukuranzmnow.setText(String.valueOf(Zmnowbaju.getUkuran()));
    tkshargazmnow.setText(String.valueOf(Zmnowbaju.getHarga()));
    tksstockzmnow.setText(String.valueOf(Zmnowbaju.getStock()));
    
    //teks kategori mukena
    
    tksdeskripsiabaya.setText( Abayamukena.getDeskripsi());
    tksnamaabaya.setText( Abayamukena.getNama());
    tkswarnaabaya.setText( Abayamukena.getWarna());
    tksbahanabaya.setText( Abayamukena.getBahan());
    tksukuranabaya.setText(String.valueOf(Abayamukena.getUkuran()));
    tkshargaabaya.setText(String.valueOf(Abayamukena.getHarga()));
    tksstockabaya.setText(String.valueOf(Abayamukena.getStock()));

    tksdeskripsialgani.setText( Alganimukena.getDeskripsi());
    tksnamaalgani.setText( Alganimukena.getNama());
    tkswarnaalgani.setText( Alganimukena.getWarna());
    tksbahanalgani.setText( Alganimukena.getBahan());
    tksukuranalgani.setText(String.valueOf(Alganimukena.getUkuran()));
    tkshargaalgani.setText(String.valueOf(Alganimukena.getHarga()));
    tksstockalgani.setText(String.valueOf(Alganimukena.getStock()));
    
    tksdeskripsiazzura.setText( Azzuramukena.getDeskripsi());
    tksnamaazzura.setText( Azzuramukena.getNama());
    tkswarnaazzura.setText( Azzuramukena.getWarna());
    tksbahanazzura.setText( Azzuramukena.getBahan());
    tksukuranazzura.setText(String.valueOf(Azzuramukena.getUkuran()));
    tkshargaazzura.setText(String.valueOf(Azzuramukena.getHarga()));
    tksstockazzura.setText(String.valueOf(Azzuramukena.getStock()));
    
    tksdeskripsighanimi.setText( Ghanimimukena.getDeskripsi());
    tksnamaghanimi.setText( Ghanimimukena.getNama());
    tkswarnaghanimi.setText( Ghanimimukena.getWarna());
    tksbahanghanimi.setText( Ghanimimukena.getBahan());
    tksukuranghanimi.setText(String.valueOf(Ghanimimukena.getUkuran()));
    tkshargaghanimi.setText(String.valueOf(Ghanimimukena.getHarga()));
    tksstockghanimi.setText(String.valueOf(Ghanimimukena.getStock()));
    
    tksdeskripsihalima.setText( Halimamukena.getDeskripsi());
    tksnamahalima.setText( Halimamukena.getNama());
    tkswarnahalima.setText( Halimamukena.getWarna());
    tksbahanhalima.setText( Halimamukena.getBahan());
    tksukuranhalima.setText(String.valueOf(Halimamukena.getUkuran()));
    tkshargahalima.setText(String.valueOf(Halimamukena.getHarga()));
    tksstockhalima.setText(String.valueOf(Halimamukena.getStock()));
    
    tksdeskripsiponco.setText( Poncomukena.getDeskripsi());
    tksnamaponco.setText( Poncomukena.getNama());
    tkswarnaponco.setText( Poncomukena.getWarna());
    tksbahanponco.setText( Poncomukena.getBahan());
    tksukuranponco.setText(String.valueOf(Poncomukena.getUkuran()));
    tkshargaponco.setText(String.valueOf(Poncomukena.getHarga()));
    tksstockponco.setText(String.valueOf(Poncomukena.getStock()));
    
    tksdeskripsitatuis.setText( Tatuismukena.getDeskripsi());
    tksnamatatuis.setText( Tatuismukena.getNama());
    tkswarnatatuis.setText( Tatuismukena.getWarna());
    tksbahantatuis.setText( Tatuismukena.getBahan());
    tksukurantatuis.setText(String.valueOf(Tatuismukena.getUkuran()));
    tkshargatatuis.setText(String.valueOf(Tatuismukena.getHarga()));
    tksstocktatuis.setText(String.valueOf(Tatuismukena.getStock()));
    
    tksdeskripsitazbiya.setText( Tazbiyamukena.getDeskripsi());
    tksnamatazbiya.setText( Tazbiyamukena.getNama());
    tkswarnatazbiya.setText( Tazbiyamukena.getWarna());
    tksbahantazbiya.setText( Tazbiyamukena.getBahan());
    tksukurantazbiya.setText(String.valueOf(Tazbiyamukena.getUkuran()));
    tkshargatazbiya.setText(String.valueOf(Tazbiyamukena.getHarga()));
    tksstocktazbiya.setText(String.valueOf(Tazbiyamukena.getStock()));
            

    }
       
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Beranda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Beranda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Beranda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Beranda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
    java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Beranda().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Hijab;
    private javax.swing.JLabel Hijab1;
    private javax.swing.JLabel Hijab2;
    private javax.swing.JPanel Transaksi;
    private javax.swing.JLabel Validasinominal;
    private javax.swing.JButton bayar;
    private javax.swing.JButton btnabaya;
    private javax.swing.JButton btnalgani;
    private javax.swing.JButton btnazzura;
    private javax.swing.JButton btnbabyhelu;
    private javax.swing.JButton btndianpelangi;
    private javax.swing.JButton btndiario;
    private javax.swing.JButton btnelzata;
    private javax.swing.JButton btnghanimi;
    private javax.swing.JButton btnhalima;
    private javax.swing.JButton btnhaura;
    private javax.swing.JPanel btnhome;
    private javax.swing.JPanel btnkategori;
    private javax.swing.JButton btnlevine;
    private javax.swing.JButton btnmelika;
    private javax.swing.JButton btnmonel;
    private javax.swing.JButton btnpashmina;
    private javax.swing.JButton btnponco;
    private javax.swing.JButton btnrabbani;
    private javax.swing.JButton btnriamiranda;
    private javax.swing.JButton btnshafira;
    private javax.swing.JButton btntatuis;
    private javax.swing.JButton btntazbiya;
    private javax.swing.JButton btntuneeca;
    private javax.swing.JButton btnumama;
    private javax.swing.JButton btnzmnow;
    private javax.swing.JButton btnzoya;
    private javax.swing.JButton chechhalima;
    private javax.swing.JButton checkabaya;
    private javax.swing.JButton checkalgani;
    private javax.swing.JButton checkazzura;
    private javax.swing.JButton checkbabyhelu;
    private javax.swing.JButton checkdianpelangi;
    private javax.swing.JButton checkdiario;
    private javax.swing.JButton checkelzata;
    private javax.swing.JButton checkghanimi;
    private javax.swing.JButton checkhaura;
    private javax.swing.JButton checklevine;
    private javax.swing.JButton checkmelika;
    private javax.swing.JButton checkmiranda;
    private javax.swing.JButton checkmonel;
    private javax.swing.JButton checkpashmina;
    private javax.swing.JButton checkponco;
    private javax.swing.JButton checkrabbani;
    private javax.swing.JButton checkshafira;
    private javax.swing.JButton checktatuis;
    private javax.swing.JButton checktazbiya;
    private javax.swing.JButton checktuneeca;
    private javax.swing.JButton checkumama;
    private javax.swing.JButton checkzmnow;
    private javax.swing.JButton checkzoya;
    private javax.swing.JPanel deskabaya;
    private javax.swing.JPanel deskalgani;
    private javax.swing.JPanel deskazzura;
    private javax.swing.JPanel deskbabyhelu;
    private javax.swing.JPanel deskdianpelangi;
    private javax.swing.JPanel deskdiario;
    private javax.swing.JPanel deskelzata;
    private javax.swing.JPanel deskghanimi;
    private javax.swing.JPanel deskhalima;
    private javax.swing.JPanel deskhaura;
    private javax.swing.JPanel desklevine;
    private javax.swing.JPanel deskmelika;
    private javax.swing.JPanel deskmonel;
    private javax.swing.JPanel deskpashmina;
    private javax.swing.JPanel deskponco;
    private javax.swing.JPanel deskrabbani;
    private javax.swing.JPanel deskrianmiranda;
    private javax.swing.JPanel deskshafira;
    private javax.swing.JPanel desktatuis;
    private javax.swing.JPanel desktazbiya;
    private javax.swing.JPanel desktuneeca;
    private javax.swing.JPanel deskumama;
    private javax.swing.JPanel deskzmnow;
    private javax.swing.JPanel deskzoya;
    private javax.swing.JTextField hargatransaksi;
    private javax.swing.JButton hitung;
    private javax.swing.JPanel homepanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel183;
    private javax.swing.JLabel jLabel184;
    private javax.swing.JLabel jLabel185;
    private javax.swing.JLabel jLabel186;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel188;
    private javax.swing.JLabel jLabel189;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel190;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel193;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel195;
    private javax.swing.JLabel jLabel196;
    private javax.swing.JLabel jLabel197;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel199;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel200;
    private javax.swing.JLabel jLabel201;
    private javax.swing.JLabel jLabel202;
    private javax.swing.JLabel jLabel203;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel222;
    private javax.swing.JLabel jLabel223;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel225;
    private javax.swing.JLabel jLabel226;
    private javax.swing.JLabel jLabel227;
    private javax.swing.JLabel jLabel228;
    private javax.swing.JLabel jLabel229;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel230;
    private javax.swing.JLabel jLabel231;
    private javax.swing.JLabel jLabel232;
    private javax.swing.JLabel jLabel233;
    private javax.swing.JLabel jLabel234;
    private javax.swing.JLabel jLabel235;
    private javax.swing.JLabel jLabel236;
    private javax.swing.JLabel jLabel237;
    private javax.swing.JLabel jLabel238;
    private javax.swing.JLabel jLabel239;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel240;
    private javax.swing.JLabel jLabel241;
    private javax.swing.JLabel jLabel242;
    private javax.swing.JLabel jLabel243;
    private javax.swing.JLabel jLabel244;
    private javax.swing.JLabel jLabel245;
    private javax.swing.JLabel jLabel246;
    private javax.swing.JLabel jLabel247;
    private javax.swing.JLabel jLabel248;
    private javax.swing.JLabel jLabel249;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel250;
    private javax.swing.JLabel jLabel251;
    private javax.swing.JLabel jLabel252;
    private javax.swing.JLabel jLabel253;
    private javax.swing.JLabel jLabel254;
    private javax.swing.JLabel jLabel255;
    private javax.swing.JLabel jLabel256;
    private javax.swing.JLabel jLabel257;
    private javax.swing.JLabel jLabel258;
    private javax.swing.JLabel jLabel259;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel260;
    private javax.swing.JLabel jLabel261;
    private javax.swing.JLabel jLabel262;
    private javax.swing.JLabel jLabel263;
    private javax.swing.JLabel jLabel265;
    private javax.swing.JLabel jLabel266;
    private javax.swing.JLabel jLabel267;
    private javax.swing.JLabel jLabel268;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel275;
    private javax.swing.JLabel jLabel276;
    private javax.swing.JLabel jLabel277;
    private javax.swing.JLabel jLabel278;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTextField jumlahtransaksi;
    private javax.swing.JPanel kategori;
    private javax.swing.JPanel kategoribaju;
    private javax.swing.JPanel kategorihijab;
    private javax.swing.JPanel kategorimukena;
    private javax.swing.JPanel kembalibaju;
    private javax.swing.JLabel kembalibayar;
    private javax.swing.JPanel kembalideskabaya;
    private javax.swing.JPanel kembalideskalgani;
    private javax.swing.JPanel kembalideskazzura;
    private javax.swing.JPanel kembalideskbabyhelu;
    private javax.swing.JPanel kembalideskdianpelangi;
    private javax.swing.JPanel kembalideskdiario;
    private javax.swing.JPanel kembalideskelzata;
    private javax.swing.JPanel kembalideskghanimi;
    private javax.swing.JPanel kembalideskhalima;
    private javax.swing.JPanel kembalideskhaura;
    private javax.swing.JPanel kembalidesklevine;
    private javax.swing.JPanel kembalideskmelika;
    private javax.swing.JPanel kembalideskmonel;
    private javax.swing.JPanel kembalideskpashmina;
    private javax.swing.JPanel kembalideskponco;
    private javax.swing.JPanel kembalideskrabbani;
    private javax.swing.JPanel kembalideskrianmiranda;
    private javax.swing.JPanel kembalideskshafira;
    private javax.swing.JPanel kembalidesktatuis;
    private javax.swing.JPanel kembalidesktazbiya;
    private javax.swing.JPanel kembalidesktuneeca;
    private javax.swing.JPanel kembalidesktuneeca1;
    private javax.swing.JPanel kembalideskumama;
    private javax.swing.JPanel kembalideskzmnow;
    private javax.swing.JPanel kembalideskzoya;
    private javax.swing.JLabel kembalidiario;
    private javax.swing.JLabel kembalidiario1;
    private javax.swing.JPanel kembalihijab;
    private javax.swing.JLabel kembalilevine;
    private javax.swing.JLabel kembalilevine1;
    private javax.swing.JLabel kembalilevine10;
    private javax.swing.JLabel kembalilevine11;
    private javax.swing.JLabel kembalilevine12;
    private javax.swing.JLabel kembalilevine13;
    private javax.swing.JLabel kembalilevine14;
    private javax.swing.JLabel kembalilevine15;
    private javax.swing.JLabel kembalilevine16;
    private javax.swing.JLabel kembalilevine17;
    private javax.swing.JLabel kembalilevine18;
    private javax.swing.JLabel kembalilevine19;
    private javax.swing.JLabel kembalilevine2;
    private javax.swing.JLabel kembalilevine20;
    private javax.swing.JLabel kembalilevine21;
    private javax.swing.JLabel kembalilevine3;
    private javax.swing.JLabel kembalilevine4;
    private javax.swing.JLabel kembalilevine5;
    private javax.swing.JLabel kembalilevine6;
    private javax.swing.JLabel kembalilevine7;
    private javax.swing.JLabel kembalilevine8;
    private javax.swing.JLabel kembalilevine9;
    private javax.swing.JPanel kembalimukena;
    private javax.swing.JPanel logout;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JLabel namapengguna;
    private javax.swing.JTextField namatransaksi;
    private javax.swing.JTextField nominal;
    private javax.swing.JButton pilihbaju;
    private javax.swing.JButton pilihhijab;
    private javax.swing.JButton pilihmukena;
    private javax.swing.JTextField tksbahanabaya;
    private javax.swing.JTextField tksbahanalgani;
    private javax.swing.JTextField tksbahanazzura;
    private javax.swing.JTextField tksbahanbabyhelu;
    private javax.swing.JTextField tksbahandianpelangi;
    private javax.swing.JTextField tksbahandiario;
    private javax.swing.JTextField tksbahanelzata;
    private javax.swing.JTextField tksbahanghanimi;
    private javax.swing.JTextField tksbahanhalima;
    private javax.swing.JTextField tksbahanhaura;
    private javax.swing.JTextField tksbahanlevine;
    private javax.swing.JTextField tksbahanmelika;
    private javax.swing.JTextField tksbahanmiranda;
    private javax.swing.JTextField tksbahanmonel;
    private javax.swing.JTextField tksbahanpashmina;
    private javax.swing.JTextField tksbahanponco;
    private javax.swing.JTextField tksbahanrabbani;
    private javax.swing.JTextField tksbahanshafira;
    private javax.swing.JTextField tksbahantatuis;
    private javax.swing.JTextField tksbahantazbiya;
    private javax.swing.JTextField tksbahantuneeca;
    private javax.swing.JTextField tksbahanumama;
    private javax.swing.JTextField tksbahanzmnow;
    private javax.swing.JTextField tksbahanzoya;
    private javax.swing.JTextPane tksdeskripsiabaya;
    private javax.swing.JTextPane tksdeskripsialgani;
    private javax.swing.JTextPane tksdeskripsiazzura;
    private javax.swing.JTextPane tksdeskripsibabyhelu;
    private javax.swing.JTextPane tksdeskripsidianpelangi;
    private javax.swing.JTextPane tksdeskripsidiario;
    private javax.swing.JTextPane tksdeskripsielzata;
    private javax.swing.JTextPane tksdeskripsighanimi;
    private javax.swing.JTextPane tksdeskripsihalima;
    private javax.swing.JTextPane tksdeskripsihaura;
    private javax.swing.JTextPane tksdeskripsilevine;
    private javax.swing.JTextPane tksdeskripsimelika;
    private javax.swing.JTextPane tksdeskripsimiranda;
    private javax.swing.JTextPane tksdeskripsimonel;
    private javax.swing.JTextPane tksdeskripsipashmina;
    private javax.swing.JTextPane tksdeskripsiponco;
    private javax.swing.JTextPane tksdeskripsirabbani;
    private javax.swing.JTextPane tksdeskripsishafira;
    private javax.swing.JTextPane tksdeskripsitatuis;
    private javax.swing.JTextPane tksdeskripsitazbiya;
    private javax.swing.JTextPane tksdeskripsituneeca;
    private javax.swing.JTextPane tksdeskripsiumama;
    private javax.swing.JTextPane tksdeskripsizmnow;
    private javax.swing.JTextPane tksdeskripsizoya;
    private javax.swing.JTextField tkshargaabaya;
    private javax.swing.JTextField tkshargaalgani;
    private javax.swing.JTextField tkshargaazzura;
    private javax.swing.JTextField tkshargababyhelu;
    private javax.swing.JTextField tkshargadianpelangi;
    private javax.swing.JTextField tkshargadiario;
    private javax.swing.JTextField tkshargaelzata;
    private javax.swing.JTextField tkshargaghanimi;
    private javax.swing.JTextField tkshargahalima;
    private javax.swing.JTextField tkshargahaura;
    private javax.swing.JTextField tkshargalevine;
    private javax.swing.JTextField tkshargamelika;
    private javax.swing.JTextField tkshargamiranda;
    private javax.swing.JTextField tkshargamonel;
    private javax.swing.JTextField tkshargapashmina;
    private javax.swing.JTextField tkshargaponco;
    private javax.swing.JTextField tkshargarabbani;
    private javax.swing.JTextField tkshargashafira;
    private javax.swing.JTextField tkshargatatuis;
    private javax.swing.JTextField tkshargatazbiya;
    private javax.swing.JTextField tkshargatuneeca;
    private javax.swing.JTextField tkshargaumama;
    private javax.swing.JTextField tkshargazmnow;
    private javax.swing.JTextField tkshargazoya;
    private javax.swing.JTextField tksnamaabaya;
    private javax.swing.JTextField tksnamaalgani;
    private javax.swing.JTextField tksnamaazzura;
    private javax.swing.JTextField tksnamababyhelu;
    private javax.swing.JTextField tksnamadianpelangi;
    private javax.swing.JTextField tksnamadiario;
    private javax.swing.JTextField tksnamaelzata;
    private javax.swing.JTextField tksnamaghanimi;
    private javax.swing.JTextField tksnamahalima;
    private javax.swing.JTextField tksnamahaura;
    private javax.swing.JTextField tksnamalevine;
    private javax.swing.JTextField tksnamamelika;
    private javax.swing.JTextField tksnamamiranda;
    private javax.swing.JTextField tksnamamonel;
    private javax.swing.JTextField tksnamapashmina;
    private javax.swing.JTextField tksnamaponco;
    private javax.swing.JTextField tksnamarabbani;
    private javax.swing.JTextField tksnamashafira;
    private javax.swing.JTextField tksnamatatuis;
    private javax.swing.JTextField tksnamatazbiya;
    private javax.swing.JTextField tksnamatuneeca;
    private javax.swing.JTextField tksnamaumama;
    private javax.swing.JTextField tksnamazmnow;
    private javax.swing.JTextField tksnamazoya;
    private javax.swing.JTextField tksstockabaya;
    private javax.swing.JTextField tksstockalgani;
    private javax.swing.JTextField tksstockazzura;
    private javax.swing.JTextField tksstockbabyhelu;
    private javax.swing.JTextField tksstockdianpelangi;
    private javax.swing.JTextField tksstockdiario;
    private javax.swing.JTextField tksstockelzata;
    private javax.swing.JTextField tksstockghanimi;
    private javax.swing.JTextField tksstockhalima;
    private javax.swing.JTextField tksstockhaura;
    private javax.swing.JTextField tksstocklevine;
    private javax.swing.JTextField tksstockmelika;
    private javax.swing.JTextField tksstockmiranda;
    private javax.swing.JTextField tksstockmonel;
    private javax.swing.JTextField tksstockpashmina;
    private javax.swing.JTextField tksstockponco;
    private javax.swing.JTextField tksstockrabbani;
    private javax.swing.JTextField tksstockshafira;
    private javax.swing.JTextField tksstocktatuis;
    private javax.swing.JTextField tksstocktazbiya;
    private javax.swing.JTextField tksstocktuneeca;
    private javax.swing.JTextField tksstockumama;
    private javax.swing.JTextField tksstockzmnow;
    private javax.swing.JTextField tksstockzoya;
    private javax.swing.JTextField tksukuranabaya;
    private javax.swing.JTextField tksukuranalgani;
    private javax.swing.JTextField tksukuranazzura;
    private javax.swing.JTextField tksukuranbabyhelu;
    private javax.swing.JTextField tksukurandianpelangi;
    private javax.swing.JTextField tksukurandiario;
    private javax.swing.JTextField tksukuranelzata;
    private javax.swing.JTextField tksukuranghanimi;
    private javax.swing.JTextField tksukuranhalima;
    private javax.swing.JTextField tksukuranhaura;
    private javax.swing.JTextField tksukuranlevine;
    private javax.swing.JTextField tksukuranmelika;
    private javax.swing.JTextField tksukuranmiranda;
    private javax.swing.JTextField tksukuranmonel;
    private javax.swing.JTextField tksukuranpashmina;
    private javax.swing.JTextField tksukuranponco;
    private javax.swing.JTextField tksukuranrabbani;
    private javax.swing.JTextField tksukuranshafira;
    private javax.swing.JTextField tksukurantatuis;
    private javax.swing.JTextField tksukurantazbiya;
    private javax.swing.JTextField tksukurantuneeca;
    private javax.swing.JTextField tksukuranumama;
    private javax.swing.JTextField tksukuranzmnow;
    private javax.swing.JTextField tksukuranzoya;
    private javax.swing.JTextField tkswarnaabaya;
    private javax.swing.JTextField tkswarnaalgani;
    private javax.swing.JTextField tkswarnaazzura;
    private javax.swing.JTextField tkswarnababyhelu;
    private javax.swing.JTextField tkswarnadianpelangi;
    private javax.swing.JTextField tkswarnadiario;
    private javax.swing.JTextField tkswarnaelzata;
    private javax.swing.JTextField tkswarnaghanimi;
    private javax.swing.JTextField tkswarnahalima;
    private javax.swing.JTextField tkswarnahaura;
    private javax.swing.JTextField tkswarnalevine;
    private javax.swing.JTextField tkswarnamelika;
    private javax.swing.JTextField tkswarnamiranda;
    private javax.swing.JTextField tkswarnamonel;
    private javax.swing.JTextField tkswarnapashmina;
    private javax.swing.JTextField tkswarnaponco;
    private javax.swing.JTextField tkswarnarabbani;
    private javax.swing.JTextField tkswarnashafira;
    private javax.swing.JTextField tkswarnatatuis;
    private javax.swing.JTextField tkswarnatazbiya;
    private javax.swing.JTextField tkswarnatuneeca;
    private javax.swing.JTextField tkswarnaumama;
    private javax.swing.JTextField tkswarnazmnow;
    private javax.swing.JTextField tkswarnazoya;
    private javax.swing.JTextField totaltransaksi;
    private javax.swing.JTextField ukurantransaksi;
    private javax.swing.JTextField warnatransaksi;
    // End of variables declaration//GEN-END:variables

}