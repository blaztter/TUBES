/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Hijab;

/**
 *
 * @author Lenovo
 */
public interface IHijab {
    String getNama();
    String getWarna();
    String getBahan();
    int getUkuran();
    double getHarga();
    String getDeskripsi();
    int getStock();

    void setNama(String nama);
    void setWarna(String warna);
    void setBahan(String bahan);
    void setUkuran(int ukuran);
    void setHarga(double harga);
    void setDeskripsi(String deskripsi);
    void setStock(int stock);
}

