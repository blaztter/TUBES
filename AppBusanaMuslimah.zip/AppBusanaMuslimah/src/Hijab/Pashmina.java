/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Hijab;

/**
 *
 * @author Lenovo
 */
public class Pashmina extends Hijab {
    public Pashmina(String nama, String warna, String bahan, int ukuran, double harga, String deskripsi, int stock) {
        super(nama, warna, bahan, ukuran, harga, deskripsi, stock);
    }
}

