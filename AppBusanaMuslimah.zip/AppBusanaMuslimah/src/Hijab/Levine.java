/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Hijab;

/**
 *
 * @author Lenovo
 */
public class Levine extends Hijab {
    public Levine(String nama, String warna, String bahan, int ukuran, double harga, String deskripsi, int stock) {
        super(nama, warna, bahan, ukuran, harga, deskripsi, stock);
    }
}
