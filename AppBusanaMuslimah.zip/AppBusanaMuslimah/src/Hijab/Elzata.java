/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Hijab;

/**
 *
 * @author Lenovo
 */
public class Elzata extends Hijab {
    // Anda dapat menambahkan fitur khusus untuk Elzata di sini jika diperlukan
    public Elzata(String nama, String warna, String bahan, int ukuran, double harga, String deskripsi, int stock) {
        super(nama, warna, bahan, ukuran, harga, deskripsi, stock);
    }
}

