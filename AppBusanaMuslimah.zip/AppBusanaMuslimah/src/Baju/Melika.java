/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Baju;

/**
 *
 * @author Lenovo
 */
public class Melika extends BajuMuslimah {
    public Melika(String nama, String warna, String bahan, int ukuran, double harga, String deskripsi, int stock) {
        super(nama, warna, bahan, ukuran, harga, deskripsi, stock);
    }
}