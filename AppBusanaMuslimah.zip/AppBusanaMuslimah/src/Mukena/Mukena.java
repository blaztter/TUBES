/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mukena;

/**
 *
 * @author Lenovo
 */
public class Mukena implements IMukena {
    private String nama;
    private String warna;
    private String bahan;
    private int ukuran;
    private double harga;
    private String deskripsi;
    private int stock;

    // Constructor
    public Mukena(String nama, String warna, String bahan, int ukuran, double harga, String deskripsi, int stock) {
        this.nama = nama;
        this.warna = warna;
        this.bahan = bahan;
        this.ukuran = ukuran;
        this.harga = harga;
        this.deskripsi = deskripsi;
        this.stock = stock;
    }

    // Implementasi dari interface IHijab
    // Getter
    @Override
    public String getNama() {
        return nama;
    }

    @Override
    public String getWarna() {
        return warna;
    }

    @Override
    public String getBahan() {
        return bahan;
    }

    @Override
    public int getUkuran() {
        return ukuran;
    }

    @Override
    public double getHarga() {
        return harga;
    }

    @Override
    public String getDeskripsi() {
        return deskripsi;
    }

    @Override
    public int getStock() {
        return stock;
    }

    // Setter
    @Override
    public void setNama(String nama) {
        this.nama = nama;
    }

    @Override
    public void setWarna(String warna) {
        this.warna = warna;
    }

    @Override
    public void setBahan(String bahan) {
        this.bahan = bahan;
    }

    @Override
    public void setUkuran(int ukuran) {
        this.ukuran = ukuran;
    }

    @Override
    public void setHarga(double harga) {
        this.harga = harga;
    }

    @Override
    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    @Override
    public void setStock(int stock) {
        this.stock = stock;
    }
}


