/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Mukena;

/**
 *
 * @author Lenovo
 */
public interface IMukena {
    String getNama();
    String getWarna();
    String getBahan();
    int getUkuran();
    double getHarga();
    String getDeskripsi();
    int getStock();

    void setNama(String nama);
    void setWarna(String warna);
    void setBahan(String bahan);
    void setUkuran(int ukuran);
    void setHarga(double harga);
    void setDeskripsi(String deskripsi);
    void setStock(int stock);
}
